using UnityEngine;

namespace TreasureHunt
{
    /// <summary>Synthesizes every sound effect and music loop at startup (no audio files required).</summary>
    public static class ProceduralAudio
    {
        public const int SR = 22050;

        static AudioClip Make(string name, float[] d)
        {
            AudioClip c = AudioClip.Create(name, d.Length, 1, SR, false);
            c.SetData(d, 0);
            return c;
        }

        static float Wave(int type, float phase)
        {
            float p = phase - Mathf.Floor(phase);
            switch (type)
            {
                case 1: return p < 0.5f ? 0.6f : -0.6f;                // square
                case 2: return 1f - 4f * Mathf.Abs(p - 0.5f);           // triangle
                default: return Mathf.Sin(p * Mathf.PI * 2f);           // sine
            }
        }

        /// <summary>Adds a tone with a frequency sweep and exponential decay into buffer d.</summary>
        static void AddTone(float[] d, float start, float dur, float f0, float f1, int type, float vol, float decay)
        {
            int s0 = (int)(start * SR), n = (int)(dur * SR);
            float phase = 0;
            for (int i = 0; i < n && s0 + i < d.Length; i++)
            {
                float t = i / (float)n;
                float f = Mathf.Lerp(f0, f1, t);
                phase += f / SR;
                float env = Mathf.Min(1f, i / (SR * 0.004f)) * Mathf.Exp(-t * decay);
                d[s0 + i] += Wave(type, phase) * vol * env;
            }
        }

        static void AddNoise(float[] d, float start, float dur, float vol, float smooth, float decay, int seed)
        {
            System.Random r = new System.Random(seed);
            int s0 = (int)(start * SR), n = (int)(dur * SR);
            float y = 0;
            for (int i = 0; i < n && s0 + i < d.Length; i++)
            {
                float t = i / (float)n;
                float x = (float)(r.NextDouble() * 2 - 1);
                y += (x - y) * smooth;
                float env = Mathf.Min(1f, i / (SR * 0.003f)) * Mathf.Exp(-t * decay);
                d[s0 + i] += y * vol * env;
            }
        }

        static float[] Buf(float seconds) { return new float[(int)(seconds * SR)]; }

        static float Midi(int m) { return 440f * Mathf.Pow(2f, (m - 69) / 12f); }

        public static AudioClip Coin() { float[] d = Buf(0.25f); AddTone(d, 0, 0.07f, 988, 988, 1, 0.25f, 2); AddTone(d, 0.06f, 0.19f, 1319, 1319, 1, 0.25f, 5); return Make("sfx_coin", d); }
        public static AudioClip Gem() { float[] d = Buf(0.45f); int[] m = { 84, 88, 91, 96 }; for (int i = 0; i < 4; i++) AddTone(d, i * 0.07f, 0.2f, Midi(m[i]), Midi(m[i]), 2, 0.3f, 4); return Make("sfx_gem", d); }
        public static AudioClip Key() { float[] d = Buf(0.4f); AddTone(d, 0, 0.15f, 1568, 1568, 0, 0.3f, 3); AddTone(d, 0.1f, 0.3f, 2093, 2093, 0, 0.3f, 4); AddNoise(d, 0, 0.08f, 0.15f, 0.9f, 8, 3); return Make("sfx_key", d); }
        public static AudioClip Chest()
        {
            float[] d = Buf(1.0f);
            AddNoise(d, 0, 0.18f, 0.35f, 0.25f, 6, 4);              // creak
            AddTone(d, 0, 0.2f, 180, 120, 2, 0.3f, 4);
            int[] m = { 72, 76, 79, 84, 88, 91 };
            for (int i = 0; i < m.Length; i++) AddTone(d, 0.15f + i * 0.06f, 0.35f, Midi(m[i]), Midi(m[i]), 0, 0.22f, 4);
            return Make("sfx_chest", d);
        }
        public static AudioClip Jump() { float[] d = Buf(0.25f); AddTone(d, 0, 0.22f, 280, 720, 2, 0.35f, 3); return Make("sfx_jump", d); }
        public static AudioClip Slide() { float[] d = Buf(0.35f); AddNoise(d, 0, 0.33f, 0.4f, 0.12f, 3, 5); return Make("sfx_slide", d); }
        public static AudioClip Hit() { float[] d = Buf(0.5f); AddNoise(d, 0, 0.45f, 0.7f, 0.35f, 6, 6); AddTone(d, 0, 0.4f, 140, 50, 0, 0.6f, 5); return Make("sfx_hit", d); }
        public static AudioClip Explosion() { float[] d = Buf(1.1f); AddNoise(d, 0, 1.05f, 0.85f, 0.08f, 4, 7); AddTone(d, 0, 0.6f, 90, 35, 0, 0.6f, 4); return Make("sfx_explosion", d); }
        public static AudioClip Splash() { float[] d = Buf(0.8f); AddNoise(d, 0, 0.75f, 0.6f, 0.5f, 5, 8); AddNoise(d, 0.05f, 0.5f, 0.3f, 0.15f, 4, 9); return Make("sfx_splash", d); }
        public static AudioClip PowerUp() { float[] d = Buf(0.6f); int[] m = { 67, 71, 74, 79, 83, 86 }; for (int i = 0; i < m.Length; i++) AddTone(d, i * 0.05f, 0.18f, Midi(m[i]), Midi(m[i]), 1, 0.18f, 3); return Make("sfx_powerup", d); }
        public static AudioClip Shield() { float[] d = Buf(0.5f); AddTone(d, 0, 0.45f, 600, 1200, 0, 0.3f, 3); AddTone(d, 0, 0.45f, 905, 1800, 0, 0.15f, 3); return Make("sfx_shield", d); }
        public static AudioClip Cannon() { float[] d = Buf(0.8f); AddNoise(d, 0, 0.7f, 0.8f, 0.2f, 7, 10); AddTone(d, 0, 0.35f, 110, 40, 0, 0.7f, 6); return Make("sfx_cannon", d); }
        public static AudioClip Footstep() { float[] d = Buf(0.07f); AddNoise(d, 0, 0.06f, 0.25f, 0.3f, 12, 11); AddTone(d, 0, 0.05f, 120, 80, 0, 0.2f, 10); return Make("sfx_step", d); }
        public static AudioClip Button() { float[] d = Buf(0.12f); AddTone(d, 0, 0.1f, 660, 880, 2, 0.3f, 6); return Make("sfx_button", d); }
        public static AudioClip Rumble() { float[] d = Buf(0.9f); AddNoise(d, 0, 0.85f, 0.6f, 0.04f, 2, 12); return Make("sfx_rumble", d); }
        public static AudioClip Revive() { float[] d = Buf(0.9f); int[] m = { 60, 64, 67, 72, 76, 79, 84 }; for (int i = 0; i < m.Length; i++) AddTone(d, i * 0.08f, 0.3f, Midi(m[i]), Midi(m[i]), 2, 0.2f, 3); return Make("sfx_revive", d); }

        public static AudioClip GameOverMusic()
        {
            float[] d = Buf(2.6f);
            int[] m = { 69, 67, 65, 64, 62 };
            for (int i = 0; i < m.Length; i++) AddTone(d, i * 0.32f, i == m.Length - 1 ? 1.4f : 0.34f, Midi(m[i]), Midi(m[i]), 2, 0.3f, i == m.Length - 1 ? 2.5f : 1.5f);
            AddTone(d, 1.28f, 1.3f, Midi(38), Midi(38), 2, 0.3f, 2);
            return Make("music_gameover", d);
        }

        /// <summary>Original 8-bar sea-shanty style loop in D minor (triangle lead, sine bass, light percussion).</summary>
        public static AudioClip Music()
        {
            const float beat = 60f / 132f;
            const int bars = 8;
            float[] d = Buf(bars * 4 * beat);
            int[] bass = { 50, 48, 50, 45, 50, 48, 45, 50 };         // D C D A | D C A D
            // Melody: (midi, beats) pairs per bar, 4 beats each.
            int[][] mel =
            {
                new[] { 62, 1, 65, 1, 69, 2 },
                new[] { 67, 1, 65, 1, 64, 2 },
                new[] { 62, 1, 65, 1, 69, 1, 72, 1 },
                new[] { 69, 2, 64, 2 },
                new[] { 74, 1, 72, 1, 69, 1, 65, 1 },
                new[] { 67, 1, 64, 1, 60, 2 },
                new[] { 61, 1, 64, 1, 69, 1, 67, 1 },
                new[] { 65, 1, 64, 1, 62, 2 },
            };
            for (int b = 0; b < bars; b++)
            {
                float t0 = b * 4 * beat;
                for (int q = 0; q < 4; q++)
                {
                    AddTone(d, t0 + q * beat, beat * 0.9f, Midi(bass[b] - 12), Midi(bass[b] - 12), 0, q % 2 == 0 ? 0.28f : 0.18f, 3);
                    AddNoise(d, t0 + q * beat, 0.05f, q % 2 == 0 ? 0.12f : 0.06f, 0.6f, 12, 100 + b * 4 + q);
                }
                int[] notes = mel[b];
                float acc = 0;
                for (int i = 0; i < notes.Length; i += 2)
                {
                    float len = notes[i + 1] * beat;
                    AddTone(d, t0 + acc, len * 0.95f, Midi(notes[i]), Midi(notes[i]), 2, 0.2f, 2f);
                    acc += len;
                }
            }
            for (int i = 0; i < d.Length; i++) d[i] = Mathf.Clamp(d[i], -1f, 1f);
            return Make("music_shanty", d);
        }

        /// <summary>Seamless ocean waves loop: filtered noise with slow swells, crossfaded ends.</summary>
        public static AudioClip Ocean()
        {
            float seconds = 8f;
            float[] d = Buf(seconds);
            System.Random r = new System.Random(42);
            float y = 0, y2 = 0;
            for (int i = 0; i < d.Length; i++)
            {
                float t = i / (float)SR;
                float x = (float)(r.NextDouble() * 2 - 1);
                y += (x - y) * 0.05f;
                y2 += (y - y2) * 0.2f;
                float swell = 0.55f + 0.45f * Mathf.Sin(t / seconds * Mathf.PI * 4f);
                d[i] = y2 * 2.2f * swell;
            }
            int fade = SR / 2;
            for (int i = 0; i < fade; i++)
            {
                float a = i / (float)fade;
                int j = d.Length - fade + i;
                d[i] = d[i] * a + d[j] * (1 - a);
            }
            System.Array.Resize(ref d, d.Length - fade);
            return Make("amb_ocean", d);
        }

        public static AudioClip Seagull()
        {
            float[] d = Buf(1.3f);
            for (int c = 0; c < 3; c++)
            {
                float st = c * 0.35f;
                int n = (int)(0.28f * SR), s0 = (int)(st * SR);
                float phase = 0;
                for (int i = 0; i < n; i++)
                {
                    float t = i / (float)n;
                    float f = Mathf.Lerp(2100, 1300, t) + Mathf.Sin(t * 60f) * 120f;
                    phase += f / SR;
                    float env = Mathf.Sin(t * Mathf.PI);
                    d[s0 + i] += Wave(2, phase) * 0.18f * env;
                }
            }
            return Make("amb_seagull", d);
        }
    }
}
