using System.Collections.Generic;
using UnityEngine;

namespace TreasureHunt
{
    public enum Sfx { Coin, Gem, Key, Chest, Artifact, Jump, Slide, Hit, Explosion, Splash, PowerUp, Shield, Cannon, Footstep, Button, Rumble, Revive }

    /// <summary>
    /// Plays effects through a small round-robin AudioSource pool plus dedicated music and ambience sources.
    /// Clips are synthesized; dropping a clip named e.g. "Coin" or "Music" into Assets/Resources/Audio overrides it.
    /// </summary>
    public class AudioManager : MonoBehaviour
    {
        public static AudioManager Instance { get; private set; }

        readonly Dictionary<Sfx, AudioClip> clips = new Dictionary<Sfx, AudioClip>();
        AudioSource[] sfx;
        int next;
        AudioSource music, ambience, gulls;
        AudioClip musicClip, gameOverClip, oceanClip, gullClip;
        float gullTimer = 4f;

        public bool SoundOn { get; private set; }
        public bool MusicOn { get; private set; }

        static AudioClip Load(string name, AudioClip fallback)
        {
            AudioClip c = Resources.Load<AudioClip>("Audio/" + name);
            return c != null ? c : fallback;
        }

        void Awake()
        {
            Instance = this;
            sfx = new AudioSource[8];
            for (int i = 0; i < sfx.Length; i++)
            {
                sfx[i] = gameObject.AddComponent<AudioSource>();
                sfx[i].playOnAwake = false;
            }
            music = gameObject.AddComponent<AudioSource>();
            music.loop = true; music.playOnAwake = false; music.volume = 0.35f;
            ambience = gameObject.AddComponent<AudioSource>();
            ambience.loop = true; ambience.playOnAwake = false; ambience.volume = 0.3f;
            gulls = gameObject.AddComponent<AudioSource>();
            gulls.playOnAwake = false; gulls.volume = 0.25f;

            clips[Sfx.Coin] = Load("Coin", ProceduralAudio.Coin());
            clips[Sfx.Gem] = Load("Gem", ProceduralAudio.Gem());
            clips[Sfx.Key] = Load("Key", ProceduralAudio.Key());
            clips[Sfx.Chest] = Load("Chest", ProceduralAudio.Chest());
            clips[Sfx.Artifact] = Load("Artifact", clips[Sfx.Chest]);
            clips[Sfx.Jump] = Load("Jump", ProceduralAudio.Jump());
            clips[Sfx.Slide] = Load("Slide", ProceduralAudio.Slide());
            clips[Sfx.Hit] = Load("Hit", ProceduralAudio.Hit());
            clips[Sfx.Explosion] = Load("Explosion", ProceduralAudio.Explosion());
            clips[Sfx.Splash] = Load("Splash", ProceduralAudio.Splash());
            clips[Sfx.PowerUp] = Load("PowerUp", ProceduralAudio.PowerUp());
            clips[Sfx.Shield] = Load("Shield", ProceduralAudio.Shield());
            clips[Sfx.Cannon] = Load("Cannon", ProceduralAudio.Cannon());
            clips[Sfx.Footstep] = Load("Footstep", ProceduralAudio.Footstep());
            clips[Sfx.Button] = Load("Button", ProceduralAudio.Button());
            clips[Sfx.Rumble] = Load("Rumble", ProceduralAudio.Rumble());
            clips[Sfx.Revive] = Load("Revive", ProceduralAudio.Revive());
            musicClip = Load("Music", ProceduralAudio.Music());
            gameOverClip = Load("GameOver", ProceduralAudio.GameOverMusic());
            oceanClip = Load("Ocean", ProceduralAudio.Ocean());
            gullClip = Load("Seagull", ProceduralAudio.Seagull());

            ambience.clip = oceanClip;
            SetSound(SaveSystem.SoundOn);
            SetMusic(SaveSystem.MusicOn);
        }

        void OnDestroy() { if (Instance == this) Instance = null; }

        public void Play(Sfx s, float volume = 1f, float pitch = 1f)
        {
            if (!SoundOn) return;
            AudioClip c;
            if (!clips.TryGetValue(s, out c) || c == null) return;
            AudioSource src = sfx[next];
            next = (next + 1) % sfx.Length;
            src.pitch = pitch;
            src.PlayOneShot(c, volume);
        }

        public void SetSound(bool on)
        {
            SoundOn = on;
            SaveSystem.SoundOn = on;
            if (on) { if (!ambience.isPlaying) ambience.Play(); }
            else { ambience.Stop(); gulls.Stop(); for (int i = 0; i < sfx.Length; i++) sfx[i].Stop(); }
        }

        public void SetMusic(bool on)
        {
            MusicOn = on;
            SaveSystem.MusicOn = on;
            if (on) PlayMusic(); else music.Stop();
        }

        public void PlayMusic()
        {
            if (!MusicOn) return;
            if (music.clip == musicClip && music.isPlaying) return;
            music.clip = musicClip;
            music.loop = true;
            music.Play();
        }

        public void PlayGameOverMusic()
        {
            if (!MusicOn) return;
            music.clip = gameOverClip;
            music.loop = false;
            music.Play();
        }

        public void SetMusicPaused(bool paused)
        {
            if (paused) music.Pause(); else if (MusicOn) music.UnPause();
        }

        void Update()
        {
            if (!SoundOn) return;
            gullTimer -= Time.unscaledDeltaTime;
            if (gullTimer <= 0f)
            {
                gullTimer = Random.Range(6f, 14f);
                gulls.pitch = Random.Range(0.85f, 1.15f);
                gulls.PlayOneShot(gullClip, 0.7f);
            }
        }
    }
}
