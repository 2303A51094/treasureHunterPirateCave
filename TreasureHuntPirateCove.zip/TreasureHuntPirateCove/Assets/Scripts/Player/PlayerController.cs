using UnityEngine;

namespace TreasureHunt
{
    public enum DeathCause { Obstacle, Fall }

    /// <summary>
    /// Auto-running three-lane controller. Movement is kinematic (transform-driven) with a downward ground
    /// probe, so the player can never fall through the track because of physics settings. Triggers on
    /// obstacles/collectibles are reported to the GameManager (which guards against duplicate handling).
    /// </summary>
    public class PlayerController : MonoBehaviour
    {
        public CapsuleCollider capsule;
        public PlayerAnimator animator;
        public GameObject shieldBubble;

        GameConfig cfg;
        GameManager gm;
        int lane = 1;
        float x, y, z, vy;
        bool grounded = true, alive = true, sliding;
        float slideTimer, jumpBuffer, slideBuffer, invulnTimer;
        static readonly int GroundMask = ~(1 << 2);

        public int Lane { get { return lane; } }
        public bool IsGrounded { get { return grounded; } }
        public bool IsSliding { get { return sliding; } }
        public bool IsAlive { get { return alive; } }
        public bool IsInvulnerable { get { return invulnTimer > 0f; } }
        public float Z { get { return z; } }

        public void Init(GameConfig config, GameManager manager)
        {
            cfg = config;
            gm = manager;
            ResetPlayer();
        }

        public void ResetPlayer()
        {
            lane = 1;
            x = 0; y = 0; z = 0; vy = 0;
            grounded = true; alive = true;
            StopSlide();
            jumpBuffer = slideBuffer = invulnTimer = 0f;
            transform.SetPositionAndRotation(Vector3.zero, Quaternion.identity);
            if (animator != null) animator.ResetPose();
        }

        public void GrantInvulnerability(float seconds) { invulnTimer = Mathf.Max(invulnTimer, seconds); }

        public void Kill()
        {
            alive = false;
            StopSlide();
        }

        /// <summary>Restores a safe running state at the current track position.</summary>
        public void Revive(float invulnerability)
        {
            alive = true;
            grounded = true;
            vy = 0;
            y = 0f;
            x = cfg.LaneX(lane);
            StopSlide();
            jumpBuffer = slideBuffer = 0f;
            transform.position = new Vector3(x, y, z);
            if (animator != null) animator.ResetPose();
            GrantInvulnerability(invulnerability);
        }

        void StartSlide()
        {
            sliding = true;
            slideTimer = cfg.slideDuration;
            capsule.height = 0.8f;
            capsule.center = new Vector3(0, 0.4f, 0);
            if (AudioManager.Instance != null) AudioManager.Instance.Play(Sfx.Slide, 0.6f);
        }

        void StopSlide()
        {
            sliding = false;
            slideTimer = 0;
            if (capsule != null)
            {
                capsule.height = 1.7f;
                capsule.center = new Vector3(0, 0.85f, 0);
            }
        }

        void Jump()
        {
            StopSlide();
            grounded = false;
            vy = cfg.jumpVelocity;
            jumpBuffer = 0;
            if (AudioManager.Instance != null) AudioManager.Instance.Play(Sfx.Jump, 0.6f);
        }

        void Update()
        {
            if (gm == null || cfg == null) return;
            float dt = Time.deltaTime;
            GameState state = gm.State;

            if (state == GameState.Menu || state == GameState.GameOver && alive)
            {
                if (animator != null) animator.Tick(PlayerPose.Idle, 0, dt);
                return;
            }
            if (!alive)
            {
                if (animator != null) animator.Tick(PlayerPose.Dead, 0, dt);
                return;
            }
            if (state != GameState.Playing) return;

            // ---- input
            InputCommand cmd = gm.input != null ? gm.input.Command : InputCommand.None;
            switch (cmd)
            {
                case InputCommand.Left: if (lane > 0) lane--; break;
                case InputCommand.Right: if (lane < 2) lane++; break;
                case InputCommand.Jump: jumpBuffer = 0.15f; break;
                case InputCommand.Slide: slideBuffer = 0.2f; break;
            }
            if (jumpBuffer > 0f) { jumpBuffer -= dt; if (grounded) Jump(); }
            if (slideBuffer > 0f)
            {
                slideBuffer -= dt;
                if (grounded && !sliding) { StartSlide(); slideBuffer = 0; }
                else if (!grounded && vy > -cfg.jumpVelocity) vy = -cfg.jumpVelocity * 1.4f; // fast-fall, slide on landing
            }

            // ---- forward & lateral
            z += gm.CurrentSpeed * dt;
            x = Mathf.MoveTowards(x, cfg.LaneX(lane), cfg.laneChangeSpeed * dt);

            // ---- vertical / ground probe
            RaycastHit hit;
            bool hasGround = Physics.Raycast(new Vector3(x, y + 0.6f, z), Vector3.down, out hit, 4f, GroundMask, QueryTriggerInteraction.Ignore);
            float groundY = hasGround ? hit.point.y : -100f;
            if (grounded)
            {
                if (hasGround && groundY > y - 0.35f) y = groundY;
                else { grounded = false; vy = 0f; }
            }
            if (!grounded)
            {
                vy -= cfg.gravity * dt;
                float ny = y + vy * dt;
                if (vy <= 0f && hasGround && ny <= groundY && y >= groundY - 0.35f)
                {
                    y = groundY;
                    vy = 0;
                    grounded = true;
                    if (AudioManager.Instance != null) AudioManager.Instance.Play(Sfx.Footstep, 0.6f);
                }
                else y = ny;
            }

            if (sliding)
            {
                slideTimer -= dt;
                if (slideTimer <= 0f) StopSlide();
            }

            if (invulnTimer > 0f)
            {
                invulnTimer -= dt;
                if (animator != null) animator.SetVisible(invulnTimer <= 0f || Mathf.Repeat(invulnTimer, 0.2f) > 0.08f);
            }

            transform.position = new Vector3(x, y, z);

            if (y < cfg.fallDeathY)
            {
                gm.ReportFall();
                return;
            }

            PlayerPose pose = sliding ? PlayerPose.Slide : grounded ? PlayerPose.Run : PlayerPose.Jump;
            if (animator != null && animator.Tick(pose, gm.CurrentSpeed, dt) && grounded)
            {
                if (AudioManager.Instance != null) AudioManager.Instance.Play(Sfx.Footstep, 0.35f, Random.Range(0.9f, 1.1f));
            }
        }

        void OnTriggerEnter(Collider other)
        {
            if (gm == null || !alive || gm.State != GameState.Playing) return;
            Collectible c = other.GetComponentInParent<Collectible>();
            if (c != null)
            {
                if (!c.collected) gm.Collect(c);
                return;
            }
            Obstacle o = other.GetComponentInParent<Obstacle>();
            if (o != null && !o.consumed) gm.ReportObstacleHit(o);
        }
    }
}
