using UnityEngine;

namespace TreasureHunt
{
    /// <summary>References to the animated joints of a procedural low-poly pirate.</summary>
    public class HumanoidParts
    {
        public Transform model, hips, torso, head, legL, legR, armL, armR;
    }

    /// <summary>Builds the low-poly pirate characters (player and guards) from primitives.</summary>
    public static class PirateBuilder
    {
        public static HumanoidParts BuildHumanoid(Transform parent, string coatMat, bool captain)
        {
            HumanoidParts h = new HumanoidParts();
            const PrimitiveType Cap = PrimitiveType.Capsule, Cube = PrimitiveType.Cube, Sph = PrimitiveType.Sphere, Cyl = PrimitiveType.Cylinder;
            h.model = Proc.Node("Model", parent, Vector3.zero).transform;
            h.hips = Proc.Node("Hips", h.model, new Vector3(0, 0.95f, 0)).transform;

            // Legs
            h.legL = Proc.Node("LegL", h.hips, new Vector3(-0.13f, 0, 0)).transform;
            h.legR = Proc.Node("LegR", h.hips, new Vector3(0.13f, 0, 0)).transform;
            Transform[] legs = { h.legL, h.legR };
            for (int i = 0; i < 2; i++)
            {
                Proc.Part(Cap, "PiratePants", legs[i], new Vector3(0, -0.42f, 0), new Vector3(0.22f, 0.42f, 0.22f));
                Proc.Part(Cube, "PirateBoots", legs[i], new Vector3(0, -0.86f, 0.05f), new Vector3(0.23f, 0.18f, 0.34f));
                Proc.Part(Cyl, "PirateBoots", legs[i], new Vector3(0, -0.7f, 0), new Vector3(0.26f, 0.1f, 0.26f));
            }

            // Torso
            h.torso = Proc.Node("Torso", h.hips, Vector3.zero).transform;
            Proc.Part(Cube, coatMat, h.torso, new Vector3(0, 0.33f, 0), new Vector3(0.52f, 0.62f, 0.3f));
            Proc.Part(Cube, coatMat, h.torso, new Vector3(0, -0.08f, -0.03f), new Vector3(0.5f, 0.3f, 0.27f));
            Proc.Part(Cube, "PirateShirt", h.torso, new Vector3(0, 0.45f, 0.14f), new Vector3(0.18f, 0.32f, 0.05f));
            Proc.Part(Cube, "Black", h.torso, new Vector3(0, 0.08f, 0), new Vector3(0.54f, 0.08f, 0.32f));
            Proc.Part(Cube, "Gold", h.torso, new Vector3(0, 0.08f, 0.165f), new Vector3(0.11f, 0.09f, 0.03f));
            Proc.Part(Cube, "Gold", h.torso, new Vector3(-0.2f, 0.55f, 0.155f), new Vector3(0.06f, 0.06f, 0.02f));
            Proc.Part(Cube, "Gold", h.torso, new Vector3(0.2f, 0.55f, 0.155f), new Vector3(0.06f, 0.06f, 0.02f));
            // Cutlass at the hip
            Proc.Part(Cube, "Silver", h.torso, new Vector3(0.3f, -0.18f, 0.02f), new Vector3(0.04f, 0.5f, 0.08f), new Vector3(0, 0, 18));
            Proc.Part(Cube, "Gold", h.torso, new Vector3(0.27f, 0.08f, 0.02f), new Vector3(0.12f, 0.04f, 0.1f), new Vector3(0, 0, 18));

            // Head
            h.head = Proc.Node("Head", h.torso, new Vector3(0, 0.68f, 0)).transform;
            Proc.Part(Sph, "SkinTone", h.head, new Vector3(0, 0.17f, 0), new Vector3(0.34f, 0.36f, 0.34f));
            Proc.Part(Sph, "Beard", h.head, new Vector3(0, 0.06f, 0.09f), new Vector3(0.27f, 0.2f, 0.2f));
            Proc.Part(Sph, "SkinTone", h.head, new Vector3(0, 0.17f, 0.17f), new Vector3(0.07f, 0.08f, 0.08f));
            Proc.Part(Cube, "Black", h.head, new Vector3(0.075f, 0.22f, 0.155f), new Vector3(0.1f, 0.07f, 0.03f));
            Proc.Part(Cube, "Black", h.head, new Vector3(0, 0.25f, 0), new Vector3(0.36f, 0.02f, 0.36f), new Vector3(0, 0, -12));
            if (captain)
            {
                // Tricorn hat with gold band and skull badge
                Proc.Part(Cyl, "HatBlack", h.head, new Vector3(0, 0.33f, 0), new Vector3(0.62f, 0.025f, 0.52f), new Vector3(-8, 0, 0));
                Proc.Part(Cyl, "HatBlack", h.head, new Vector3(0, 0.42f, -0.01f), new Vector3(0.33f, 0.11f, 0.32f));
                Proc.Part(Cyl, "Gold", h.head, new Vector3(0, 0.36f, -0.01f), new Vector3(0.34f, 0.02f, 0.33f));
                Proc.Part(Cube, "HatBlack", h.head, new Vector3(-0.27f, 0.37f, 0), new Vector3(0.06f, 0.1f, 0.4f), new Vector3(0, 0, 30));
                Proc.Part(Cube, "HatBlack", h.head, new Vector3(0.27f, 0.37f, 0), new Vector3(0.06f, 0.1f, 0.4f), new Vector3(0, 0, -30));
                Proc.Part(Sph, "PirateShirt", h.head, new Vector3(0, 0.43f, 0.165f), new Vector3(0.08f, 0.08f, 0.04f));
            }
            else
            {
                // Bandana for guards
                Proc.Part(Sph, "Bandana", h.head, new Vector3(0, 0.26f, -0.01f), new Vector3(0.37f, 0.22f, 0.37f));
                Proc.Part(Cube, "Bandana", h.head, new Vector3(0, 0.22f, -0.2f), new Vector3(0.08f, 0.16f, 0.06f), new Vector3(30, 0, 0));
            }

            // Arms
            h.armL = Proc.Node("ArmL", h.torso, new Vector3(-0.33f, 0.58f, 0)).transform;
            h.armR = Proc.Node("ArmR", h.torso, new Vector3(0.33f, 0.58f, 0)).transform;
            Transform[] arms = { h.armL, h.armR };
            for (int i = 0; i < 2; i++)
            {
                Proc.Part(Cap, coatMat, arms[i], new Vector3(0, -0.27f, 0), new Vector3(0.16f, 0.3f, 0.16f));
                Proc.Part(Cyl, "PirateShirt", arms[i], new Vector3(0, -0.52f, 0), new Vector3(0.15f, 0.04f, 0.15f));
                Proc.Part(Sph, "SkinTone", arms[i], new Vector3(0, -0.6f, 0), new Vector3(0.13f, 0.13f, 0.13f));
            }
            return h;
        }

        /// <summary>The player character: pirate captain with collider, kinematic rigidbody and controllers.</summary>
        public static GameObject BuildPlayer()
        {
            GameObject root = new GameObject("Player");
            root.layer = 2; // Ignore Raycast: ground probes never hit the player itself
            HumanoidParts h = BuildHumanoid(root.transform, "PirateCoat", true);

            CapsuleCollider col = root.AddComponent<CapsuleCollider>();
            col.radius = 0.35f;
            col.height = 1.7f;
            col.center = new Vector3(0, 0.85f, 0);
            Rigidbody rb = root.AddComponent<Rigidbody>();
            rb.isKinematic = true;
            rb.useGravity = false;
            rb.interpolation = RigidbodyInterpolation.None;

            PlayerAnimator anim = root.AddComponent<PlayerAnimator>();
            anim.model = h.model; anim.hips = h.hips; anim.torso = h.torso; anim.head = h.head;
            anim.legL = h.legL; anim.legR = h.legR; anim.armL = h.armL; anim.armR = h.armR;

            // Shield bubble (toggled by the PowerUpManager)
            GameObject bubble = Proc.Part(PrimitiveType.Sphere, "ShieldBubble", root.transform, new Vector3(0, 0.95f, 0), new Vector3(1.9f, 2.2f, 1.9f), Vector3.zero, false, "ShieldBubble");
            bubble.AddComponent<Pulse>().amount = 0.04f;
            bubble.SetActive(false);

            PlayerController pc = root.AddComponent<PlayerController>();
            pc.capsule = col;
            pc.animator = anim;
            pc.shieldBubble = bubble;
            return root;
        }
    }
}
