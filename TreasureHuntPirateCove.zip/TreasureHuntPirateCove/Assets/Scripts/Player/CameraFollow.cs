using UnityEngine;

namespace TreasureHunt
{
    /// <summary>
    /// Third-person chase camera. Follows lane changes and jumps with damping (so the view never jerks),
    /// orbits the captain on the menu, widens FOV during speed boost, and supports screen shake.
    /// </summary>
    [RequireComponent(typeof(Camera))]
    public class CameraFollow : MonoBehaviour
    {
        public Transform target;
        public Vector3 offset = new Vector3(0, 3.6f, -6.8f);
        public float lookAhead = 7f;
        public float baseFov = 60f;
        public float boostFov = 72f;

        Camera cam;
        float camX, camY, shakeAmount, shakeTime, menuAngle, blend;
        bool menuMode = true;

        void Awake()
        {
            cam = GetComponent<Camera>();
            cam.fieldOfView = baseFov;
            cam.nearClipPlane = 0.2f;
            cam.farClipPlane = 420f;
        }

        public void SetMenuMode(bool menu)
        {
            menuMode = menu;
            if (!menu) blend = 0f;
        }

        public void Shake(float amount, float duration)
        {
            shakeAmount = Mathf.Max(shakeAmount, amount);
            shakeTime = Mathf.Max(shakeTime, duration);
        }

        public void Snap()
        {
            if (target == null) return;
            camX = target.position.x * 0.65f;
            camY = target.position.y * 0.35f;
            blend = 1f;
        }

        void LateUpdate()
        {
            if (target == null) return;
            float dt = Time.unscaledDeltaTime;
            if (Time.timeScale == 0f) return; // paused: hold still
            Vector3 tp = target.position;

            Vector3 desiredPos;
            Quaternion desiredRot;
            if (menuMode)
            {
                menuAngle += dt * 0.15f;
                float a = Mathf.Sin(menuAngle) * 0.5f;
                desiredPos = tp + new Vector3(Mathf.Sin(a) * 5.5f + 1.5f, 2.2f, Mathf.Cos(a) * 5.5f);
                desiredRot = Quaternion.LookRotation(tp + new Vector3(0, 1.5f, 0) - desiredPos);
                blend = 0f;
            }
            else
            {
                camX = Mathf.Lerp(camX, tp.x * 0.65f, 1f - Mathf.Exp(-dt * 8f));
                camY = Mathf.Lerp(camY, Mathf.Max(-1f, tp.y) * 0.35f, 1f - Mathf.Exp(-dt * 5f));
                desiredPos = new Vector3(camX, offset.y + camY, tp.z + offset.z);
                Vector3 look = new Vector3(camX * 0.8f, 1.1f + camY, tp.z + lookAhead);
                desiredRot = Quaternion.LookRotation(look - desiredPos);
                blend = Mathf.MoveTowards(blend, 1f, dt * 1.5f);
            }

            if (!menuMode && blend < 1f)
            {
                float k = blend * blend * (3f - 2f * blend);
                transform.position = Vector3.Lerp(transform.position, desiredPos, k);
                transform.rotation = Quaternion.Slerp(transform.rotation, desiredRot, k);
            }
            else
            {
                transform.position = menuMode ? Vector3.Lerp(transform.position, desiredPos, 1f - Mathf.Exp(-dt * 3f)) : desiredPos;
                transform.rotation = menuMode ? Quaternion.Slerp(transform.rotation, desiredRot, 1f - Mathf.Exp(-dt * 3f)) : desiredRot;
            }

            if (shakeTime > 0f)
            {
                shakeTime -= dt;
                transform.position += Random.insideUnitSphere * shakeAmount;
                if (shakeTime <= 0f) shakeAmount = 0f;
            }

            GameManager gm = GameManager.Instance;
            float fov = (gm != null && gm.powerUps != null && gm.powerUps.SpeedBoostActive && !menuMode) ? boostFov : baseFov;
            cam.fieldOfView = Mathf.Lerp(cam.fieldOfView, fov, 1f - Mathf.Exp(-dt * 4f));
        }
    }
}
