using UnityEngine;

namespace TreasureHunt
{
    public enum PlayerPose { Idle, Run, Jump, Slide, Dead }

    /// <summary>Procedural run / jump / slide / death animation for the primitive pirate rig.</summary>
    public class PlayerAnimator : MonoBehaviour
    {
        public Transform model, hips, torso, head, legL, legR, armL, armR;
        float phase, deadT, slideBlend;
        Vector3 hipsBase;
        bool init;
        Renderer[] renderers;

        void Init()
        {
            if (init) return;
            init = true;
            if (hips != null) hipsBase = hips.localPosition;
            renderers = model != null ? model.GetComponentsInChildren<Renderer>(true) : new Renderer[0];
        }

        public void SetVisible(bool visible)
        {
            Init();
            for (int i = 0; i < renderers.Length; i++) renderers[i].enabled = visible;
        }

        public void ResetPose()
        {
            Init();
            phase = 0; deadT = 0; slideBlend = 0;
            if (model != null) { model.localRotation = Quaternion.identity; model.localPosition = Vector3.zero; }
            SetVisible(true);
        }

        static Quaternion X(float deg) { return Quaternion.Euler(deg, 0, 0); }

        /// <summary>Advances the animation. Returns true on the frame a foot strikes the ground (for footstep audio).</summary>
        public bool Tick(PlayerPose pose, float speed, float dt)
        {
            Init();
            if (model == null) return false;
            bool step = false;
            float k = 1f - Mathf.Exp(-dt * 18f);
            slideBlend = Mathf.MoveTowards(slideBlend, pose == PlayerPose.Slide ? 1f : 0f, dt * 8f);

            switch (pose)
            {
                case PlayerPose.Run:
                {
                    float prev = Mathf.Sin(phase);
                    phase += dt * speed * 1.45f;
                    float s = Mathf.Sin(phase);
                    if (Mathf.Sign(prev) != Mathf.Sign(s)) step = true;
                    legL.localRotation = Quaternion.Slerp(legL.localRotation, X(s * 48f), k);
                    legR.localRotation = Quaternion.Slerp(legR.localRotation, X(-s * 48f), k);
                    armL.localRotation = Quaternion.Slerp(armL.localRotation, Quaternion.Euler(-s * 42f, 0, -8f), k);
                    armR.localRotation = Quaternion.Slerp(armR.localRotation, Quaternion.Euler(s * 42f, 0, 8f), k);
                    torso.localRotation = Quaternion.Slerp(torso.localRotation, Quaternion.Euler(10f, s * 6f, 0), k);
                    hips.localPosition = hipsBase + new Vector3(0, Mathf.Abs(Mathf.Cos(phase)) * 0.07f, 0);
                    break;
                }
                case PlayerPose.Jump:
                    legL.localRotation = Quaternion.Slerp(legL.localRotation, X(-65f), k);
                    legR.localRotation = Quaternion.Slerp(legR.localRotation, X(25f), k);
                    armL.localRotation = Quaternion.Slerp(armL.localRotation, Quaternion.Euler(-150f, 0, -20f), k);
                    armR.localRotation = Quaternion.Slerp(armR.localRotation, Quaternion.Euler(-150f, 0, 20f), k);
                    torso.localRotation = Quaternion.Slerp(torso.localRotation, X(-5f), k);
                    hips.localPosition = Vector3.Lerp(hips.localPosition, hipsBase, k);
                    break;
                case PlayerPose.Slide:
                    legL.localRotation = Quaternion.Slerp(legL.localRotation, X(-80f), k);
                    legR.localRotation = Quaternion.Slerp(legR.localRotation, X(-60f), k);
                    armL.localRotation = Quaternion.Slerp(armL.localRotation, Quaternion.Euler(-30f, 0, -50f), k);
                    armR.localRotation = Quaternion.Slerp(armR.localRotation, Quaternion.Euler(-30f, 0, 50f), k);
                    torso.localRotation = Quaternion.Slerp(torso.localRotation, X(-20f), k);
                    break;
                case PlayerPose.Dead:
                    deadT = Mathf.Min(1f, deadT + dt * 3f);
                    model.localRotation = Quaternion.Slerp(Quaternion.identity, X(-80f), deadT);
                    model.localPosition = new Vector3(0, 0.2f * deadT, -0.6f * deadT);
                    armL.localRotation = Quaternion.Slerp(armL.localRotation, Quaternion.Euler(-160f, 0, -40f), k);
                    armR.localRotation = Quaternion.Slerp(armR.localRotation, Quaternion.Euler(-160f, 0, 40f), k);
                    return false;
                default: // Idle: breathing + looking around
                {
                    float t = Time.time;
                    legL.localRotation = Quaternion.Slerp(legL.localRotation, Quaternion.Euler(0, 0, -4f), k);
                    legR.localRotation = Quaternion.Slerp(legR.localRotation, Quaternion.Euler(0, 0, 4f), k);
                    armL.localRotation = Quaternion.Slerp(armL.localRotation, Quaternion.Euler(Mathf.Sin(t * 1.5f) * 4f, 0, -10f), k);
                    armR.localRotation = Quaternion.Slerp(armR.localRotation, Quaternion.Euler(-Mathf.Sin(t * 1.5f) * 4f, 0, 35f), k); // hand on cutlass
                    torso.localRotation = Quaternion.Slerp(torso.localRotation, Quaternion.Euler(Mathf.Sin(t * 2f) * 1.5f, 0, 0), k);
                    if (head != null) head.localRotation = Quaternion.Euler(0, Mathf.Sin(t * 0.6f) * 25f, 0);
                    hips.localPosition = hipsBase + new Vector3(0, Mathf.Sin(t * 2f) * 0.01f, 0);
                    break;
                }
            }
            if (pose != PlayerPose.Idle && head != null) head.localRotation = Quaternion.Slerp(head.localRotation, Quaternion.identity, k);
            // Slide: lean the whole body back and lower it
            model.localRotation = X(-62f * slideBlend);
            model.localPosition = new Vector3(0, -0.25f * slideBlend, 0);
            return step;
        }
    }
}
