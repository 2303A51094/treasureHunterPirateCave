using UnityEngine;

namespace TreasureHunt
{
    /// <summary>Persistent data (high score, wallet, settings) stored in PlayerPrefs.</summary>
    public static class SaveSystem
    {
        /// <summary>Key prefix; tests switch it so they never touch real player data.</summary>
        public static string Prefix = "THPC_";

        static string K(string k) { return Prefix + k; }
        static int GetI(string k, int d) { return PlayerPrefs.GetInt(K(k), d); }
        static void SetI(string k, int v) { PlayerPrefs.SetInt(K(k), v); }

        public static int BestScore { get { return GetI("Best", 0); } set { SetI("Best", Mathf.Max(0, value)); } }
        public static int Coins { get { return GetI("Coins", 0); } set { SetI("Coins", Mathf.Max(0, value)); } }
        public static int Gems { get { return GetI("Gems", 0); } set { SetI("Gems", Mathf.Max(0, value)); } }
        public static int Keys { get { return GetI("Keys", 0); } set { SetI("Keys", Mathf.Max(0, value)); } }
        public static int RunsPlayed { get { return GetI("Runs", 0); } set { SetI("Runs", value); } }
        public static bool SoundOn { get { return GetI("Sound", 1) == 1; } set { SetI("Sound", value ? 1 : 0); } }
        public static bool MusicOn { get { return GetI("Music", 1) == 1; } set { SetI("Music", value ? 1 : 0); } }
        public static float Sensitivity
        {
            get { return PlayerPrefs.GetFloat(K("Sens"), 1f); }
            set { PlayerPrefs.SetFloat(K("Sens"), Mathf.Clamp(value, 0.5f, 2f)); }
        }

        /// <summary>Stores the score if it beats the best. Returns true on a new record.</summary>
        public static bool SubmitScore(int score)
        {
            if (score <= BestScore) return false;
            BestScore = score;
            return true;
        }

        public static void AddCoins(int n) { if (n > 0) Coins = Coins + n; }
        public static void AddGems(int n) { if (n > 0) Gems = Gems + n; }
        public static void AddKeys(int n) { if (n > 0) Keys = Keys + n; }

        public static bool TrySpendGems(int n)
        {
            if (n < 0 || Gems < n) return false;
            Gems = Gems - n;
            return true;
        }

        public static bool TrySpendKey()
        {
            if (Keys <= 0) return false;
            Keys = Keys - 1;
            return true;
        }

        public static void Save() { PlayerPrefs.Save(); }

        public static void DeleteAll()
        {
            string[] keys = { "Best", "Coins", "Gems", "Keys", "Runs", "Sound", "Music", "Sens" };
            for (int i = 0; i < keys.Length; i++) PlayerPrefs.DeleteKey(K(keys[i]));
        }
    }
}
