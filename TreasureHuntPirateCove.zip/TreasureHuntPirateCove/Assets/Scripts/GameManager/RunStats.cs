namespace TreasureHunt
{
    /// <summary>Per-run counters shown in the HUD and on the Game Over screen.</summary>
    public class RunStats
    {
        public float distance;
        public double score;
        public int coins, gems, keys, chests, artifacts;

        public int Score { get { return (int)score; } }
        public int Distance { get { return (int)distance; } }

        public void Reset()
        {
            distance = 0; score = 0;
            coins = gems = keys = chests = artifacts = 0;
        }
    }
}
