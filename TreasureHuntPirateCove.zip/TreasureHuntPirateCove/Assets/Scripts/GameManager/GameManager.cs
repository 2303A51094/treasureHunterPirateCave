using System;
using System.Collections;
using UnityEngine;

namespace TreasureHunt
{
    public enum GameState { Menu, Playing, Paused, Dying, GameOver }

    /// <summary>
    /// Game state machine and rules: speed ramp, scoring, collection, hits, death, revive, pause and persistence.
    /// All transitions go through this class, so pause/retry/home always reset or keep the correct state.
    /// </summary>
    public class GameManager : MonoBehaviour
    {
        public static GameManager Instance { get; private set; }

        public GameConfig config;
        public PlayerController player;
        public TrackGenerator track;
        public PowerUpManager powerUps;
        public UIManager ui;
        public CameraFollow cameraFollow;
        public AtmosphereController atmosphere;
        public InputAdapter input;

        public readonly RunStats Stats = new RunStats();
        public GameState State { get; private set; }
        public float BaseSpeed { get; private set; }
        public float CurrentSpeed { get; private set; }
        public int RevivesUsed { get; private set; }
        public bool LastRunWasRecord { get; private set; }
        public ThemeId CurrentTheme { get; private set; }

        public event Action<GameState> StateChanged;
        public event Action<ThemeId> ThemeEntered;
        public event Action<string, Color> Toast;

        float runTime;
        bool deathHandled;
        Coroutine deathRoutine;

        void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
        }

        void OnDestroy() { if (Instance == this) Instance = null; }

        /// <summary>Called once by Bootstrap after every system is created.</summary>
        public void Init()
        {
            if (powerUps != null)
            {
                powerUps.Activated += OnPowerUpActivated;
                powerUps.Expired += OnPowerUpExpired;
            }
            GoToMenu();
        }

        void SetState(GameState s)
        {
            State = s;
            Time.timeScale = s == GameState.Paused ? 0f : 1f;
            if (StateChanged != null) StateChanged(s);
        }

        void ResetWorld()
        {
            if (deathRoutine != null) { StopCoroutine(deathRoutine); deathRoutine = null; }
            Time.timeScale = 1f;
            deathHandled = false;
            runTime = 0f;
            RevivesUsed = 0;
            LastRunWasRecord = false;
            BaseSpeed = CurrentSpeed = config.startSpeed;
            Stats.Reset();
            powerUps.ResetAll();
            player.ResetPlayer();
            track.ResetTrack(Environment.TickCount);
            CurrentTheme = ThemeId.TropicalIsland;
            if (atmosphere != null) atmosphere.SetTheme(CurrentTheme, true);
            Physics.SyncTransforms(); // ground colliders spawned this frame are visible to the first ground probe
        }

        // ------------------------------------------------------------ transitions
        public void GoToMenu()
        {
            ResetWorld();
            if (cameraFollow != null) cameraFollow.SetMenuMode(true);
            if (AudioManager.Instance != null) AudioManager.Instance.PlayMusic();
            SetState(GameState.Menu);
        }

        public void StartRun()
        {
            ResetWorld();
            SaveSystem.RunsPlayed = SaveSystem.RunsPlayed + 1;
            if (cameraFollow != null) { cameraFollow.SetMenuMode(false); }
            if (AudioManager.Instance != null) { AudioManager.Instance.PlayMusic(); AudioManager.Instance.SetMusicPaused(false); }
            SetState(GameState.Playing);
            if (ThemeEntered != null) ThemeEntered(CurrentTheme);
        }

        public void Pause()
        {
            if (State != GameState.Playing) return;
            SetState(GameState.Paused);
            if (AudioManager.Instance != null) AudioManager.Instance.SetMusicPaused(true);
            SaveSystem.Save();
        }

        public void Resume()
        {
            if (State != GameState.Paused) return;
            SetState(GameState.Playing);
            if (AudioManager.Instance != null) AudioManager.Instance.SetMusicPaused(false);
        }

        public void TogglePause()
        {
            if (State == GameState.Playing) Pause();
            else if (State == GameState.Paused) Resume();
        }

        void OnApplicationPause(bool paused)
        {
            if (paused) { Pause(); SaveSystem.Save(); }
        }

        void OnApplicationQuit() { SaveSystem.Save(); }

        // ------------------------------------------------------------ per frame
        void Update()
        {
            if (input != null && input.PausePressed) TogglePause();
            if (State != GameState.Playing) return;

            float dt = Time.deltaTime;
            runTime += dt;
            BaseSpeed = Mathf.Min(config.maxSpeed, config.startSpeed + config.acceleration * runTime);
            CurrentSpeed = BaseSpeed * powerUps.SpeedMultiplier;

            float newDist = Mathf.Max(Stats.distance, player.Z);
            float delta = newDist - Stats.distance;
            Stats.distance = newDist;
            Stats.score += delta * config.pointsPerMeter * powerUps.ScoreMultiplier;

            ThemeId t = track.ThemeAt(player.Z);
            if (t != CurrentTheme)
            {
                CurrentTheme = t;
                if (atmosphere != null) atmosphere.SetTheme(t, false);
                if (ThemeEntered != null) ThemeEntered(t);
            }
        }

        void AddScore(int points) { Stats.score += points * powerUps.ScoreMultiplier; }

        void ShowToast(string msg, Color c) { if (Toast != null) Toast(msg, c); }

        // ------------------------------------------------------------ collection
        public void Collect(Collectible c)
        {
            if (c == null || c.collected || State != GameState.Playing) return;
            c.Hide();
            Vector3 p = c.transform.position + Vector3.up * 0.4f;
            FxManager fx = FxManager.Instance;
            AudioManager au = AudioManager.Instance;
            switch (c.type)
            {
                case CollectibleType.Coin:
                    Stats.coins++;
                    SaveSystem.AddCoins(1);
                    AddScore(config.coinScore);
                    if (fx != null) fx.Sparkle(p, new Color(1f, 0.85f, 0.3f), 8);
                    if (au != null) au.Play(Sfx.Coin, 0.5f);
                    break;
                case CollectibleType.Gem:
                    Stats.gems++;
                    SaveSystem.AddGems(1);
                    AddScore(config.gemScore);
                    if (fx != null) fx.Sparkle(p, new Color(0.4f, 0.7f, 1f), 18);
                    if (au != null) au.Play(Sfx.Gem, 0.6f);
                    break;
                case CollectibleType.Key:
                    Stats.keys++;
                    SaveSystem.AddKeys(1);
                    AddScore(config.keyScore);
                    if (fx != null) fx.Sparkle(p, new Color(1f, 0.9f, 0.4f), 20);
                    if (au != null) au.Play(Sfx.Key, 0.7f);
                    ShowToast("Treasure Key!", new Color(1f, 0.85f, 0.3f));
                    break;
                case CollectibleType.Chest:
                {
                    bool usedKey = SaveSystem.TrySpendKey();
                    int reward = usedKey ? config.chestCoinsWithKey : config.chestCoins;
                    Stats.chests++;
                    Stats.coins += reward;
                    SaveSystem.AddCoins(reward);
                    AddScore(config.chestScore);
                    if (fx != null) { fx.Sparkle(p, new Color(1f, 0.8f, 0.2f), 40); fx.Sparkle(p, Color.white, 15); }
                    if (au != null) au.Play(Sfx.Chest, 0.8f);
                    ShowToast(usedKey ? "Chest unlocked! +" + reward + " coins" : "Treasure chest! +" + reward + " coins", new Color(1f, 0.82f, 0.3f));
                    break;
                }
                case CollectibleType.Artifact:
                    Stats.artifacts++;
                    Stats.coins += config.artifactCoins;
                    Stats.gems += config.artifactGems;
                    SaveSystem.AddCoins(config.artifactCoins);
                    SaveSystem.AddGems(config.artifactGems);
                    AddScore(config.artifactScore);
                    if (fx != null) { fx.Sparkle(p, new Color(1f, 0.9f, 0.4f), 50); fx.Sparkle(p, new Color(0.4f, 0.8f, 1f), 20); }
                    if (au != null) au.Play(Sfx.Artifact, 0.9f);
                    if (cameraFollow != null) cameraFollow.Shake(0.05f, 0.2f);
                    ShowToast("GOLDEN ARTIFACT! +" + config.artifactCoins + " coins, +" + config.artifactGems + " gems", new Color(1f, 0.9f, 0.35f));
                    break;
                case CollectibleType.PowerUp:
                    if (fx != null) fx.Sparkle(p, Color.white, 24);
                    if (c.powerUp == PowerUpType.TreasureBonus)
                    {
                        Stats.coins += config.treasureBonusCoins;
                        SaveSystem.AddCoins(config.treasureBonusCoins);
                        AddScore(config.treasureBonusScore);
                        if (au != null) au.Play(Sfx.Chest, 0.8f);
                        ShowToast("Treasure Bonus! +" + config.treasureBonusCoins + " coins", new Color(1f, 0.75f, 0.25f));
                    }
                    else
                    {
                        powerUps.Activate(c.powerUp);
                        if (au != null) au.Play(c.powerUp == PowerUpType.Shield ? Sfx.Shield : Sfx.PowerUp, 0.8f);
                    }
                    break;
            }
        }

        static string PowerUpName(PowerUpType t)
        {
            switch (t)
            {
                case PowerUpType.Magnet: return "Coin Magnet";
                case PowerUpType.Shield: return "Shield";
                case PowerUpType.SpeedBoost: return "Speed Boost";
                case PowerUpType.ScoreMultiplier: return "Score x2";
                case PowerUpType.TreasureDetector: return "Treasure Detector";
                default: return "Treasure Bonus";
            }
        }

        void OnPowerUpActivated(PowerUpType t) { ShowToast(PowerUpName(t) + "!", new Color(0.6f, 0.95f, 1f)); }
        void OnPowerUpExpired(PowerUpType t) { }

        // ------------------------------------------------------------ hits & death
        public void ReportObstacleHit(Obstacle o)
        {
            if (o == null || o.consumed || State != GameState.Playing || deathHandled) return;
            if (player.IsInvulnerable) { o.Smash(true); return; }
            if (powerUps.SpeedBoostActive)
            {
                o.Smash(true);
                if (AudioManager.Instance != null) AudioManager.Instance.Play(o.explodes ? Sfx.Explosion : Sfx.Hit, 0.6f);
                if (cameraFollow != null) cameraFollow.Shake(0.12f, 0.15f);
                return;
            }
            if (powerUps.ConsumeShield())
            {
                o.Smash(true);
                player.GrantInvulnerability(1.2f);
                if (AudioManager.Instance != null) AudioManager.Instance.Play(Sfx.Shield, 0.9f, 0.7f);
                if (cameraFollow != null) cameraFollow.Shake(0.15f, 0.2f);
                ShowToast("Shield saved you!", new Color(0.4f, 0.75f, 1f));
                return;
            }
            o.consumed = true;
            if (o.explodes) { if (FxManager.Instance != null) FxManager.Instance.Explosion(o.transform.position + Vector3.up); }
            BeginDeath(DeathCause.Obstacle, o.explodes);
        }

        public void ReportFall()
        {
            if (State != GameState.Playing || deathHandled) return;
            if (FxManager.Instance != null) FxManager.Instance.Splash(player.transform.position + Vector3.up * 0.5f);
            BeginDeath(DeathCause.Fall, false);
        }

        void BeginDeath(DeathCause cause, bool explosion)
        {
            deathHandled = true;   // guarantees a single game-over per death
            player.Kill();
            SetState(GameState.Dying);
            AudioManager au = AudioManager.Instance;
            if (au != null)
            {
                au.Play(cause == DeathCause.Fall ? Sfx.Splash : (explosion ? Sfx.Explosion : Sfx.Hit), 0.9f);
                au.PlayGameOverMusic();
            }
            if (cameraFollow != null) cameraFollow.Shake(explosion ? 0.4f : 0.25f, 0.4f);
            deathRoutine = StartCoroutine(DeathSequence());
        }

        IEnumerator DeathSequence()
        {
            yield return new WaitForSecondsRealtime(1.1f);
            deathRoutine = null;
            LastRunWasRecord = SaveSystem.SubmitScore(Stats.Score);
            SaveSystem.Save();
            SetState(GameState.GameOver);
        }

        // ------------------------------------------------------------ revive
        public int ReviveCost
        {
            get { return config.reviveCostDoubles ? config.reviveGemCost * (1 << Mathf.Min(RevivesUsed, 10)) : config.reviveGemCost; }
        }

        public bool RevivesRemaining { get { return RevivesUsed < config.maxRevivesPerRun; } }
        public bool CanRevive { get { return State == GameState.GameOver && RevivesRemaining && SaveSystem.Gems >= ReviveCost; } }

        /// <summary>Spends gems, clears nearby hazards, restores a safe running state and resumes the run.</summary>
        public bool Revive()
        {
            if (!CanRevive) return false;
            if (!SaveSystem.TrySpendGems(ReviveCost)) return false;
            RevivesUsed++;
            SaveSystem.Save();
            float z = player.Z;
            track.ClearForRevive(z, 8f, 60f);
            player.Revive(config.reviveInvulnerability);
            Physics.SyncTransforms(); // rescue platform must be solid on the very next frame
            runTime = Mathf.Max(0f, runTime - 8f); // ease the pace slightly
            deathHandled = false;
            if (AudioManager.Instance != null) { AudioManager.Instance.Play(Sfx.Revive, 0.9f); AudioManager.Instance.PlayMusic(); }
            if (FxManager.Instance != null) FxManager.Instance.Sparkle(player.transform.position + Vector3.up, new Color(0.5f, 0.8f, 1f), 40);
            SetState(GameState.Playing);
            ShowToast("Revived!", new Color(0.5f, 0.9f, 1f));
            return true;
        }
    }
}
