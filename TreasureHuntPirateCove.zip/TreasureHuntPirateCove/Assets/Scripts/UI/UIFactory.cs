using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace TreasureHunt
{
    /// <summary>Builds uGUI elements in the pirate style (weathered wood, parchment, gold trim).</summary>
    public static class UIFactory
    {
        public static readonly Color Gold = new Color(1f, 0.82f, 0.3f);
        public static readonly Color DarkGold = new Color(0.55f, 0.36f, 0.08f);
        public static readonly Color Ink = new Color(0.24f, 0.13f, 0.05f);
        public static readonly Color Cream = new Color(1f, 0.95f, 0.82f);

        static Font font;
        public static Font Font
        {
            get
            {
                if (font != null) return font;
#if UNITY_2022_2_OR_NEWER
                font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
                font = Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
                return font;
            }
        }

        public static RectTransform Rect(string name, Transform parent, Vector2 anchor, Vector2 pos, Vector2 size)
        {
            GameObject go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(parent, false);
            RectTransform rt = (RectTransform)go.transform;
            rt.anchorMin = rt.anchorMax = anchor;
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = pos;
            rt.sizeDelta = size;
            return rt;
        }

        public static RectTransform Stretch(string name, Transform parent)
        {
            GameObject go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(parent, false);
            RectTransform rt = (RectTransform)go.transform;
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = rt.offsetMax = Vector2.zero;
            return rt;
        }

        public static Image Img(RectTransform rt, Sprite sprite, Color color)
        {
            Image img = rt.gameObject.AddComponent<Image>();
            img.sprite = sprite;
            img.color = color;
            return img;
        }

        public static void Trim(GameObject go, Color c, float size)
        {
            Outline o = go.AddComponent<Outline>();
            o.effectColor = c;
            o.effectDistance = new Vector2(size, -size);
        }

        public static Image WoodPanel(string name, Transform parent, Vector2 anchor, Vector2 pos, Vector2 size)
        {
            Image img = Img(Rect(name, parent, anchor, pos, size), TextureFactory.SpriteFor(TextureFactory.UIWood()), new Color(0.95f, 0.9f, 0.85f, 0.97f));
            Trim(img.gameObject, Gold, 4);
            return img;
        }

        public static Image ParchmentPanel(string name, Transform parent, Vector2 anchor, Vector2 pos, Vector2 size)
        {
            Image img = Img(Rect(name, parent, anchor, pos, size), TextureFactory.SpriteFor(TextureFactory.UIParchment()), Color.white);
            Trim(img.gameObject, DarkGold, 5);
            return img;
        }

        public static Text Label(string name, Transform parent, string text, int size, Color color, TextAnchor align, Vector2 anchor, Vector2 pos, Vector2 box, bool outline = true)
        {
            RectTransform rt = Rect(name, parent, anchor, pos, box);
            Text t = rt.gameObject.AddComponent<Text>();
            t.font = Font;
            t.text = text;
            t.fontSize = size;
            t.fontStyle = FontStyle.Bold;
            t.color = color;
            t.alignment = align;
            t.horizontalOverflow = HorizontalWrapMode.Overflow;
            t.verticalOverflow = VerticalWrapMode.Overflow;
            t.raycastTarget = false;
            if (outline) Trim(rt.gameObject, new Color(0.12f, 0.06f, 0.02f, 0.9f), 3);
            return t;
        }

        public static Button Button(string name, Transform parent, string label, Vector2 anchor, Vector2 pos, Vector2 size, Color tint, UnityAction onClick, int fontSize = 44)
        {
            RectTransform rt = Rect(name, parent, anchor, pos, size);
            Image img = Img(rt, TextureFactory.SpriteFor(TextureFactory.UIWood()), tint);
            Trim(rt.gameObject, Gold, 4);
            Button b = rt.gameObject.AddComponent<Button>();
            b.targetGraphic = img;
            ColorBlock cb = b.colors;
            cb.highlightedColor = new Color(1.1f, 1.1f, 1.1f);
            cb.pressedColor = new Color(0.75f, 0.75f, 0.75f);
            cb.disabledColor = new Color(0.45f, 0.45f, 0.45f, 0.8f);
            b.colors = cb;
            Label("Label", rt, label, fontSize, Cream, TextAnchor.MiddleCenter, new Vector2(0.5f, 0.5f), Vector2.zero, size);
            b.onClick.AddListener(() => { if (AudioManager.Instance != null) AudioManager.Instance.Play(Sfx.Button, 0.6f); });
            if (onClick != null) b.onClick.AddListener(onClick);
            return b;
        }

        public static Text ButtonLabel(Button b) { return b.GetComponentInChildren<Text>(); }

        public static Image Icon(string name, Transform parent, string icon, Vector2 anchor, Vector2 pos, float size)
        {
            Image img = Img(Rect(name, parent, anchor, pos, new Vector2(size, size)), TextureFactory.Icon(icon), Color.white);
            img.raycastTarget = false;
            img.preserveAspect = true;
            return img;
        }
    }
}
