using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace TreasureHunt
{
    /// <summary>
    /// Builds and drives every screen: Main Menu, HUD, Pause, Game Over and Settings.
    /// All button listeners are added exactly once at build time (no duplicate subscriptions).
    /// HUD text only changes when a value changes, avoiding per-frame string allocations.
    /// </summary>
    public class UIManager : MonoBehaviour
    {
        GameManager gm;
        RectTransform canvasRoot;
        GameObject menu, hud, pause, gameOver, settings;

        Text menuBest, menuCoins, menuGems, menuKeys, menuSound;
        Text hudScore, hudDistance, hudCoins, hudGems, hudKeys, hudMult;
        Text toast, banner;
        CanvasGroup toastGroup, bannerGroup;
        float toastTime, bannerTime;
        Text pauseSound;
        Text goScore, goBest, goCoins, goGems, goNewBest, reviveLabel, goWallet;
        Button reviveButton;
        Text setSound, setMusic, setSens;
        Slider sensSlider;
        InputAdapter input;

        class Slot { public GameObject root; public RectTransform bar; public PowerUpType type; }
        readonly List<Slot> slots = new List<Slot>();

        int lastScore = -1, lastDist = -1, lastCoins = -1, lastGems = -1, lastKeys = -1;
        bool lastMult;

        static readonly Vector2 C = new Vector2(0.5f, 0.5f), TL = new Vector2(0, 1), TR = new Vector2(1, 1), TC = new Vector2(0.5f, 1), BL = new Vector2(0, 0), BC = new Vector2(0.5f, 0);

        public void Build(GameManager manager, InputAdapter inputAdapter)
        {
            gm = manager;
            input = inputAdapter;
            Canvas canvas = gameObject.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 10;
            CanvasScaler scaler = gameObject.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
            scaler.matchWidthOrHeight = 0.5f;
            gameObject.AddComponent<GraphicRaycaster>();
            canvasRoot = (RectTransform)transform;

            BuildMenu();
            BuildHud();
            BuildPause();
            BuildGameOver();
            BuildSettings();

            gm.StateChanged += OnStateChanged;
            gm.ThemeEntered += OnThemeEntered;
            gm.Toast += ShowToast;
            OnStateChanged(gm.State);
        }

        void OnDestroy()
        {
            if (gm == null) return;
            gm.StateChanged -= OnStateChanged;
            gm.ThemeEntered -= OnThemeEntered;
            gm.Toast -= ShowToast;
        }

        GameObject MakeScreen(string name, bool dim)
        {
            RectTransform rt = UIFactory.Stretch(name, canvasRoot);
            if (dim)
            {
                Image d = rt.gameObject.AddComponent<Image>();
                d.color = new Color(0.02f, 0.03f, 0.06f, 0.6f);
            }
            return rt.gameObject;
        }

        // ------------------------------------------------------------------ Main menu
        void BuildMenu()
        {
            menu = MakeScreen("MainMenu", false);
            Transform m = menu.transform;
            Image shade = UIFactory.Img(UIFactory.Stretch("Vignette", m), null, new Color(0, 0, 0, 0.25f));
            shade.raycastTarget = false;

            UIFactory.Label("Title", m, "TREASURE HUNT", 132, UIFactory.Gold, TextAnchor.MiddleCenter, TC, new Vector2(0, -150), new Vector2(1400, 160));
            Text sub = UIFactory.Label("Subtitle", m, "— PIRATE COVE —", 58, UIFactory.Cream, TextAnchor.MiddleCenter, TC, new Vector2(0, -262), new Vector2(1000, 80));
            sub.gameObject.AddComponent<Shadow>().effectDistance = new Vector2(3, -3);

            Image panel = UIFactory.WoodPanel("MenuPanel", m, C, new Vector2(0, -120), new Vector2(560, 470));
            UIFactory.Button("PlayButton", panel.transform, "PLAY", C, new Vector2(0, 135), new Vector2(440, 130), new Color(0.55f, 0.95f, 0.45f), () => gm.StartRun(), 70);
            UIFactory.Button("SettingsButton", panel.transform, "SETTINGS", C, new Vector2(0, -15), new Vector2(440, 100), Color.white, () => ShowSettings(true), 46);
            Button sound = UIFactory.Button("SoundButton", panel.transform, "SOUND: ON", C, new Vector2(0, -145), new Vector2(440, 100), Color.white, ToggleSound, 46);
            menuSound = UIFactory.ButtonLabel(sound);

            Image best = UIFactory.ParchmentPanel("BestPanel", m, BL, new Vector2(230, 120), new Vector2(380, 150));
            UIFactory.Label("BestLabel", best.transform, "BEST SCORE", 34, UIFactory.Ink, TextAnchor.MiddleCenter, C, new Vector2(0, 32), new Vector2(360, 50), false);
            menuBest = UIFactory.Label("BestValue", best.transform, "0", 54, UIFactory.DarkGold, TextAnchor.MiddleCenter, C, new Vector2(0, -25), new Vector2(360, 70), false);

            Image wallet = UIFactory.WoodPanel("Wallet", m, TR, new Vector2(-230, -90), new Vector2(400, 130));
            UIFactory.Icon("CoinIcon", wallet.transform, "coin", C, new Vector2(-150, 28), 50);
            menuCoins = UIFactory.Label("Coins", wallet.transform, "0", 40, UIFactory.Cream, TextAnchor.MiddleLeft, C, new Vector2(-30, 28), new Vector2(180, 50));
            UIFactory.Icon("GemIcon", wallet.transform, "gem", C, new Vector2(-150, -30), 50);
            menuGems = UIFactory.Label("Gems", wallet.transform, "0", 40, UIFactory.Cream, TextAnchor.MiddleLeft, C, new Vector2(-30, -30), new Vector2(180, 50));
            UIFactory.Icon("KeyIcon", wallet.transform, "key", C, new Vector2(70, -30), 50);
            menuKeys = UIFactory.Label("Keys", wallet.transform, "0", 40, UIFactory.Cream, TextAnchor.MiddleLeft, C, new Vector2(150, -30), new Vector2(100, 50));

            UIFactory.Label("Controls", m, "PC: A/D or Arrows = move   Space/Up = jump   S/Down = slide   Esc = pause      Mobile: swipe left/right/up/down",
                26, UIFactory.Cream, TextAnchor.MiddleCenter, BC, new Vector2(150, 45), new Vector2(1500, 40));
        }

        void RefreshMenu()
        {
            menuBest.text = SaveSystem.BestScore.ToString("00000");
            menuCoins.text = SaveSystem.Coins.ToString();
            menuGems.text = SaveSystem.Gems.ToString();
            menuKeys.text = SaveSystem.Keys.ToString();
            RefreshSoundLabels();
        }

        // ------------------------------------------------------------------ HUD
        void BuildHud()
        {
            hud = MakeScreen("HUD", false);
            Transform h = hud.transform;

            Image counters = UIFactory.WoodPanel("Counters", h, TL, new Vector2(170, -125), new Vector2(300, 210));
            string[] icons = { "coin", "gem", "key" };
            Text[] vals = new Text[3];
            for (int i = 0; i < 3; i++)
            {
                UIFactory.Icon(icons[i] + "Icon", counters.transform, icons[i], C, new Vector2(-95, 62 - i * 62), 52);
                vals[i] = UIFactory.Label(icons[i] + "Value", counters.transform, "0", 44, UIFactory.Cream, TextAnchor.MiddleLeft, C, new Vector2(35, 62 - i * 62), new Vector2(200, 56));
            }
            hudCoins = vals[0]; hudGems = vals[1]; hudKeys = vals[2];

            Image scorePanel = UIFactory.ParchmentPanel("ScorePanel", h, TC, new Vector2(0, -85), new Vector2(420, 140));
            UIFactory.Icon("StarIcon", scorePanel.transform, "star", C, new Vector2(-160, 18), 54);
            hudScore = UIFactory.Label("Score", scorePanel.transform, "00000", 64, UIFactory.DarkGold, TextAnchor.MiddleCenter, C, new Vector2(20, 18), new Vector2(320, 80), false);
            hudDistance = UIFactory.Label("Distance", scorePanel.transform, "0 m", 34, UIFactory.Ink, TextAnchor.MiddleCenter, C, new Vector2(0, -42), new Vector2(380, 44), false);
            hudMult = UIFactory.Label("Multiplier", h, "x2", 52, new Color(0.85f, 0.5f, 1f), TextAnchor.MiddleLeft, TC, new Vector2(270, -85), new Vector2(120, 70));
            hudMult.gameObject.SetActive(false);

            Button pb = UIFactory.Button("PauseButton", h, "", TR, new Vector2(-90, -90), new Vector2(120, 120), Color.white, () => gm.Pause());
            UIFactory.Icon("PauseIcon", pb.transform, "pause", C, Vector2.zero, 80);

            // Power-up indicators
            RectTransform row = UIFactory.Rect("PowerUps", h, BL, new Vector2(420, 90), new Vector2(760, 120));
            HorizontalLayoutGroup lg = row.gameObject.AddComponent<HorizontalLayoutGroup>();
            lg.spacing = 14;
            lg.childAlignment = TextAnchor.MiddleLeft;
            lg.childControlWidth = lg.childControlHeight = false;
            lg.childForceExpandWidth = lg.childForceExpandHeight = false;
            string[] ids = { "magnet", "shield", "speed", "multiplier", "detector" };
            for (int i = 0; i < PowerUpTimers.TimedCount; i++)
            {
                Slot s = new Slot();
                s.type = (PowerUpType)i;
                Image bg = UIFactory.WoodPanel("Slot_" + s.type, row, C, Vector2.zero, new Vector2(110, 110));
                UIFactory.Icon("Icon", bg.transform, ids[i], C, new Vector2(0, 8), 72);
                RectTransform barBg = UIFactory.Rect("BarBg", bg.transform, C, new Vector2(0, -44), new Vector2(90, 12));
                UIFactory.Img(barBg, null, new Color(0, 0, 0, 0.6f));
                RectTransform bar = UIFactory.Rect("Bar", barBg, new Vector2(0, 0.5f), Vector2.zero, new Vector2(90, 12));
                bar.pivot = new Vector2(0, 0.5f);
                UIFactory.Img(bar, null, UIFactory.Gold);
                s.root = bg.gameObject;
                s.bar = bar;
                s.root.SetActive(false);
                slots.Add(s);
            }

            toast = UIFactory.Label("Toast", h, "", 50, UIFactory.Gold, TextAnchor.MiddleCenter, C, new Vector2(0, 230), new Vector2(1400, 80));
            toastGroup = toast.gameObject.AddComponent<CanvasGroup>();
            toastGroup.alpha = 0;

            Image bannerBg = UIFactory.ParchmentPanel("Banner", h, C, new Vector2(0, 340), new Vector2(760, 110));
            bannerBg.raycastTarget = false;
            banner = UIFactory.Label("BannerText", bannerBg.transform, "", 50, UIFactory.Ink, TextAnchor.MiddleCenter, C, Vector2.zero, new Vector2(740, 100), false);
            bannerGroup = bannerBg.gameObject.AddComponent<CanvasGroup>();
            bannerGroup.alpha = 0;
            bannerGroup.blocksRaycasts = false;
        }

        void RefreshHud(bool force)
        {
            RunStats s = gm.Stats;
            if (force || s.Score != lastScore) { lastScore = s.Score; hudScore.text = lastScore.ToString("00000"); }
            if (force || s.Distance != lastDist) { lastDist = s.Distance; hudDistance.text = lastDist + " m"; }
            if (force || s.coins != lastCoins) { lastCoins = s.coins; hudCoins.text = lastCoins.ToString(); }
            if (force || s.gems != lastGems) { lastGems = s.gems; hudGems.text = lastGems.ToString(); }
            if (force || s.keys != lastKeys) { lastKeys = s.keys; hudKeys.text = lastKeys.ToString(); }
            bool mult = gm.powerUps.timers.IsActive(PowerUpType.ScoreMultiplier);
            if (force || mult != lastMult) { lastMult = mult; hudMult.gameObject.SetActive(mult); }
            for (int i = 0; i < slots.Count; i++)
            {
                Slot sl = slots[i];
                bool on = gm.powerUps.timers.IsActive(sl.type);
                if (sl.root.activeSelf != on) sl.root.SetActive(on);
                if (on) sl.bar.localScale = new Vector3(gm.powerUps.timers.Fraction(sl.type), 1, 1);
            }
        }

        public void ShowToast(string msg, Color c)
        {
            toast.text = msg;
            toast.color = c;
            toastTime = 1.8f;
        }

        void OnThemeEntered(ThemeId t)
        {
            banner.text = ThemeInfo.DisplayName(t);
            bannerTime = 2.5f;
        }

        // ------------------------------------------------------------------ Pause
        void BuildPause()
        {
            pause = MakeScreen("PauseMenu", true);
            Image p = UIFactory.ParchmentPanel("Panel", pause.transform, C, Vector2.zero, new Vector2(600, 660));
            UIFactory.Label("Title", p.transform, "PAUSED", 80, UIFactory.DarkGold, TextAnchor.MiddleCenter, C, new Vector2(0, 240), new Vector2(560, 100), false);
            UIFactory.Button("Resume", p.transform, "RESUME", C, new Vector2(0, 110), new Vector2(440, 100), new Color(0.55f, 0.95f, 0.45f), () => gm.Resume());
            UIFactory.Button("Restart", p.transform, "RESTART", C, new Vector2(0, -10), new Vector2(440, 100), Color.white, () => gm.StartRun());
            UIFactory.Button("Home", p.transform, "HOME", C, new Vector2(0, -130), new Vector2(440, 100), new Color(0.6f, 0.75f, 1f), () => gm.GoToMenu());
            pauseSound = UIFactory.ButtonLabel(UIFactory.Button("Sound", p.transform, "SOUND: ON", C, new Vector2(0, -250), new Vector2(440, 100), Color.white, ToggleSound));
        }

        // ------------------------------------------------------------------ Game over
        void BuildGameOver()
        {
            gameOver = MakeScreen("GameOver", true);
            Image p = UIFactory.WoodPanel("Panel", gameOver.transform, C, Vector2.zero, new Vector2(1060, 640));
            UIFactory.Label("Title", p.transform, "GAME OVER", 104, UIFactory.Gold, TextAnchor.MiddleCenter, C, new Vector2(-180, 225), new Vector2(700, 120));

            UIFactory.Label("ScoreLbl", p.transform, "SCORE", 36, new Color(0.9f, 0.75f, 0.5f), TextAnchor.MiddleCenter, C, new Vector2(-180, 120), new Vector2(500, 50));
            goScore = UIFactory.Label("Score", p.transform, "00000", 86, UIFactory.Cream, TextAnchor.MiddleCenter, C, new Vector2(-180, 55), new Vector2(500, 100));
            UIFactory.Label("BestLbl", p.transform, "BEST SCORE", 36, new Color(0.9f, 0.75f, 0.5f), TextAnchor.MiddleCenter, C, new Vector2(-180, -25), new Vector2(500, 50));
            goBest = UIFactory.Label("Best", p.transform, "00000", 70, UIFactory.Gold, TextAnchor.MiddleCenter, C, new Vector2(-180, -85), new Vector2(500, 90));
            goNewBest = UIFactory.Label("NewBest", p.transform, "NEW BEST!", 44, new Color(0.5f, 1f, 0.5f), TextAnchor.MiddleCenter, C, new Vector2(110, -85), new Vector2(260, 60));
            goNewBest.gameObject.AddComponent<Pulse>().amount = 0.08f;

            UIFactory.Icon("CoinIcon", p.transform, "coin", C, new Vector2(-380, -180), 56);
            goCoins = UIFactory.Label("Coins", p.transform, "0", 48, UIFactory.Cream, TextAnchor.MiddleLeft, C, new Vector2(-250, -180), new Vector2(200, 60));
            UIFactory.Icon("GemIcon", p.transform, "gem", C, new Vector2(-120, -180), 56);
            goGems = UIFactory.Label("Gems", p.transform, "0", 48, UIFactory.Cream, TextAnchor.MiddleLeft, C, new Vector2(10, -180), new Vector2(200, 60));
            goWallet = UIFactory.Label("Wallet", p.transform, "", 28, new Color(0.9f, 0.8f, 0.6f), TextAnchor.MiddleCenter, C, new Vector2(-180, -250), new Vector2(700, 40));

            reviveButton = UIFactory.Button("Revive", p.transform, "REVIVE", C, new Vector2(320, 140), new Vector2(330, 120), new Color(0.5f, 0.95f, 0.45f), OnReviveClicked, 44);
            reviveLabel = UIFactory.ButtonLabel(reviveButton);
            UIFactory.Button("Home", p.transform, "HOME", C, new Vector2(320, -5), new Vector2(330, 110), new Color(0.5f, 0.7f, 1f), () => gm.GoToMenu(), 50);
            UIFactory.Button("Retry", p.transform, "RETRY", C, new Vector2(320, -145), new Vector2(330, 110), new Color(1f, 0.5f, 0.42f), () => gm.StartRun(), 50);
        }

        void OnReviveClicked()
        {
            if (!gm.Revive()) RefreshGameOver(); // not enough gems: just refresh the explanation
        }

        void RefreshGameOver()
        {
            RunStats s = gm.Stats;
            goScore.text = s.Score.ToString("00000");
            goBest.text = SaveSystem.BestScore.ToString("00000");
            goCoins.text = s.coins.ToString();
            goGems.text = s.gems.ToString();
            goNewBest.gameObject.SetActive(gm.LastRunWasRecord);
            goWallet.text = "Treasury: " + SaveSystem.Coins + " coins  |  " + SaveSystem.Gems + " gems  |  " + SaveSystem.Keys + " keys";
            int cost = gm.ReviveCost;
            if (!gm.RevivesRemaining) { reviveLabel.text = "NO REVIVES\nLEFT"; reviveLabel.fontSize = 34; }
            else if (SaveSystem.Gems < cost) { reviveLabel.text = "REVIVE\nneed " + cost + " gems"; reviveLabel.fontSize = 34; }
            else { reviveLabel.text = "REVIVE\n" + cost + " gems"; reviveLabel.fontSize = 40; }
            reviveButton.interactable = gm.CanRevive;
        }

        // ------------------------------------------------------------------ Settings
        void BuildSettings()
        {
            settings = MakeScreen("Settings", true);
            Image p = UIFactory.ParchmentPanel("Panel", settings.transform, C, Vector2.zero, new Vector2(700, 680));
            UIFactory.Label("Title", p.transform, "SETTINGS", 76, UIFactory.DarkGold, TextAnchor.MiddleCenter, C, new Vector2(0, 250), new Vector2(600, 100), false);
            setSound = UIFactory.ButtonLabel(UIFactory.Button("Sound", p.transform, "SOUND: ON", C, new Vector2(0, 130), new Vector2(480, 100), Color.white, ToggleSound));
            setMusic = UIFactory.ButtonLabel(UIFactory.Button("Music", p.transform, "MUSIC: ON", C, new Vector2(0, 10), new Vector2(480, 100), Color.white, ToggleMusic));
            setSens = UIFactory.Label("SensLabel", p.transform, "SWIPE SENSITIVITY: 1.0", 34, UIFactory.Ink, TextAnchor.MiddleCenter, C, new Vector2(0, -85), new Vector2(600, 50), false);

            GameObject sliderGo = DefaultControls.CreateSlider(new DefaultControls.Resources());
            sliderGo.name = "SensitivitySlider";
            RectTransform srt = (RectTransform)sliderGo.transform;
            srt.SetParent(p.transform, false);
            srt.anchorMin = srt.anchorMax = C;
            srt.anchoredPosition = new Vector2(0, -145);
            srt.sizeDelta = new Vector2(480, 40);
            sensSlider = sliderGo.GetComponent<Slider>();
            sensSlider.minValue = 0.5f;
            sensSlider.maxValue = 2f;
            sensSlider.value = SaveSystem.Sensitivity;
            Image[] imgs = sliderGo.GetComponentsInChildren<Image>(true);
            for (int i = 0; i < imgs.Length; i++)
            {
                if (imgs[i].name == "Background") imgs[i].color = new Color(0.35f, 0.22f, 0.1f);
                else if (imgs[i].name == "Fill") imgs[i].color = UIFactory.Gold;
                else if (imgs[i].name == "Handle") { imgs[i].color = new Color(0.55f, 0.32f, 0.12f); imgs[i].rectTransform.sizeDelta = new Vector2(40, 0); }
            }
            sensSlider.onValueChanged.AddListener(OnSensitivityChanged);
            OnSensitivityChanged(sensSlider.value);

            UIFactory.Button("Back", p.transform, "BACK", C, new Vector2(0, -250), new Vector2(360, 100), new Color(0.6f, 0.75f, 1f), () => ShowSettings(false));
        }

        void OnSensitivityChanged(float v)
        {
            SaveSystem.Sensitivity = v;
            if (input != null) input.sensitivity = v;
            setSens.text = "SWIPE SENSITIVITY: " + v.ToString("0.0");
        }

        void ShowSettings(bool show)
        {
            settings.SetActive(show);
            menu.SetActive(!show && gm.State == GameState.Menu);
            if (!show) { SaveSystem.Save(); RefreshMenu(); }
            else RefreshSoundLabels();
        }

        // ------------------------------------------------------------------ toggles
        void ToggleSound()
        {
            if (AudioManager.Instance != null) AudioManager.Instance.SetSound(!AudioManager.Instance.SoundOn);
            else SaveSystem.SoundOn = !SaveSystem.SoundOn;
            SaveSystem.Save();
            RefreshSoundLabels();
        }

        void ToggleMusic()
        {
            if (AudioManager.Instance != null) AudioManager.Instance.SetMusic(!AudioManager.Instance.MusicOn);
            else SaveSystem.MusicOn = !SaveSystem.MusicOn;
            SaveSystem.Save();
            RefreshSoundLabels();
        }

        void RefreshSoundLabels()
        {
            string s = SaveSystem.SoundOn ? "SOUND: ON" : "SOUND: OFF";
            string m = SaveSystem.MusicOn ? "MUSIC: ON" : "MUSIC: OFF";
            if (menuSound != null) menuSound.text = s;
            if (pauseSound != null) pauseSound.text = s;
            if (setSound != null) setSound.text = s;
            if (setMusic != null) setMusic.text = m;
        }

        // ------------------------------------------------------------------ state & update
        void OnStateChanged(GameState s)
        {
            menu.SetActive(s == GameState.Menu);
            hud.SetActive(s == GameState.Playing || s == GameState.Paused || s == GameState.Dying);
            pause.SetActive(s == GameState.Paused);
            gameOver.SetActive(s == GameState.GameOver);
            settings.SetActive(false);
            if (s == GameState.Menu) RefreshMenu();
            if (s == GameState.Paused) RefreshSoundLabels();
            if (s == GameState.GameOver) RefreshGameOver();
            if (s == GameState.Playing) RefreshHud(true);
            if (s == GameState.Menu) { toastGroup.alpha = 0; bannerGroup.alpha = 0; toastTime = bannerTime = 0; }
        }

        void Update()
        {
            if (gm == null) return;
            if (hud.activeSelf) RefreshHud(false);
            float dt = Time.unscaledDeltaTime;
            if (toastTime > 0f) { toastTime -= dt; toastGroup.alpha = Mathf.Clamp01(toastTime / 0.4f); }
            if (bannerTime > 0f) { bannerTime -= dt; bannerGroup.alpha = Mathf.Clamp01(bannerTime / 0.5f) * Mathf.Clamp01((2.5f - bannerTime) / 0.3f); }
            if (gameOver.activeSelf && Time.frameCount % 15 == 0) reviveButton.interactable = gm.CanRevive;
        }
    }
}
