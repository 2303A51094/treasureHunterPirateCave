using UnityEngine;

namespace TreasureHunt
{
    public enum CollectibleType { Coin, Gem, Key, Chest, Artifact, PowerUp }

    /// <summary>Spinning, bobbing pickup. Coins are pulled in by the magnet; rare items glow under the detector.</summary>
    public class Collectible : MonoBehaviour, IPoolable
    {
        public CollectibleType type;
        public PowerUpType powerUp;
        public Transform visual;
        public GameObject highlight;
        public float spinSpeed = 160f;
        public float spawnHeight = 0.9f;
        [System.NonSerialized] public bool collected;

        Vector3 visualBase;
        bool baseCached, highlightOn;
        float phase;

        public bool IsRare { get { return type == CollectibleType.Gem || type == CollectibleType.Key || type == CollectibleType.Chest || type == CollectibleType.Artifact; } }

        public void OnSpawned()
        {
            collected = false;
            if (visual != null)
            {
                if (!baseCached) { visualBase = visual.localPosition; baseCached = true; }
                visual.localPosition = visualBase;
            }
            highlightOn = false;
            if (highlight != null) highlight.SetActive(false);
            phase = transform.position.z * 0.7f;
        }

        public void OnDespawned() { }

        void Update()
        {
            if (collected) return;
            float dt = Time.deltaTime;
            if (visual != null)
            {
                if (type != CollectibleType.Chest) visual.Rotate(Vector3.up, spinSpeed * dt, Space.World);
                Vector3 p = visualBase;
                p.y += Mathf.Sin(Time.time * 3f + phase) * 0.12f;
                visual.localPosition = p;
            }

            GameManager gm = GameManager.Instance;
            if (gm == null || gm.powerUps == null) return;

            if (highlight != null)
            {
                bool want = gm.powerUps.DetectorActive && IsRare;
                if (want != highlightOn) { highlightOn = want; highlight.SetActive(want); }
            }

            if (type == CollectibleType.Coin && gm.powerUps.MagnetActive && gm.State == GameState.Playing && gm.player != null)
            {
                Vector3 target = gm.player.transform.position + Vector3.up * 0.9f;
                Vector3 to = target - transform.position;
                float r = gm.powerUps.MagnetRadius;
                if (to.z < r && to.z > -2f && to.sqrMagnitude < r * r * 1.5f)
                {
                    float speed = gm.CurrentSpeed + 14f;
                    transform.position = Vector3.MoveTowards(transform.position, target, speed * dt);
                    if (to.sqrMagnitude < 0.64f) gm.Collect(this); // safety net in case the trigger is skipped
                }
            }
        }

        /// <summary>Hides the pickup; the pooled object is reclaimed with its chunk.</summary>
        public void Hide()
        {
            collected = true;
            gameObject.SetActive(false);
        }
    }
}
