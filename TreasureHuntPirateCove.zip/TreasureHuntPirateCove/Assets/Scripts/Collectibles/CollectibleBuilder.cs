using UnityEngine;

namespace TreasureHunt
{
    /// <summary>Builds pickups. Keys: col_Coin, col_Gem, col_Key, col_Chest, col_Artifact, pu_&lt;PowerUpType&gt;.</summary>
    public static class CollectibleBuilder
    {
        const PrimitiveType Cube = PrimitiveType.Cube, Cyl = PrimitiveType.Cylinder, Sph = PrimitiveType.Sphere;

        public static string Key(CollectibleType t) { return "col_" + t; }
        public static string Key(PowerUpType t) { return "pu_" + t; }

        static Collectible Base(string name, CollectibleType type, out Transform visual)
        {
            GameObject root = new GameObject(name);
            Collectible c = root.AddComponent<Collectible>();
            c.type = type;
            visual = Proc.Node("Visual", root.transform, Vector3.zero).transform;
            c.visual = visual;
            SphereCollider sc = root.AddComponent<SphereCollider>();
            sc.isTrigger = true;
            sc.radius = 0.6f;
            return c;
        }

        static void AddBeam(Collectible c)
        {
            GameObject beam = Proc.Part(Cyl, "Beam", c.transform, new Vector3(0, 4f, 0), new Vector3(0.35f, 4.5f, 0.35f), Vector3.zero, false, "DetectorBeam");
            beam.AddComponent<Pulse>().amount = 0.08f;
            beam.SetActive(false);
            c.highlight = beam;
        }

        public static GameObject Build(CollectibleType type)
        {
            Transform v;
            Collectible c = Base(Key(type), type, out v);
            switch (type)
            {
                case CollectibleType.Coin:
                    Proc.Part(Cyl, "Coin", v, Vector3.zero, new Vector3(0.62f, 0.05f, 0.62f), new Vector3(90, 0, 0), false);
                    Proc.Part(Cyl, "Gold", v, Vector3.zero, new Vector3(0.42f, 0.07f, 0.42f), new Vector3(90, 0, 0), false);
                    break;
                case CollectibleType.Gem:
                    Proc.Mesh(MeshFactory.Octahedron(), "Gem", v, Vector3.zero, new Vector3(0.5f, 0.75f, 0.5f), Vector3.zero, false, "Gem");
                    AddBeam(c);
                    break;
                case CollectibleType.Key:
                    Proc.Mesh(MeshFactory.Torus(0.17f, 0.05f), "GoldGlow", v, new Vector3(0, 0.25f, 0), Vector3.one, new Vector3(90, 0, 0), false, "Bow");
                    Proc.Part(Cyl, "GoldGlow", v, new Vector3(0, -0.12f, 0), new Vector3(0.07f, 0.28f, 0.07f), Vector3.zero, false);
                    Proc.Part(Cube, "GoldGlow", v, new Vector3(0.08f, -0.3f, 0), new Vector3(0.14f, 0.06f, 0.05f), Vector3.zero, false);
                    Proc.Part(Cube, "GoldGlow", v, new Vector3(0.08f, -0.18f, 0), new Vector3(0.1f, 0.05f, 0.05f), Vector3.zero, false);
                    AddBeam(c);
                    break;
                case CollectibleType.Chest:
                    c.spawnHeight = 0.0f;
                    Proc.Part(Cube, "ChestWood", v, new Vector3(0, 0.3f, 0), new Vector3(1.0f, 0.6f, 0.65f));
                    Proc.Part(Cyl, "ChestWood", v, new Vector3(0, 0.62f, 0), new Vector3(0.65f, 0.5f, 0.65f), new Vector3(0, 0, 90));
                    Proc.Part(Cube, "Gold", v, new Vector3(-0.32f, 0.45f, 0), new Vector3(0.08f, 0.95f, 0.68f));
                    Proc.Part(Cube, "Gold", v, new Vector3(0.32f, 0.45f, 0), new Vector3(0.08f, 0.95f, 0.68f));
                    Proc.Part(Cube, "GoldGlow", v, new Vector3(0, 0.5f, -0.34f), new Vector3(0.16f, 0.2f, 0.04f));
                    Proc.Part(Sph, "GoldGlow", v, new Vector3(0, 0.66f, 0), new Vector3(0.7f, 0.15f, 0.4f), Vector3.zero, false);
                    FxManager.MakeSystem("ChestSparkle", v, false, true, 12, 0.5f, 1f, 0.3f, 1f, 0.06f, 0.14f, new Color(1f, 0.85f, 0.3f), -0.2f, ParticleSystemShapeType.Sphere, 0.5f, 30).transform.localPosition = new Vector3(0, 0.7f, 0);
                    c.GetComponent<SphereCollider>().center = new Vector3(0, 0.5f, 0);
                    c.GetComponent<SphereCollider>().radius = 0.75f;
                    AddBeam(c);
                    break;
                case CollectibleType.Artifact:
                    Proc.Part(Cyl, "GoldGlow", v, new Vector3(0, -0.35f, 0), new Vector3(0.4f, 0.06f, 0.4f), Vector3.zero, false);
                    Proc.Part(Cyl, "GoldGlow", v, new Vector3(0, -0.08f, 0), new Vector3(0.26f, 0.22f, 0.22f), Vector3.zero, false);
                    Proc.Part(Sph, "GoldGlow", v, new Vector3(0, 0.25f, 0), new Vector3(0.3f, 0.32f, 0.3f), Vector3.zero, false);
                    Proc.Mesh(MeshFactory.Octahedron(), "Gem", v, new Vector3(0, 0.27f, 0.14f), new Vector3(0.1f, 0.12f, 0.06f), Vector3.zero, false, "Eye");
                    Proc.Mesh(MeshFactory.Cone(6), "GoldGlow", v, new Vector3(0, 0.38f, 0), new Vector3(0.32f, 0.3f, 0.32f), Vector3.zero, false, "Crown");
                    FxManager.MakeSystem("ArtifactSparkle", v, false, true, 18, 0.4f, 0.9f, 0.5f, 1.2f, 0.05f, 0.12f, new Color(1f, 0.9f, 0.4f), 0, ParticleSystemShapeType.Sphere, 0.4f, 40);
                    c.spinSpeed = 90f;
                    AddBeam(c);
                    break;
            }
            return c.gameObject;
        }

        public static GameObject Build(PowerUpType p)
        {
            Transform v;
            Collectible c = Base(Key(p), CollectibleType.PowerUp, out v);
            c.powerUp = p;
            c.spawnHeight = 1.1f;
            c.spinSpeed = 110f;
            GameObject bubble = Proc.Part(Sph, "PickupBubble", v, Vector3.zero, Vector3.one * 1.05f, Vector3.zero, false, "Bubble");
            bubble.AddComponent<Pulse>().amount = 0.05f;
            switch (p)
            {
                case PowerUpType.Magnet:
                    Proc.Part(Cube, "MagnetRed", v, new Vector3(-0.17f, 0.05f, 0), new Vector3(0.12f, 0.4f, 0.12f), Vector3.zero, false);
                    Proc.Part(Cube, "MagnetRed", v, new Vector3(0.17f, 0.05f, 0), new Vector3(0.12f, 0.4f, 0.12f), Vector3.zero, false);
                    Proc.Part(Cube, "MagnetRed", v, new Vector3(0, -0.18f, 0), new Vector3(0.46f, 0.12f, 0.12f), Vector3.zero, false);
                    Proc.Part(Cube, "Silver", v, new Vector3(-0.17f, 0.3f, 0), new Vector3(0.13f, 0.1f, 0.13f), Vector3.zero, false);
                    Proc.Part(Cube, "Silver", v, new Vector3(0.17f, 0.3f, 0), new Vector3(0.13f, 0.1f, 0.13f), Vector3.zero, false);
                    break;
                case PowerUpType.Shield:
                    Proc.Part(Cyl, "ShieldBlue", v, Vector3.zero, new Vector3(0.6f, 0.05f, 0.7f), new Vector3(90, 0, 0), false);
                    Proc.Part(Cyl, "Gold", v, new Vector3(0, 0, -0.02f), new Vector3(0.68f, 0.03f, 0.78f), new Vector3(90, 0, 0), false);
                    Proc.Part(Cube, "Gold", v, new Vector3(0, 0, -0.06f), new Vector3(0.08f, 0.5f, 0.03f), Vector3.zero, false);
                    break;
                case PowerUpType.SpeedBoost:
                    Proc.Part(Cube, "PirateBoots", v, new Vector3(0, -0.05f, 0), new Vector3(0.18f, 0.4f, 0.2f), Vector3.zero, false);
                    Proc.Part(Cube, "PirateBoots", v, new Vector3(0, -0.22f, 0.1f), new Vector3(0.18f, 0.12f, 0.38f), Vector3.zero, false);
                    Proc.Part(Sph, "SpeedGreen", v, new Vector3(-0.17f, 0.1f, -0.05f), new Vector3(0.08f, 0.3f, 0.2f), new Vector3(0, 0, 30), false);
                    Proc.Part(Sph, "SpeedGreen", v, new Vector3(0.17f, 0.1f, -0.05f), new Vector3(0.08f, 0.3f, 0.2f), new Vector3(0, 0, -30), false);
                    break;
                case PowerUpType.ScoreMultiplier:
                    Proc.Mesh(MeshFactory.Star(), "PurpleGlow", v, Vector3.zero, Vector3.one * 0.75f, Vector3.zero, false, "Star");
                    break;
                case PowerUpType.TreasureDetector:
                    Proc.Part(Cyl, "Gold", v, Vector3.zero, new Vector3(0.6f, 0.05f, 0.6f), new Vector3(90, 0, 0), false);
                    Proc.Part(Cyl, "Teal", v, new Vector3(0, 0, -0.03f), new Vector3(0.5f, 0.03f, 0.5f), new Vector3(90, 0, 0), false);
                    Proc.Mesh(MeshFactory.Octahedron(), "MagnetRed", v, new Vector3(0, 0.1f, -0.06f), new Vector3(0.08f, 0.32f, 0.03f), Vector3.zero, false, "Needle");
                    Proc.Mesh(MeshFactory.Octahedron(), "Silver", v, new Vector3(0, -0.1f, -0.06f), new Vector3(0.08f, 0.32f, 0.03f), Vector3.zero, false, "Needle2");
                    break;
                case PowerUpType.TreasureBonus:
                    Proc.Part(Cube, "ChestWood", v, new Vector3(0, -0.08f, 0), new Vector3(0.5f, 0.3f, 0.32f), Vector3.zero, false);
                    Proc.Part(Cube, "GoldGlow", v, new Vector3(0, 0.1f, 0), new Vector3(0.52f, 0.12f, 0.34f), Vector3.zero, false);
                    Proc.Part(Cyl, "Coin", v, new Vector3(0, 0.25f, 0), new Vector3(0.22f, 0.03f, 0.22f), new Vector3(90, 0, 0), false);
                    break;
            }
            return c.gameObject;
        }
    }
}
