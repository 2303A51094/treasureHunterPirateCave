using UnityEngine;

namespace TreasureHunt
{
    public enum PowerUpType { Magnet = 0, Shield = 1, SpeedBoost = 2, ScoreMultiplier = 3, TreasureDetector = 4, TreasureBonus = 5 }

    /// <summary>
    /// Pure power-up timing state (unit-tested).
    /// Stacking rules: collecting an active power-up refreshes it to full duration (no compounding);
    /// different power-ups run simultaneously; the shield holds one charge that blocks one hit.
    /// TreasureBonus is instant and never becomes active.
    /// </summary>
    public class PowerUpTimers
    {
        public const int TimedCount = 5;
        readonly float[] remaining = new float[TimedCount];
        readonly float[] duration = new float[TimedCount];

        public bool IsTimed(PowerUpType t) { return (int)t < TimedCount; }
        public bool IsActive(PowerUpType t) { return IsTimed(t) && remaining[(int)t] > 0f; }
        public float Remaining(PowerUpType t) { return IsTimed(t) ? remaining[(int)t] : 0f; }
        public float Fraction(PowerUpType t)
        {
            int i = (int)t;
            if (!IsTimed(t) || duration[i] <= 0f) return 0f;
            return Mathf.Clamp01(remaining[i] / duration[i]);
        }

        /// <summary>Activates or refreshes a timed power-up. Returns false for instant types.</summary>
        public bool Activate(PowerUpType t, float seconds)
        {
            if (!IsTimed(t) || seconds <= 0f) return false;
            int i = (int)t;
            duration[i] = seconds;
            remaining[i] = Mathf.Max(remaining[i], seconds);
            return true;
        }

        /// <summary>Advances time. Returns a bitmask of power-ups that expired during this tick.</summary>
        public int Tick(float dt)
        {
            int expired = 0;
            for (int i = 0; i < TimedCount; i++)
            {
                if (remaining[i] <= 0f) continue;
                remaining[i] -= dt;
                if (remaining[i] <= 0f) { remaining[i] = 0f; expired |= 1 << i; }
            }
            return expired;
        }

        /// <summary>Consumes the shield if active.</summary>
        public bool ConsumeShield()
        {
            int i = (int)PowerUpType.Shield;
            if (remaining[i] <= 0f) return false;
            remaining[i] = 0f;
            return true;
        }

        public void Clear()
        {
            for (int i = 0; i < TimedCount; i++) { remaining[i] = 0f; duration[i] = 0f; }
        }
    }
}
