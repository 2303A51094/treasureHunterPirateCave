using System;
using UnityEngine;

namespace TreasureHunt
{
    /// <summary>Owns power-up timers, their gameplay effects and their visual feedback on the player.</summary>
    public class PowerUpManager : MonoBehaviour
    {
        public readonly PowerUpTimers timers = new PowerUpTimers();
        public event Action<PowerUpType> Activated;
        public event Action<PowerUpType> Expired;

        GameConfig cfg;
        PlayerController player;
        ParticleSystem magnetAura, speedLines, detectorGlow;

        public bool MagnetActive { get { return timers.IsActive(PowerUpType.Magnet); } }
        public bool ShieldActive { get { return timers.IsActive(PowerUpType.Shield); } }
        public bool SpeedBoostActive { get { return timers.IsActive(PowerUpType.SpeedBoost); } }
        public bool DetectorActive { get { return timers.IsActive(PowerUpType.TreasureDetector); } }
        public float ScoreMultiplier { get { return timers.IsActive(PowerUpType.ScoreMultiplier) ? cfg.scoreMultiplier : 1f; } }
        public float SpeedMultiplier { get { return SpeedBoostActive ? cfg.speedBoostMultiplier : 1f; } }
        public float MagnetRadius { get { return cfg.magnetRadius; } }
        public float RareChanceMultiplier { get { return DetectorActive ? cfg.detectorRareMultiplier : 1f; } }

        public void Init(GameConfig config, PlayerController p)
        {
            cfg = config;
            player = p;
            Transform t = p.transform;
            magnetAura = FxManager.MakeSystem("MagnetAura", t, false, true, 30, 0.4f, 0.8f, -3f, -1.5f, 0.08f, 0.18f, new Color(1f, 0.3f, 0.3f), 0, ParticleSystemShapeType.Sphere, 2.2f, 80);
            magnetAura.transform.localPosition = new Vector3(0, 1f, 0);
            speedLines = FxManager.MakeSystem("SpeedLines", t, true, true, 60, 0.2f, 0.4f, 0.5f, 1f, 0.05f, 0.12f, new Color(0.6f, 1f, 0.6f), 0, ParticleSystemShapeType.Sphere, 1.2f, 120);
            speedLines.transform.localPosition = new Vector3(0, 1f, 0.5f);
            detectorGlow = FxManager.MakeSystem("DetectorGlow", t, false, true, 15, 0.6f, 1.2f, 0.3f, 0.8f, 0.1f, 0.2f, new Color(0.3f, 1f, 0.9f), -0.2f, ParticleSystemShapeType.Circle, 0.8f, 40);
            detectorGlow.transform.localPosition = new Vector3(0, 0.1f, 0);
            detectorGlow.transform.localRotation = Quaternion.Euler(-90, 0, 0);
            SetFx(magnetAura, false); SetFx(speedLines, false); SetFx(detectorGlow, false);
        }

        static void SetFx(ParticleSystem ps, bool on)
        {
            if (ps == null) return;
            if (on && !ps.isPlaying) ps.Play();
            else if (!on && ps.isPlaying) ps.Stop(true, ParticleSystemStopBehavior.StopEmitting);
        }

        public float DurationFor(PowerUpType t)
        {
            switch (t)
            {
                case PowerUpType.Magnet: return cfg.magnetDuration;
                case PowerUpType.Shield: return cfg.shieldDuration;
                case PowerUpType.SpeedBoost: return cfg.speedBoostDuration;
                case PowerUpType.ScoreMultiplier: return cfg.multiplierDuration;
                case PowerUpType.TreasureDetector: return cfg.detectorDuration;
                default: return 0f;
            }
        }

        public void Activate(PowerUpType t)
        {
            timers.Activate(t, DurationFor(t));
            RefreshVisuals();
            if (Activated != null) Activated(t);
        }

        /// <summary>Uses the shield charge. Returns true if a hit was absorbed.</summary>
        public bool ConsumeShield()
        {
            if (!timers.ConsumeShield()) return false;
            RefreshVisuals();
            if (Expired != null) Expired(PowerUpType.Shield);
            return true;
        }

        public void ResetAll()
        {
            timers.Clear();
            RefreshVisuals();
        }

        void RefreshVisuals()
        {
            if (player == null) return;
            if (player.shieldBubble != null) player.shieldBubble.SetActive(ShieldActive);
            SetFx(magnetAura, MagnetActive);
            SetFx(speedLines, SpeedBoostActive);
            SetFx(detectorGlow, DetectorActive);
        }

        void Update()
        {
            GameManager gm = GameManager.Instance;
            if (gm == null || gm.State != GameState.Playing) return;
            int expired = timers.Tick(Time.deltaTime);
            if (expired == 0) return;
            RefreshVisuals();
            for (int i = 0; i < PowerUpTimers.TimedCount; i++)
            {
                if ((expired & (1 << i)) == 0) continue;
                PowerUpType t = (PowerUpType)i;
                if (t == PowerUpType.SpeedBoost && player != null) player.GrantInvulnerability(0.8f); // grace period
                if (Expired != null) Expired(t);
            }
        }
    }
}
