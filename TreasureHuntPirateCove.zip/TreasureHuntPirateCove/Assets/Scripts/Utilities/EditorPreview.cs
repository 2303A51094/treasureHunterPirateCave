using UnityEngine;

namespace TreasureHunt
{
    /// <summary>Static preview shown in Edit mode so the scene isn't empty. Removed as soon as Play starts.</summary>
    public class EditorPreview : MonoBehaviour
    {
        void Awake() { Destroy(gameObject); }
    }
}
