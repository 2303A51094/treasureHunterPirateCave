using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace TreasureHunt
{
    /// <summary>Small helpers for assembling procedural models from parts.</summary>
    public static class Proc
    {
        public static GameObject Node(string name, Transform parent, Vector3 localPos)
        {
            GameObject go = new GameObject(name);
            if (parent != null) go.transform.SetParent(parent, false);
            go.transform.localPosition = localPos;
            return go;
        }

        public static GameObject Mesh(Mesh mesh, string mat, Transform parent, Vector3 lp, Vector3 ls, Vector3 euler, bool shadows = true, string name = null)
        {
            GameObject go = new GameObject(name ?? (mesh != null ? mesh.name : "Part"));
            if (parent != null) go.transform.SetParent(parent, false);
            go.transform.localPosition = lp;
            go.transform.localRotation = Quaternion.Euler(euler);
            go.transform.localScale = ls;
            go.AddComponent<MeshFilter>().sharedMesh = mesh;
            MeshRenderer r = go.AddComponent<MeshRenderer>();
            r.sharedMaterial = MaterialLibrary.Get(mat);
            r.shadowCastingMode = shadows ? ShadowCastingMode.On : ShadowCastingMode.Off;
            return go;
        }

        public static GameObject Part(PrimitiveType type, string mat, Transform parent, Vector3 lp, Vector3 ls, Vector3 euler, bool shadows = true, string name = null)
        {
            return Mesh(MeshFactory.Primitive(type), mat, parent, lp, ls, euler, shadows, name ?? type.ToString());
        }

        public static GameObject Part(PrimitiveType type, string mat, Transform parent, Vector3 lp, Vector3 ls)
        {
            return Part(type, mat, parent, lp, ls, Vector3.zero);
        }

        public static BoxCollider Box(GameObject go, Vector3 center, Vector3 size, bool trigger)
        {
            BoxCollider b = go.AddComponent<BoxCollider>();
            b.center = center;
            b.size = size;
            b.isTrigger = trigger;
            return b;
        }

        /// <summary>
        /// Merges every MeshFilter under root into one renderer per material to cut draw calls.
        /// Only use on static, non-animated props.
        /// </summary>
        public static void CombineByMaterial(GameObject root)
        {
            MeshFilter[] filters = root.GetComponentsInChildren<MeshFilter>(true);
            if (filters.Length < 2) return;
            Dictionary<Material, List<CombineInstance>> groups = new Dictionary<Material, List<CombineInstance>>();
            Matrix4x4 toLocal = root.transform.worldToLocalMatrix;
            List<GameObject> toRemove = new List<GameObject>();
            for (int i = 0; i < filters.Length; i++)
            {
                MeshFilter f = filters[i];
                MeshRenderer r = f.GetComponent<MeshRenderer>();
                if (r == null || f.sharedMesh == null || r.sharedMaterial == null) continue;
                if (f.GetComponentInParent<KeepSeparate>() != null) continue;
                List<CombineInstance> list;
                if (!groups.TryGetValue(r.sharedMaterial, out list)) { list = new List<CombineInstance>(); groups.Add(r.sharedMaterial, list); }
                CombineInstance ci = new CombineInstance();
                ci.mesh = f.sharedMesh;
                ci.transform = toLocal * f.transform.localToWorldMatrix;
                list.Add(ci);
                toRemove.Add(f.gameObject);
            }
            foreach (KeyValuePair<Material, List<CombineInstance>> kv in groups)
            {
                Mesh m = new Mesh();
                m.name = root.name + "_" + kv.Key.name;
                int verts = 0;
                for (int i = 0; i < kv.Value.Count; i++) verts += kv.Value[i].mesh.vertexCount;
                if (verts > 65000) m.indexFormat = IndexFormat.UInt32;
                m.CombineMeshes(kv.Value.ToArray(), true, true);
                m.RecalculateBounds();
                MeshFactory.RegisterCombined(m);
                GameObject g = new GameObject("Combined_" + kv.Key.name);
                g.transform.SetParent(root.transform, false);
                g.AddComponent<MeshFilter>().sharedMesh = m;
                MeshRenderer mr = g.AddComponent<MeshRenderer>();
                mr.sharedMaterial = kv.Key;
                mr.shadowCastingMode = ShadowCastingMode.On;
            }
            // Remove originals (only the renderer parts; keep nodes that hold other components).
            for (int i = 0; i < toRemove.Count; i++)
            {
                GameObject g = toRemove[i];
                if (g == root) continue;
                if (g.transform.childCount == 0 && g.GetComponents<Component>().Length <= 3)
                    Object.DestroyImmediate(g);
                else
                {
                    Object.DestroyImmediate(g.GetComponent<MeshRenderer>());
                    Object.DestroyImmediate(g.GetComponent<MeshFilter>());
                }
            }
        }

        public static void DisableShadows(GameObject root)
        {
            Renderer[] rs = root.GetComponentsInChildren<Renderer>(true);
            for (int i = 0; i < rs.Length; i++) rs[i].shadowCastingMode = ShadowCastingMode.Off;
        }
    }

    /// <summary>Marks a subtree that CombineByMaterial must leave alone (animated or special parts).</summary>
    public class KeepSeparate : MonoBehaviour { }
}
