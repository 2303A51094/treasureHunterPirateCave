using System.Collections.Generic;
using UnityEngine;

namespace TreasureHunt
{
    /// <summary>Procedural low-poly meshes plus cached Unity primitive meshes.</summary>
    public static class MeshFactory
    {
        static readonly Dictionary<string, Mesh> cache = new Dictionary<string, Mesh>();
        /// <summary>Every mesh created procedurally (editor tool saves these as assets).</summary>
        public static readonly List<Mesh> Generated = new List<Mesh>();

        public static void ClearCache()
        {
            cache.Clear();
            Generated.Clear();
        }

        public static Mesh Primitive(PrimitiveType type)
        {
            string key = "prim_" + type;
            Mesh m;
            if (cache.TryGetValue(key, out m) && m != null) return m;
            GameObject go = GameObject.CreatePrimitive(type);
            m = go.GetComponent<MeshFilter>().sharedMesh;
            Object.DestroyImmediate(go);
            cache[key] = m;
            return m;
        }

        static Mesh Register(string key, Mesh m)
        {
            m.name = key;
            m.RecalculateBounds();
            cache[key] = m;
            Generated.Add(m);
            return m;
        }

        static bool TryGet(string key, out Mesh m)
        {
            return cache.TryGetValue(key, out m) && m != null;
        }

        /// <summary>Builds a flat-shaded mesh from a triangle soup (each triangle gets its own vertices).</summary>
        static Mesh FlatMesh(List<Vector3> tris)
        {
            Mesh m = new Mesh();
            Vector3[] v = tris.ToArray();
            int[] idx = new int[v.Length];
            Vector2[] uv = new Vector2[v.Length];
            for (int i = 0; i < idx.Length; i++)
            {
                idx[i] = i;
                uv[i] = new Vector2(v[i].x + 0.5f, v[i].y + 0.5f);
            }
            m.vertices = v;
            m.uv = uv;
            m.triangles = idx;
            m.RecalculateNormals();
            return m;
        }

        /// <summary>Cone with base radius 0.5 at y=0 and apex at y=1.</summary>
        public static Mesh Cone(int segments = 10)
        {
            string key = "Cone" + segments;
            Mesh m;
            if (TryGet(key, out m)) return m;
            List<Vector3> t = new List<Vector3>();
            Vector3 apex = new Vector3(0, 1, 0);
            for (int i = 0; i < segments; i++)
            {
                float a0 = i * Mathf.PI * 2f / segments, a1 = (i + 1) * Mathf.PI * 2f / segments;
                Vector3 p0 = new Vector3(Mathf.Cos(a0) * 0.5f, 0, Mathf.Sin(a0) * 0.5f);
                Vector3 p1 = new Vector3(Mathf.Cos(a1) * 0.5f, 0, Mathf.Sin(a1) * 0.5f);
                t.Add(p0); t.Add(apex); t.Add(p1);
                t.Add(p1); t.Add(Vector3.zero); t.Add(p0);
            }
            return Register(key, FlatMesh(t));
        }

        /// <summary>Unit octahedron (gem shape), extents ±0.5.</summary>
        public static Mesh Octahedron()
        {
            Mesh m;
            if (TryGet("Octahedron", out m)) return m;
            Vector3 top = new Vector3(0, 0.5f, 0), bot = new Vector3(0, -0.5f, 0);
            Vector3[] ring = { new Vector3(0.5f, 0, 0), new Vector3(0, 0, 0.5f), new Vector3(-0.5f, 0, 0), new Vector3(0, 0, -0.5f) };
            List<Vector3> t = new List<Vector3>();
            for (int i = 0; i < 4; i++)
            {
                Vector3 a = ring[i], b = ring[(i + 1) % 4];
                t.Add(a); t.Add(b); t.Add(top);
                t.Add(b); t.Add(a); t.Add(bot);
            }
            // Winding check: make outward-facing by testing normal against centroid direction.
            for (int i = 0; i < t.Count; i += 3)
            {
                Vector3 n = Vector3.Cross(t[i + 1] - t[i], t[i + 2] - t[i]);
                Vector3 c = (t[i] + t[i + 1] + t[i + 2]) / 3f;
                if (Vector3.Dot(n, c) < 0) { Vector3 tmp = t[i + 1]; t[i + 1] = t[i + 2]; t[i + 2] = tmp; }
            }
            return Register("Octahedron", FlatMesh(t));
        }

        /// <summary>Torus in the XZ plane (ring axis = Y).</summary>
        public static Mesh Torus(float radius = 0.5f, float tube = 0.12f, int seg = 18, int sides = 8)
        {
            string key = "Torus" + radius + "_" + tube;
            Mesh m;
            if (TryGet(key, out m)) return m;
            Vector3[] v = new Vector3[(seg + 1) * (sides + 1)];
            Vector2[] uv = new Vector2[v.Length];
            int k = 0;
            for (int i = 0; i <= seg; i++)
            {
                float u = i * Mathf.PI * 2f / seg;
                Vector3 center = new Vector3(Mathf.Cos(u) * radius, 0, Mathf.Sin(u) * radius);
                for (int j = 0; j <= sides; j++)
                {
                    float w = j * Mathf.PI * 2f / sides;
                    Vector3 dir = center.normalized * Mathf.Cos(w) + Vector3.up * Mathf.Sin(w);
                    v[k] = center + dir * tube;
                    uv[k] = new Vector2((float)i / seg, (float)j / sides);
                    k++;
                }
            }
            int[] tri = new int[seg * sides * 6];
            k = 0;
            for (int i = 0; i < seg; i++)
                for (int j = 0; j < sides; j++)
                {
                    int a = i * (sides + 1) + j, b = (i + 1) * (sides + 1) + j;
                    tri[k++] = a; tri[k++] = a + 1; tri[k++] = b;
                    tri[k++] = b; tri[k++] = a + 1; tri[k++] = b + 1;
                }
            m = new Mesh();
            m.vertices = v;
            m.uv = uv;
            m.triangles = tri;
            m.RecalculateNormals();
            return Register(key, m);
        }

        /// <summary>Five-point star prism, facing -Z, extents roughly ±0.5, thickness 0.2.</summary>
        public static Mesh Star()
        {
            Mesh m;
            if (TryGet("Star", out m)) return m;
            Vector3[] outline = new Vector3[10];
            for (int i = 0; i < 10; i++)
            {
                float a = Mathf.PI / 2f + i * Mathf.PI / 5f;
                float r = (i % 2 == 0) ? 0.5f : 0.2f;
                outline[i] = new Vector3(Mathf.Cos(a) * r, Mathf.Sin(a) * r, 0);
            }
            List<Vector3> t = new List<Vector3>();
            Vector3 f = new Vector3(0, 0, -0.1f), b = new Vector3(0, 0, 0.1f);
            for (int i = 0; i < 10; i++)
            {
                Vector3 p0 = outline[i], p1 = outline[(i + 1) % 10];
                t.Add(f); t.Add(p1 + f); t.Add(p0 + f);
                t.Add(b); t.Add(p0 + b); t.Add(p1 + b);
                t.Add(p0 + f); t.Add(p1 + f); t.Add(p1 + b);
                t.Add(p0 + f); t.Add(p1 + b); t.Add(p0 + b);
            }
            return Register("Star", FlatMesh(t));
        }

        /// <summary>Flat grid in XZ, used by the animated ocean (not cached: each ocean owns its copy).</summary>
        public static Mesh Grid(int cells, float size)
        {
            int n = cells + 1;
            Vector3[] v = new Vector3[n * n];
            Vector2[] uv = new Vector2[v.Length];
            for (int z = 0; z < n; z++)
                for (int x = 0; x < n; x++)
                {
                    v[z * n + x] = new Vector3((x / (float)cells - 0.5f) * size, 0, (z / (float)cells - 0.5f) * size);
                    uv[z * n + x] = new Vector2(x / (float)cells * 8f, z / (float)cells * 8f);
                }
            int[] tri = new int[cells * cells * 6];
            int k = 0;
            for (int z = 0; z < cells; z++)
                for (int x = 0; x < cells; x++)
                {
                    int a = z * n + x;
                    tri[k++] = a; tri[k++] = a + n; tri[k++] = a + 1;
                    tri[k++] = a + 1; tri[k++] = a + n; tri[k++] = a + n + 1;
                }
            Mesh m = new Mesh();
            m.name = "OceanGrid";
            m.vertices = v;
            m.uv = uv;
            m.triangles = tri;
            m.RecalculateNormals();
            m.MarkDynamic();
            return m;
        }

        /// <summary>Registers a combined mesh created by Proc.CombineByMaterial.</summary>
        public static Mesh RegisterCombined(Mesh m)
        {
            Generated.Add(m);
            return m;
        }
    }
}
