using System;
using System.Collections.Generic;
using UnityEngine;

namespace TreasureHunt
{
    /// <summary>Implemented by components that must reset when a pooled object is reused.</summary>
    public interface IPoolable
    {
        void OnSpawned();
        void OnDespawned();
    }

    /// <summary>Marker placed on every pooled root. Caches IPoolable children once.</summary>
    [DisallowMultipleComponent]
    public class PooledObject : MonoBehaviour
    {
        public string poolKey;
        [NonSerialized] public bool inPool;
        IPoolable[] poolables;

        void CacheInterfaces()
        {
            if (poolables == null) poolables = GetComponentsInChildren<IPoolable>(true);
        }

        public void NotifySpawned()
        {
            CacheInterfaces();
            for (int i = 0; i < poolables.Length; i++) poolables[i].OnSpawned();
        }

        public void NotifyDespawned()
        {
            CacheInterfaces();
            for (int i = 0; i < poolables.Length; i++) poolables[i].OnDespawned();
        }
    }

    /// <summary>Keyed object pool. Objects are created by a factory delegate on demand.</summary>
    public class ObjectPool
    {
        readonly Dictionary<string, Stack<PooledObject>> stacks = new Dictionary<string, Stack<PooledObject>>();
        readonly Func<string, GameObject> factory;
        readonly Transform root;

        public ObjectPool(Func<string, GameObject> factory, Transform root)
        {
            this.factory = factory;
            this.root = root;
        }

        Stack<PooledObject> StackFor(string key)
        {
            Stack<PooledObject> s;
            if (!stacks.TryGetValue(key, out s))
            {
                s = new Stack<PooledObject>();
                stacks.Add(key, s);
            }
            return s;
        }

        PooledObject Create(string key)
        {
            GameObject go = factory(key);
            if (go == null) return null;
            PooledObject po = go.GetComponent<PooledObject>();
            if (po == null) po = go.AddComponent<PooledObject>();
            po.poolKey = key;
            return po;
        }

        public void Prewarm(string key, int count)
        {
            Stack<PooledObject> s = StackFor(key);
            for (int i = 0; i < count; i++)
            {
                PooledObject po = Create(key);
                if (po == null) return;
                po.inPool = true;
                po.gameObject.SetActive(false);
                po.transform.SetParent(root, false);
                s.Push(po);
            }
        }

        public PooledObject Get(string key, Transform parent, Vector3 worldPos, Quaternion rot)
        {
            Stack<PooledObject> s = StackFor(key);
            PooledObject po = null;
            while (po == null && s.Count > 0) po = s.Pop(); // skips destroyed entries
            if (po == null) po = Create(key);
            if (po == null) return null;
            Transform t = po.transform;
            t.SetParent(parent, false);
            t.SetPositionAndRotation(worldPos, rot);
            po.inPool = false;
            po.gameObject.SetActive(true);
            po.NotifySpawned();
            return po;
        }

        public void Release(PooledObject po)
        {
            if (po == null || po.inPool) return;
            po.NotifyDespawned();
            po.inPool = true;
            po.gameObject.SetActive(false);
            po.transform.SetParent(root, false);
            StackFor(po.poolKey).Push(po);
        }
    }
}
