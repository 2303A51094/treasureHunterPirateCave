using UnityEngine;
using UnityEngine.EventSystems;
#if TH_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
using UnityEngine.InputSystem;
#endif

namespace TreasureHunt
{
    public enum InputCommand { None, Left, Right, Jump, Slide }

    /// <summary>Pure swipe classification (unit tested).</summary>
    public static class SwipeLogic
    {
        /// <summary>Returns a command once the drag passes minDistance along its dominant axis; None for taps.</summary>
        public static InputCommand Classify(Vector2 delta, float minDistance)
        {
            if (delta.sqrMagnitude < minDistance * minDistance) return InputCommand.None;
            if (Mathf.Abs(delta.x) > Mathf.Abs(delta.y)) return delta.x > 0 ? InputCommand.Right : InputCommand.Left;
            return delta.y > 0 ? InputCommand.Jump : InputCommand.Slide;
        }
    }

    /// <summary>
    /// Unified keyboard + swipe input. Works with the legacy Input Manager and, when only the
    /// new Input System is enabled, with the Input System package (define TH_INPUT_SYSTEM).
    /// A swipe triggers as soon as it crosses the threshold (responsive), then the gesture is locked
    /// until the finger lifts, so one gesture can never produce two moves.
    /// </summary>
    public class InputAdapter : MonoBehaviour
    {
        public float sensitivity = 1f;
        public float swipeMinFraction = 0.06f;

        int cachedFrame = -1;
        InputCommand cachedCommand;
        bool cachedPause;

        bool tracking, consumed;
        Vector2 startPos;

        float MinSwipePixels
        {
            get { return Mathf.Max(20f, Screen.height * swipeMinFraction / Mathf.Clamp(sensitivity, 0.3f, 3f)); }
        }

        /// <summary>The gameplay command for this frame (safe to call multiple times per frame).</summary>
        public InputCommand Command { get { Refresh(); return cachedCommand; } }
        public bool PausePressed { get { Refresh(); return cachedPause; } }

        void Refresh()
        {
            if (cachedFrame == Time.frameCount) return;
            cachedFrame = Time.frameCount;
            cachedPause = ReadPause();
            InputCommand k = ReadKeyboard();
            InputCommand s = ReadSwipe();
            cachedCommand = k != InputCommand.None ? k : s;
        }

        static bool OverUI(int pointerId)
        {
            EventSystem es = EventSystem.current;
            if (es == null) return false;
            return pointerId >= 0 ? es.IsPointerOverGameObject(pointerId) : es.IsPointerOverGameObject();
        }

        void Begin(Vector2 pos, int pointerId)
        {
            tracking = !OverUI(pointerId);
            consumed = false;
            startPos = pos;
        }

        InputCommand Move(Vector2 pos)
        {
            if (!tracking || consumed) return InputCommand.None;
            InputCommand c = SwipeLogic.Classify(pos - startPos, MinSwipePixels);
            if (c != InputCommand.None) consumed = true;
            return c;
        }

#if ENABLE_LEGACY_INPUT_MANAGER || !TH_INPUT_SYSTEM
        bool ReadPause()
        {
#if ENABLE_LEGACY_INPUT_MANAGER
            return Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.P);
#else
            return false;
#endif
        }

        InputCommand ReadKeyboard()
        {
#if ENABLE_LEGACY_INPUT_MANAGER
            if (Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.LeftArrow)) return InputCommand.Left;
            if (Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.RightArrow)) return InputCommand.Right;
            if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.W)) return InputCommand.Jump;
            if (Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.DownArrow)) return InputCommand.Slide;
#endif
            return InputCommand.None;
        }

        InputCommand ReadSwipe()
        {
#if ENABLE_LEGACY_INPUT_MANAGER
            if (Input.touchCount > 0)
            {
                Touch t = Input.GetTouch(0);
                if (t.phase == TouchPhase.Began) { Begin(t.position, t.fingerId); return InputCommand.None; }
                if (t.phase == TouchPhase.Moved || t.phase == TouchPhase.Stationary) return Move(t.position);
                if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled)
                {
                    InputCommand c = Move(t.position);
                    tracking = false;
                    return c;
                }
                return InputCommand.None;
            }
            if (!Application.isMobilePlatform)
            {
                // Mouse drag = swipe (handy for testing swipe controls in the Editor).
                if (Input.GetMouseButtonDown(0)) { Begin(Input.mousePosition, -1); return InputCommand.None; }
                if (Input.GetMouseButton(0)) return Move(Input.mousePosition);
                if (Input.GetMouseButtonUp(0)) { InputCommand c = Move(Input.mousePosition); tracking = false; return c; }
            }
#endif
            return InputCommand.None;
        }
#else
        bool ReadPause()
        {
            Keyboard k = Keyboard.current;
            return k != null && (k.escapeKey.wasPressedThisFrame || k.pKey.wasPressedThisFrame);
        }

        InputCommand ReadKeyboard()
        {
            Keyboard k = Keyboard.current;
            if (k == null) return InputCommand.None;
            if (k.aKey.wasPressedThisFrame || k.leftArrowKey.wasPressedThisFrame) return InputCommand.Left;
            if (k.dKey.wasPressedThisFrame || k.rightArrowKey.wasPressedThisFrame) return InputCommand.Right;
            if (k.spaceKey.wasPressedThisFrame || k.upArrowKey.wasPressedThisFrame || k.wKey.wasPressedThisFrame) return InputCommand.Jump;
            if (k.sKey.wasPressedThisFrame || k.downArrowKey.wasPressedThisFrame) return InputCommand.Slide;
            return InputCommand.None;
        }

        InputCommand ReadSwipe()
        {
            Touchscreen ts = Touchscreen.current;
            if (ts != null && (ts.primaryTouch.press.isPressed || ts.primaryTouch.press.wasReleasedThisFrame))
            {
                Vector2 p = ts.primaryTouch.position.ReadValue();
                if (ts.primaryTouch.press.wasPressedThisFrame) { Begin(p, -1); return InputCommand.None; }
                if (ts.primaryTouch.press.wasReleasedThisFrame) { InputCommand c = Move(p); tracking = false; return c; }
                return Move(p);
            }
            Mouse m = Mouse.current;
            if (m != null && !Application.isMobilePlatform)
            {
                Vector2 p = m.position.ReadValue();
                if (m.leftButton.wasPressedThisFrame) { Begin(p, -1); return InputCommand.None; }
                if (m.leftButton.wasReleasedThisFrame) { InputCommand c = Move(p); tracking = false; return c; }
                if (m.leftButton.isPressed) return Move(p);
            }
            return InputCommand.None;
        }
#endif
    }
}
