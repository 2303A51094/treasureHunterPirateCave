using System.Collections.Generic;
using UnityEngine;

namespace TreasureHunt
{
    /// <summary>
    /// Generates every texture and UI icon at load time, so the project needs no image files.
    /// All drawing is deterministic (hash noise), so results are identical on every device.
    /// </summary>
    public static class TextureFactory
    {
        static readonly Dictionary<string, Texture2D> cache = new Dictionary<string, Texture2D>();
        static readonly Dictionary<string, Sprite> sprites = new Dictionary<string, Sprite>();

        public static IEnumerable<Texture2D> All { get { return cache.Values; } }

        public static void ClearCache()
        {
            cache.Clear();
            sprites.Clear();
        }

        // ---------- noise helpers ----------
        static float Hash(int x, int y, int seed)
        {
            unchecked
            {
                uint h = (uint)(x * 374761393 + y * 668265263 + seed * 982451653);
                h = (h ^ (h >> 13)) * 1274126177u;
                h ^= h >> 16;
                return (h & 0xFFFFFF) / 16777215f;
            }
        }

        static float ValueNoise(float x, float y, int seed)
        {
            int xi = Mathf.FloorToInt(x), yi = Mathf.FloorToInt(y);
            float xf = x - xi, yf = y - yi;
            float a = Hash(xi, yi, seed), b = Hash(xi + 1, yi, seed);
            float c = Hash(xi, yi + 1, seed), d = Hash(xi + 1, yi + 1, seed);
            float u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
            return Mathf.Lerp(Mathf.Lerp(a, b, u), Mathf.Lerp(c, d, u), v);
        }

        static float Fbm(float x, float y, int seed)
        {
            return ValueNoise(x, y, seed) * 0.55f + ValueNoise(x * 2f, y * 2f, seed + 7) * 0.3f + ValueNoise(x * 4f, y * 4f, seed + 13) * 0.15f;
        }

        delegate Color PixelFn(int x, int y);

        static Texture2D Make(string name, int size, PixelFn fn, bool repeat = true)
        {
            Texture2D cached;
            if (cache.TryGetValue(name, out cached) && cached != null) return cached;
            Texture2D t = new Texture2D(size, size, TextureFormat.RGBA32, true);
            t.name = name;
            t.wrapMode = repeat ? TextureWrapMode.Repeat : TextureWrapMode.Clamp;
            t.filterMode = FilterMode.Bilinear;
            Color32[] px = new Color32[size * size];
            for (int y = 0; y < size; y++)
                for (int x = 0; x < size; x++)
                    px[y * size + x] = fn(x, y);
            t.SetPixels32(px);
            t.Apply(true);
            cache[name] = t;
            return t;
        }

        // ---------- surface textures ----------
        public static Texture2D Planks(string name, Color baseColor, int seed)
        {
            const int size = 128;
            return Make(name, size, (x, y) =>
            {
                int plank = y / 32;                 // 4 boards across the texture
                int ly = y % 32;
                float grain = Fbm(x * 0.05f, (y + plank * 17) * 0.6f, seed + plank);
                float tone = 0.78f + Hash(plank, 0, seed) * 0.3f;
                float k = tone * (0.75f + grain * 0.45f);
                if (ly < 2) k *= 0.35f;            // dark seam between boards
                int nailX = (plank % 2 == 0) ? 12 : 116;
                if (Mathf.Abs(x - nailX) < 2 && Mathf.Abs(ly - 16) < 2) k *= 0.4f;
                Color c = baseColor * k;
                c.a = 1;
                return c;
            });
        }

        public static Texture2D Stone(string name, Color baseColor, int seed)
        {
            const int size = 128;
            return Make(name, size, (x, y) =>
            {
                int row = y / 32;
                int off = (row % 2) * 24;
                int col = (x + off) / 48;
                int lx = (x + off) % 48, ly = y % 32;
                float tone = 0.75f + Hash(col, row, seed) * 0.35f;
                float n = Fbm(x * 0.08f, y * 0.08f, seed);
                float k = tone * (0.7f + n * 0.5f);
                if (lx < 2 || ly < 2) k *= 0.3f;   // mortar lines
                Color c = baseColor * k;
                c.a = 1;
                return c;
            });
        }

        public static Texture2D Speckle(string name, Color baseColor, float scale, float contrast, int seed)
        {
            const int size = 128;
            return Make(name, size, (x, y) =>
            {
                float n = Fbm(x * scale, y * scale, seed);
                float s = Hash(x, y, seed + 99) > 0.97f ? 0.8f : 1f;
                Color c = baseColor * (1f - contrast + n * contrast * 2f) * s;
                c.a = 1;
                return c;
            });
        }

        public static Texture2D WaterStreaks()
        {
            return Make("WaterStreaks", 64, (x, y) =>
            {
                float n = ValueNoise(x * 0.4f, y * 0.04f, 3);
                float a = 0.45f + n * 0.5f;
                return new Color(0.75f + n * 0.25f, 0.9f, 1f, a);
            });
        }

        public static Texture2D Glyphs()
        {
            // Mysterious carved symbols: circles, crosses and lines on dark stone.
            return Make("Glyphs", 128, (x, y) =>
            {
                int cx = x / 32, cy = y / 32;
                int lx = x % 32 - 16, ly = y % 32 - 16;
                int kind = (int)(Hash(cx, cy, 5) * 4);
                bool on = false;
                float r = Mathf.Sqrt(lx * lx + ly * ly);
                if (kind == 0) on = Mathf.Abs(r - 10) < 1.6f || (Mathf.Abs(lx) < 1.5f && Mathf.Abs(ly) < 10);
                else if (kind == 1) on = Mathf.Abs(lx - ly) < 1.6f && r < 11 || Mathf.Abs(lx + ly) < 1.6f && r < 11;
                else if (kind == 2) on = Mathf.Abs(r - 5) < 1.4f || Mathf.Abs(r - 11) < 1.4f;
                else on = (Mathf.Abs(ly) < 1.5f && Mathf.Abs(lx) < 11) || (Mathf.Abs(lx - 6) < 1.5f && ly > -11 && ly < 0) || (Mathf.Abs(lx + 6) < 1.5f && ly < 11 && ly > 0);
                return on ? new Color(1, 1, 1, 1) : new Color(0.05f, 0.05f, 0.06f, 1);
            });
        }

        public static Texture2D SoftCircle()
        {
            return Make("SoftCircle", 64, (x, y) =>
            {
                float dx = (x - 31.5f) / 31.5f, dy = (y - 31.5f) / 31.5f;
                float d = Mathf.Sqrt(dx * dx + dy * dy);
                float a = Mathf.Clamp01(1f - d);
                a = a * a;
                return new Color(1, 1, 1, a);
            }, false);
        }

        // ---------- UI textures ----------
        public static Texture2D UIWood()
        {
            return Make("UIWood", 128, (x, y) =>
            {
                float grain = Fbm(x * 0.6f, y * 0.04f, 21);
                int board = x / 32;
                float tone = 0.8f + Hash(board, 3, 4) * 0.2f;
                float k = tone * (0.6f + grain * 0.5f);
                if (x % 32 < 2) k *= 0.45f;
                return new Color(0.42f * k, 0.25f * k, 0.12f * k, 1);
            });
        }

        public static Texture2D UIParchment()
        {
            return Make("UIParchment", 128, (x, y) =>
            {
                float n = Fbm(x * 0.05f, y * 0.05f, 31);
                float edge = Mathf.Min(Mathf.Min(x, 127 - x), Mathf.Min(y, 127 - y)) / 20f;
                float k = Mathf.Lerp(0.72f, 1f, Mathf.Clamp01(edge)) * (0.85f + n * 0.2f);
                return new Color(0.93f * k, 0.84f * k, 0.64f * k, 1);
            }, false);
        }

        public static Sprite SpriteFor(Texture2D t)
        {
            Sprite s;
            if (sprites.TryGetValue(t.name, out s) && s != null) return s;
            s = Sprite.Create(t, new Rect(0, 0, t.width, t.height), new Vector2(0.5f, 0.5f), 100f);
            s.name = t.name;
            sprites[t.name] = s;
            return s;
        }

        // ---------- Icons (64x64, transparent background) ----------
        static bool InPoly(float px, float py, Vector2[] poly)
        {
            bool inside = false;
            for (int i = 0, j = poly.Length - 1; i < poly.Length; j = i++)
            {
                if (((poly[i].y > py) != (poly[j].y > py)) &&
                    (px < (poly[j].x - poly[i].x) * (py - poly[i].y) / (poly[j].y - poly[i].y) + poly[i].x))
                    inside = !inside;
            }
            return inside;
        }

        static Vector2[] StarPoly(float cx, float cy, float ro, float ri)
        {
            Vector2[] p = new Vector2[10];
            for (int i = 0; i < 10; i++)
            {
                float a = Mathf.PI / 2f + i * Mathf.PI / 5f;
                float r = i % 2 == 0 ? ro : ri;
                p[i] = new Vector2(cx + Mathf.Cos(a) * r, cy + Mathf.Sin(a) * r);
            }
            return p;
        }

        static readonly Color Clear = new Color(0, 0, 0, 0);

        public static Sprite Icon(string id)
        {
            string name = "Icon_" + id;
            Texture2D t;
            switch (id)
            {
                case "coin":
                    t = Make(name, 64, (x, y) =>
                    {
                        float d = Vector2.Distance(new Vector2(x, y), new Vector2(31.5f, 31.5f));
                        if (d > 28) return Clear;
                        if (d > 24) return new Color(0.75f, 0.5f, 0.08f, 1);
                        if (d > 20) return new Color(1f, 0.82f, 0.25f, 1);
                        return new Color(0.95f, 0.7f, 0.15f, 1);
                    }, false); break;
                case "gem":
                    t = Make(name, 64, (x, y) =>
                    {
                        Vector2[] dia = { new Vector2(32, 4), new Vector2(58, 34), new Vector2(46, 52), new Vector2(18, 52), new Vector2(6, 34) };
                        if (!InPoly(x, y, dia)) return Clear;
                        if (y > 34) return new Color(0.55f, 0.85f, 1f, 1);
                        return x < 32 ? new Color(0.15f, 0.45f, 0.95f, 1) : new Color(0.1f, 0.3f, 0.8f, 1);
                    }, false); break;
                case "key":
                    t = Make(name, 64, (x, y) =>
                    {
                        float d = Vector2.Distance(new Vector2(x, y), new Vector2(16, 32));
                        bool bow = d < 13 && d > 6;
                        bool shaft = x >= 26 && x <= 58 && y >= 29 && y <= 35;
                        bool tooth = (x >= 46 && x <= 50 || x >= 54 && x <= 58) && y >= 20 && y < 29;
                        return (bow || shaft || tooth) ? new Color(0.98f, 0.78f, 0.25f, 1) : Clear;
                    }, false); break;
                case "star":
                    t = Make(name, 64, (x, y) => InPoly(x, y, StarPoly(32, 31, 29, 12)) ? new Color(1f, 0.8f, 0.2f, 1) : Clear, false); break;
                case "magnet":
                    t = Make(name, 64, (x, y) =>
                    {
                        float d = Vector2.Distance(new Vector2(x, y), new Vector2(32, 30));
                        bool arc = d < 24 && d > 12 && y <= 30;
                        bool armL = x >= 8 && x <= 20 && y > 30 && y <= 56;
                        bool armR = x >= 44 && x <= 56 && y > 30 && y <= 56;
                        if ((armL || armR) && y > 46) return new Color(0.85f, 0.85f, 0.9f, 1);
                        return (arc || armL || armR) ? new Color(0.9f, 0.15f, 0.15f, 1) : Clear;
                    }, false); break;
                case "shield":
                    t = Make(name, 64, (x, y) =>
                    {
                        Vector2[] sh = { new Vector2(32, 4), new Vector2(56, 22), new Vector2(54, 56), new Vector2(10, 56), new Vector2(8, 22) };
                        Vector2[] inner = { new Vector2(32, 10), new Vector2(50, 25), new Vector2(49, 51), new Vector2(15, 51), new Vector2(14, 25) };
                        if (InPoly(x, y, inner)) return new Color(0.2f, 0.5f, 0.95f, 1);
                        if (InPoly(x, y, sh)) return new Color(1f, 0.8f, 0.25f, 1);
                        return Clear;
                    }, false); break;
                case "speed":
                    t = Make(name, 64, (x, y) =>
                    {
                        Vector2[] bolt = { new Vector2(38, 60), new Vector2(14, 30), new Vector2(30, 30), new Vector2(24, 4), new Vector2(50, 36), new Vector2(34, 36) };
                        return InPoly(x, y, bolt) ? new Color(0.45f, 1f, 0.35f, 1) : Clear;
                    }, false); break;
                case "multiplier":
                    t = Make(name, 64, (x, y) => InPoly(x, y, StarPoly(32, 31, 29, 13)) ? new Color(0.75f, 0.35f, 1f, 1) : Clear, false); break;
                case "detector":
                    t = Make(name, 64, (x, y) =>
                    {
                        float d = Vector2.Distance(new Vector2(x, y), new Vector2(32, 32));
                        Vector2[] needle = { new Vector2(32, 56), new Vector2(38, 32), new Vector2(32, 8), new Vector2(26, 32) };
                        if (InPoly(x, y, needle)) return y > 32 ? new Color(0.95f, 0.2f, 0.2f, 1) : new Color(0.9f, 0.9f, 0.9f, 1);
                        if (d < 28 && d > 23) return new Color(1f, 0.8f, 0.25f, 1);
                        if (d <= 23) return new Color(0.1f, 0.35f, 0.4f, 1);
                        return Clear;
                    }, false); break;
                case "bonus":
                    t = Make(name, 64, (x, y) =>
                    {
                        bool body = x >= 8 && x <= 56 && y >= 10 && y <= 36;
                        bool lid = x >= 8 && x <= 56 && y > 38 && y <= 52;
                        bool band = (x >= 28 && x <= 36) && (body || lid);
                        if (band) return new Color(1f, 0.82f, 0.25f, 1);
                        if (body) return new Color(0.5f, 0.28f, 0.12f, 1);
                        if (lid) return new Color(0.62f, 0.36f, 0.16f, 1);
                        return Clear;
                    }, false); break;
                case "pause":
                    t = Make(name, 64, (x, y) => ((x >= 16 && x <= 26) || (x >= 38 && x <= 48)) && y >= 12 && y <= 52 ? new Color(1f, 0.92f, 0.7f, 1) : Clear, false); break;
                default:
                    t = Make(name, 64, (x, y) => Color.white, false); break;
            }
            return SpriteFor(t);
        }
    }
}
