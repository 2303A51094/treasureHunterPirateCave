using System;
using UnityEngine;

namespace TreasureHunt
{
    /// <summary>
    /// Every tunable gameplay value lives here. The instance is serialized on the
    /// Bootstrap object in Assets/Scenes/PirateCove.unity, so designers can edit it in the Inspector.
    /// </summary>
    [Serializable]
    public class GameConfig
    {
        [Header("Lanes")]
        public float laneWidth = 2.5f;
        public float laneChangeSpeed = 16f;

        [Header("Running speed (m/s)")]
        public float startSpeed = 11f;
        public float maxSpeed = 26f;
        [Tooltip("Metres per second gained every second of running.")]
        public float acceleration = 0.15f;

        [Header("Jump & slide")]
        public float jumpVelocity = 9.5f;
        public float gravity = 26f;
        public float slideDuration = 0.75f;
        public float fallDeathY = -2.5f;

        [Header("Score")]
        public float pointsPerMeter = 1f;
        public int coinScore = 10;
        public int gemScore = 50;
        public int keyScore = 150;
        public int chestScore = 300;
        public int artifactScore = 1000;

        [Header("Treasure rewards")]
        public int chestCoins = 40;
        public int chestCoinsWithKey = 150;
        public int artifactCoins = 100;
        public int artifactGems = 5;
        public int treasureBonusCoins = 75;
        public int treasureBonusScore = 500;

        [Header("Power-ups")]
        public float magnetDuration = 10f;
        public float magnetRadius = 8f;
        public float shieldDuration = 20f;
        public float speedBoostDuration = 5f;
        public float speedBoostMultiplier = 1.6f;
        public float multiplierDuration = 12f;
        public float scoreMultiplier = 2f;
        public float detectorDuration = 15f;
        public float detectorRareMultiplier = 3f;

        [Header("Revive")]
        public int reviveGemCost = 20;
        public bool reviveCostDoubles = true;
        public int maxRevivesPerRun = 3;
        public float reviveInvulnerability = 2.5f;

        [Header("Track")]
        public float chunkLength = 40f;
        public int chunksAhead = 6;
        public int chunksBehind = 1;
        public int chunksPerTheme = 6;
        public float safeStartDistance = 60f;

        [Header("Spawning")]
        public float minRowSpacing = 15f;
        public float rowSpacingSeconds = 0.95f;
        public float powerUpChance = 0.07f;
        public float gemChance = 0.12f;
        public float keyChance = 0.03f;
        public float chestChance = 0.025f;
        public float artifactChance = 0.008f;

        [Header("Input")]
        [Tooltip("Minimum swipe length as a fraction of screen height (divided by the sensitivity setting).")]
        public float swipeMinFraction = 0.06f;

        public float TrackWidth { get { return laneWidth * 3f + 1f; } }
        public float LaneX(int lane) { return (lane - 1) * laneWidth; }
    }
}
