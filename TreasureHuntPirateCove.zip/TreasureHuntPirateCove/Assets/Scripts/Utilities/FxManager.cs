using UnityEngine;
using UnityEngine.Rendering;

namespace TreasureHunt
{
    /// <summary>
    /// One shared world-space particle system per effect type. Effects are emitted with
    /// EmitParams, so there is zero instantiation or allocation per pickup/explosion.
    /// </summary>
    public class FxManager : MonoBehaviour
    {
        public static FxManager Instance { get; private set; }
        ParticleSystem sparkle, smoke, fire, splash, dust;

        public static ParticleSystem MakeSystem(string name, Transform parent, bool worldSpace, bool loop,
            float rate, float lifeMin, float lifeMax, float speedMin, float speedMax, float sizeMin, float sizeMax,
            Color color, float gravity, ParticleSystemShapeType shape, float radius, int max)
        {
            GameObject go = new GameObject(name);
            go.transform.SetParent(parent, false);
            ParticleSystem ps = go.AddComponent<ParticleSystem>();
            ps.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
            ParticleSystem.MainModule main = ps.main;
            main.duration = 1f;
            main.loop = loop;
            main.playOnAwake = loop;
            main.startLifetime = new ParticleSystem.MinMaxCurve(lifeMin, lifeMax);
            main.startSpeed = new ParticleSystem.MinMaxCurve(speedMin, speedMax);
            main.startSize = new ParticleSystem.MinMaxCurve(sizeMin, sizeMax);
            main.startColor = color;
            main.gravityModifier = gravity;
            main.maxParticles = max;
            main.simulationSpace = worldSpace ? ParticleSystemSimulationSpace.World : ParticleSystemSimulationSpace.Local;
            ParticleSystem.EmissionModule em = ps.emission;
            em.rateOverTime = rate;
            ParticleSystem.ShapeModule sh = ps.shape;
            sh.shapeType = shape;
            sh.radius = radius;
            ParticleSystem.ColorOverLifetimeModule col = ps.colorOverLifetime;
            col.enabled = true;
            Gradient g = new Gradient();
            g.SetKeys(new GradientColorKey[] { new GradientColorKey(Color.white, 0f), new GradientColorKey(Color.white, 1f) },
                      new GradientAlphaKey[] { new GradientAlphaKey(1f, 0f), new GradientAlphaKey(0.8f, 0.5f), new GradientAlphaKey(0f, 1f) });
            col.color = new ParticleSystem.MinMaxGradient(g);
            ParticleSystemRenderer r = go.GetComponent<ParticleSystemRenderer>();
            r.sharedMaterial = MaterialLibrary.Particle();
            r.shadowCastingMode = ShadowCastingMode.Off;
            r.receiveShadows = false;
            if (loop) ps.Play();
            return ps;
        }

        void Awake()
        {
            Instance = this;
            sparkle = MakeSystem("FX_Sparkle", transform, true, false, 0, 0.35f, 0.7f, 2f, 5f, 0.08f, 0.22f, Color.white, 0.6f, ParticleSystemShapeType.Sphere, 0.3f, 400);
            smoke = MakeSystem("FX_Smoke", transform, true, false, 0, 0.8f, 1.6f, 0.5f, 2f, 0.6f, 1.4f, new Color(0.5f, 0.48f, 0.45f, 0.7f), -0.1f, ParticleSystemShapeType.Sphere, 0.4f, 200);
            fire = MakeSystem("FX_Fire", transform, true, false, 0, 0.3f, 0.7f, 3f, 8f, 0.3f, 0.9f, new Color(1f, 0.55f, 0.1f), 0f, ParticleSystemShapeType.Sphere, 0.5f, 300);
            splash = MakeSystem("FX_Splash", transform, true, false, 0, 0.5f, 1f, 3f, 7f, 0.15f, 0.4f, new Color(0.75f, 0.9f, 1f), 1.5f, ParticleSystemShapeType.Hemisphere, 0.5f, 200);
            dust = MakeSystem("FX_Dust", transform, true, false, 0, 0.5f, 1.1f, 1f, 3f, 0.3f, 0.8f, new Color(0.7f, 0.62f, 0.5f, 0.8f), 0.2f, ParticleSystemShapeType.Hemisphere, 0.8f, 200);
        }

        void OnDestroy() { if (Instance == this) Instance = null; }

        static void Emit(ParticleSystem ps, Vector3 pos, Color c, int count)
        {
            if (ps == null) return;
            ParticleSystem.EmitParams ep = new ParticleSystem.EmitParams();
            ep.position = pos;
            ep.startColor = c;
            ep.applyShapeToPosition = true;
            ps.Emit(ep, count);
        }

        public void Sparkle(Vector3 pos, Color c, int count = 14) { Emit(sparkle, pos, c, count); }
        public void Smoke(Vector3 pos, int count = 10) { Emit(smoke, pos, new Color(0.55f, 0.52f, 0.5f, 0.7f), count); }
        public void Explosion(Vector3 pos)
        {
            Emit(fire, pos, new Color(1f, 0.6f, 0.15f), 40);
            Emit(fire, pos, new Color(1f, 0.25f, 0.05f), 20);
            Emit(smoke, pos, new Color(0.3f, 0.28f, 0.26f, 0.8f), 20);
        }
        public void Splash(Vector3 pos) { Emit(splash, pos, new Color(0.8f, 0.92f, 1f), 40); }
        public void Dust(Vector3 pos, int count = 18) { Emit(dust, pos, new Color(0.72f, 0.64f, 0.52f, 0.8f), count); }
    }
}
