using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace TreasureHunt
{
    /// <summary>
    /// Central material palette. Works with the Built-in pipeline (Standard shader) and URP (Lit).
    /// Saved material assets from the PrefabCatalog are preferred so builds include the right
    /// shader variants; otherwise materials are created at runtime from the spec table below.
    /// Runtime code never edits a returned material, so saved assets are never modified in play mode.
    /// </summary>
    public static class MaterialLibrary
    {
        public static PrefabCatalog Catalog;
        static readonly Dictionary<string, Material> cache = new Dictionary<string, Material>();

        public static IEnumerable<Material> All { get { return cache.Values; } }

        public static void ClearCache() { cache.Clear(); }

        public static bool IsURP { get { return GraphicsSettings.currentRenderPipeline != null; } }

        struct Spec
        {
            public string name; public Color color; public float smooth; public float metal;
            public Color emission; public string tex; public Vector2 tiling; public bool transparent;
        }

        static Spec S(string n, float r, float g, float b, float smooth = 0.15f, float metal = 0f)
        {
            Spec s = new Spec();
            s.name = n; s.color = new Color(r, g, b, 1); s.smooth = smooth; s.metal = metal;
            s.emission = Color.black; s.tiling = Vector2.one;
            return s;
        }

        static Spec E(Spec s, float r, float g, float b) { s.emission = new Color(r, g, b, 1); return s; }
        static Spec T(Spec s, string tex, float tx, float ty) { s.tex = tex; s.tiling = new Vector2(tx, ty); return s; }
        static Spec A(Spec s, float alpha) { s.transparent = true; s.color.a = alpha; return s; }

        static Spec[] specs;

        static Spec[] Specs
        {
            get
            {
                if (specs != null) return specs;
                specs = new Spec[]
                {
                    // Wood & structures
                    S("Wood", 0.45f, 0.29f, 0.16f),
                    S("WoodDark", 0.27f, 0.17f, 0.1f),
                    S("WoodLight", 0.62f, 0.45f, 0.28f),
                    T(S("Planks", 0.62f, 0.42f, 0.25f), "planks", 1, 2),
                    T(S("PlanksRotten", 0.32f, 0.26f, 0.2f), "planksRotten", 1, 3),
                    T(S("DeckPlanks", 0.46f, 0.32f, 0.2f), "deck", 1, 2),
                    T(S("RescuePlanks", 0.7f, 0.55f, 0.3f), "planks", 1, 12),
                    T(S("SandPath", 0.92f, 0.78f, 0.52f), "sand", 2, 4),
                    T(S("Sand", 0.95f, 0.83f, 0.58f), "sand", 6, 6),
                    T(S("StoneCave", 0.42f, 0.42f, 0.48f), "stoneCave", 1, 2),
                    T(S("StoneTemple", 0.78f, 0.64f, 0.4f, 0.25f), "stoneTemple", 1, 2),
                    T(S("FortStone", 0.6f, 0.57f, 0.5f), "stoneFort", 2, 2),
                    T(S("Rock", 0.5f, 0.48f, 0.45f), "rock", 1, 1),
                    T(S("RockDark", 0.25f, 0.24f, 0.27f), "rock", 1, 1),
                    S("PalmTrunk", 0.5f, 0.36f, 0.22f),
                    S("PalmLeaf", 0.18f, 0.55f, 0.2f),
                    S("Bush", 0.12f, 0.42f, 0.16f),
                    S("IslandGreen", 0.16f, 0.38f, 0.18f),
                    S("Sail", 0.88f, 0.84f, 0.72f),
                    S("SailDark", 0.25f, 0.22f, 0.2f),
                    S("Rope", 0.72f, 0.6f, 0.4f),
                    S("Iron", 0.2f, 0.2f, 0.22f, 0.45f, 0.7f),
                    S("IronRust", 0.38f, 0.22f, 0.14f, 0.2f, 0.4f),
                    S("Silver", 0.8f, 0.82f, 0.86f, 0.7f, 0.9f),
                    S("Spike", 0.6f, 0.6f, 0.62f, 0.6f, 0.8f),
                    S("Black", 0.06f, 0.06f, 0.07f),
                    S("Cannon", 0.12f, 0.12f, 0.13f, 0.5f, 0.6f),
                    S("Barrel", 0.52f, 0.3f, 0.15f),
                    E(S("ExplosiveRed", 0.75f, 0.1f, 0.06f), 0.35f, 0.02f, 0f),
                    // Water
                    S("Water", 0.04f, 0.22f, 0.42f, 0.92f),
                    T(A(E(S("Waterfall", 0.8f, 0.92f, 1f, 0.8f), 0.15f, 0.25f, 0.3f), 0.75f), "water", 1, 2),
                    A(S("Mist", 0.9f, 0.95f, 1f), 0.35f),
                    // Treasure & glowing things
                    E(S("Gold", 1f, 0.76f, 0.22f, 0.75f, 1f), 0.35f, 0.22f, 0.02f),
                    E(S("GoldGlow", 1f, 0.8f, 0.3f, 0.8f, 1f), 1.1f, 0.7f, 0.1f),
                    E(S("Coin", 1f, 0.78f, 0.2f, 0.8f, 1f), 0.9f, 0.55f, 0.05f),
                    E(S("Gem", 0.2f, 0.5f, 1f, 0.9f), 0.15f, 0.45f, 1.4f),
                    E(S("Crystal", 0.3f, 0.9f, 1f, 0.9f), 0.2f, 1.2f, 1.5f),
                    E(S("CrystalPurple", 0.7f, 0.35f, 1f, 0.9f), 0.9f, 0.3f, 1.4f),
                    T(E(S("Glyph", 0.3f, 0.3f, 0.35f), 0.2f, 1.1f, 1.3f), "glyphs", 1, 1),
                    E(S("Flame", 1f, 0.55f, 0.1f), 2.5f, 1.1f, 0.15f),
                    E(S("Lantern", 1f, 0.85f, 0.45f), 1.8f, 1.3f, 0.4f),
                    E(S("Moon", 0.95f, 0.95f, 0.85f), 1.3f, 1.3f, 1.15f),
                    S("ChestWood", 0.45f, 0.24f, 0.1f),
                    // Characters
                    S("SkinTone", 0.88f, 0.66f, 0.5f),
                    S("PirateCoat", 0.62f, 0.08f, 0.08f),
                    S("PirateShirt", 0.92f, 0.9f, 0.82f),
                    S("PiratePants", 0.25f, 0.18f, 0.12f),
                    S("PirateBoots", 0.1f, 0.07f, 0.05f, 0.35f),
                    S("HatBlack", 0.08f, 0.07f, 0.07f),
                    S("Bandana", 0.85f, 0.15f, 0.12f),
                    S("GuardCoat", 0.12f, 0.16f, 0.35f),
                    S("Beard", 0.18f, 0.1f, 0.06f),
                    // Effects / power-ups
                    A(E(S("Warning", 1f, 0.15f, 0.1f), 1.4f, 0.1f, 0.05f), 0.55f),
                    E(S("WarningSolid", 1f, 0.15f, 0.1f), 1.8f, 0.15f, 0.05f),
                    A(E(S("ShieldBubble", 0.3f, 0.75f, 1f, 0.9f), 0.2f, 0.6f, 1.2f), 0.28f),
                    A(E(S("Beam", 1f, 0.85f, 0.3f), 1.2f, 0.9f, 0.2f), 0.3f),
                    A(E(S("PickupBubble", 0.9f, 0.95f, 1f, 0.9f), 0.2f, 0.25f, 0.3f), 0.22f),
                    E(S("MagnetRed", 0.85f, 0.1f, 0.1f, 0.6f), 0.4f, 0.02f, 0.02f),
                    E(S("SpeedGreen", 0.3f, 1f, 0.3f), 0.25f, 1.1f, 0.25f),
                    E(S("PurpleGlow", 0.7f, 0.3f, 1f), 0.8f, 0.25f, 1.3f),
                    E(S("ShieldBlue", 0.2f, 0.5f, 1f, 0.7f, 0.5f), 0.1f, 0.35f, 1f),
                    E(S("Teal", 0.1f, 0.7f, 0.7f, 0.6f), 0.05f, 0.6f, 0.6f),
                };
                return specs;
            }
        }

        public static IEnumerable<string> AllNames
        {
            get { Spec[] s = Specs; for (int i = 0; i < s.Length; i++) yield return s[i].name; }
        }

        static Texture2D TextureFor(string id)
        {
            switch (id)
            {
                case "planks": return TextureFactory.Planks("TexPlanks", new Color(1f, 0.85f, 0.65f), 1);
                case "planksRotten": return TextureFactory.Planks("TexPlanksRotten", new Color(0.8f, 0.75f, 0.7f), 9);
                case "deck": return TextureFactory.Planks("TexDeck", new Color(0.95f, 0.85f, 0.75f), 5);
                case "sand": return TextureFactory.Speckle("TexSand", Color.white, 0.12f, 0.15f, 2);
                case "rock": return TextureFactory.Speckle("TexRock", Color.white, 0.09f, 0.3f, 4);
                case "stoneCave": return TextureFactory.Stone("TexStoneCave", Color.white, 6);
                case "stoneTemple": return TextureFactory.Stone("TexStoneTemple", Color.white, 8);
                case "stoneFort": return TextureFactory.Stone("TexStoneFort", Color.white, 11);
                case "water": return TextureFactory.WaterStreaks();
                case "glyphs": return TextureFactory.Glyphs();
            }
            return null;
        }

        public static Shader LitShader
        {
            get
            {
                Shader s = null;
                if (IsURP) s = Shader.Find("Universal Render Pipeline/Lit");
                if (s == null) s = Shader.Find("Standard");
                if (s == null) s = Shader.Find("Diffuse");
                return s;
            }
        }

        public static Material Get(string name)
        {
            Material m;
            if (cache.TryGetValue(name, out m) && m != null) return m;
            if (Catalog != null)
            {
                m = Catalog.FindMaterial(name);
                if (m != null) { cache[name] = m; return m; }
            }
            Spec[] all = Specs;
            for (int i = 0; i < all.Length; i++)
            {
                if (all[i].name == name)
                {
                    m = Create(all[i]);
                    cache[name] = m;
                    return m;
                }
            }
            Debug.LogWarning("[TreasureHunt] Unknown material '" + name + "', using magenta fallback.");
            Spec f = S(name, 1, 0, 1);
            m = Create(f);
            cache[name] = m;
            return m;
        }

        static Material Create(Spec s)
        {
            Material m = new Material(LitShader);
            m.name = s.name;
            m.color = s.color;
            m.SetColor("_BaseColor", s.color);
            m.SetFloat("_Glossiness", s.smooth);
            m.SetFloat("_Smoothness", s.smooth);
            m.SetFloat("_Metallic", s.metal);
            if (!string.IsNullOrEmpty(s.tex))
            {
                Texture2D t = TextureFor(s.tex);
                if (t != null)
                {
                    m.mainTexture = t;
                    m.mainTextureScale = s.tiling;
                    if (s.tex == "glyphs") m.SetTexture("_EmissionMap", t);
                }
            }
            if (s.emission.maxColorComponent > 0.001f)
            {
                m.EnableKeyword("_EMISSION");
                m.SetColor("_EmissionColor", s.emission);
                m.globalIlluminationFlags = MaterialGlobalIlluminationFlags.None;
            }
            if (s.transparent) MakeTransparent(m);
            m.enableInstancing = true;
            return m;
        }

        public static void MakeTransparent(Material m)
        {
            if (IsURP)
            {
                m.SetFloat("_Surface", 1f);
                m.SetFloat("_Blend", 0f);
                m.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");
            }
            else
            {
                m.SetFloat("_Mode", 2f); // Fade
                m.EnableKeyword("_ALPHABLEND_ON");
                m.DisableKeyword("_ALPHATEST_ON");
                m.DisableKeyword("_ALPHAPREMULTIPLY_ON");
            }
            m.SetOverrideTag("RenderType", "Transparent");
            m.SetInt("_SrcBlend", (int)BlendMode.SrcAlpha);
            m.SetInt("_DstBlend", (int)BlendMode.OneMinusSrcAlpha);
            m.SetInt("_ZWrite", 0);
            m.renderQueue = (int)RenderQueue.Transparent;
        }

        /// <summary>Additive-style particle material using the always-available Sprites/Default shader.</summary>
        public static Material Particle()
        {
            Material m;
            if (cache.TryGetValue("Particle", out m) && m != null) return m;
            if (Catalog != null)
            {
                m = Catalog.FindMaterial("Particle");
                if (m != null) { cache["Particle"] = m; return m; }
            }
            Shader sh = Shader.Find("Sprites/Default");
            if (sh == null) sh = LitShader;
            m = new Material(sh);
            m.name = "Particle";
            m.mainTexture = TextureFactory.SoftCircle();
            cache["Particle"] = m;
            return m;
        }

        /// <summary>Creates (never caches into assets) the sunset procedural skybox.</summary>
        public static Material CreateSkybox()
        {
            Shader sh = Shader.Find("Skybox/Procedural");
            if (sh == null) return null;
            Material m = new Material(sh);
            m.name = "PirateSunsetSky";
            m.SetFloat("_SunSize", 0.06f);
            m.SetFloat("_SunSizeConvergence", 4f);
            m.SetFloat("_AtmosphereThickness", 1.6f);
            m.SetColor("_SkyTint", new Color(0.7f, 0.5f, 0.55f));
            m.SetColor("_GroundColor", new Color(0.12f, 0.2f, 0.3f));
            m.SetFloat("_Exposure", 1.15f);
            return m;
        }
    }
}
