using UnityEngine;

namespace TreasureHunt
{
    /// <summary>Constant rotation around a local axis.</summary>
    public class Rotator : MonoBehaviour
    {
        public Vector3 axis = Vector3.up;
        public float degreesPerSecond = 90f;
        void Update() { transform.Rotate(axis, degreesPerSecond * Time.deltaTime, Space.Self); }
    }

    /// <summary>Vertical bobbing around the start position.</summary>
    public class Bobber : MonoBehaviour
    {
        public float amplitude = 0.15f;
        public float frequency = 2f;
        public float phase;
        Vector3 basePos;
        bool init;
        void OnEnable() { if (!init) { basePos = transform.localPosition; init = true; } }
        void Update()
        {
            Vector3 p = basePos;
            p.y += Mathf.Sin(Time.time * frequency + phase) * amplitude;
            transform.localPosition = p;
        }
    }

    /// <summary>Flickering torch / lantern light and flame scale.</summary>
    public class Flicker : MonoBehaviour
    {
        public Light targetLight;
        public Transform flame;
        public float baseIntensity = 1.6f;
        float seed;
        Vector3 flameScale;
        void Awake()
        {
            seed = Random.value * 100f;
            if (flame != null) flameScale = flame.localScale;
        }
        void Update()
        {
            float n = Mathf.PerlinNoise(seed, Time.time * 6f);
            if (targetLight != null) targetLight.intensity = baseIntensity * (0.75f + n * 0.5f);
            if (flame != null) flame.localScale = flameScale * (0.85f + n * 0.3f);
        }
    }

    /// <summary>Scrolls a renderer's main texture with a MaterialPropertyBlock (does not touch the shared material).</summary>
    public class TextureScroller : MonoBehaviour
    {
        public Vector2 speed = new Vector2(0, -1.2f);
        public Vector2 tiling = new Vector2(1, 2);
        Renderer rend;
        MaterialPropertyBlock block;
        static readonly int MainTexST = Shader.PropertyToID("_MainTex_ST");
        static readonly int BaseMapST = Shader.PropertyToID("_BaseMap_ST");
        void Awake() { rend = GetComponent<Renderer>(); block = new MaterialPropertyBlock(); }
        void Update()
        {
            if (rend == null) return;
            Vector2 o = speed * Time.time;
            Vector4 st = new Vector4(tiling.x, tiling.y, o.x % 1f, o.y % 1f);
            rend.GetPropertyBlock(block);
            block.SetVector(MainTexST, st);
            block.SetVector(BaseMapST, st);
            rend.SetPropertyBlock(block);
        }
    }

    /// <summary>Uniform scale pulse (warning markers, glowing treasure).</summary>
    public class Pulse : MonoBehaviour
    {
        public float amount = 0.15f;
        public float speed = 6f;
        Vector3 baseScale;
        bool init;
        void OnEnable() { if (!init) { baseScale = transform.localScale; init = true; } }
        void Update() { transform.localScale = baseScale * (1f + Mathf.Sin(Time.time * speed) * amount); }
    }
}
