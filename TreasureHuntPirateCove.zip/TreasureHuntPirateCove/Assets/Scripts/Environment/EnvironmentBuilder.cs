using UnityEngine;

namespace TreasureHunt
{
    /// <summary>
    /// Builds every scenery prefab: per-theme side structures (40 m long, pivot at chunk start),
    /// gateways, ground tiles and individual props. Static props are mesh-combined per material.
    /// </summary>
    public static class EnvironmentBuilder
    {
        const PrimitiveType Cube = PrimitiveType.Cube, Cyl = PrimitiveType.Cylinder, Sph = PrimitiveType.Sphere, Cap = PrimitiveType.Capsule;

        public static readonly string[] IslandProps = { "dec_palm", "dec_palm", "dec_rock", "dec_bush", "dec_torch", "dec_chest", "dec_waterfall", "dec_watchtower", "dec_palm", "dec_barrels" };
        public static readonly string[] HarborProps = { "dec_barrels", "dec_crates", "dec_lantern", "dec_anchor", "dec_cannon", "dec_ship", "dec_watchtower", "dec_fort", "dec_ropecoil", "dec_lantern" };
        public static readonly string[] WreckProps = { "dec_wreck", "dec_mast", "dec_barrels", "dec_crates", "dec_rock", "dec_anchor", "dec_mast", "dec_ship" };
        public static readonly string[] CaveProps = { "dec_crystals", "dec_crystals", "dec_stalagmite", "dec_symbols", "dec_torch_lit", "dec_treasurepile", "dec_stalagmite" };
        public static readonly string[] TempleProps = { "dec_pillar", "dec_ruin", "dec_statue", "dec_treasurepile", "dec_chest", "dec_symbols", "dec_brazier", "dec_pillar" };

        public static readonly string[] AllDecorKeys =
        {
            "dec_palm", "dec_rock", "dec_bush", "dec_torch", "dec_torch_lit", "dec_chest", "dec_waterfall", "dec_watchtower", "dec_barrels",
            "dec_crates", "dec_lantern", "dec_anchor", "dec_cannon", "dec_ship", "dec_fort", "dec_ropecoil", "dec_wreck", "dec_mast",
            "dec_crystals", "dec_stalagmite", "dec_symbols", "dec_treasurepile", "dec_pillar", "dec_ruin", "dec_statue", "dec_brazier", "dec_platform"
        };

        public static string[] PropsFor(ThemeId t)
        {
            switch (t)
            {
                case ThemeId.TropicalIsland: return IslandProps;
                case ThemeId.PirateHarbor: return HarborProps;
                case ThemeId.ShipwreckPassage: return WreckProps;
                case ThemeId.HauntedCave: return CaveProps;
                default: return TempleProps;
            }
        }

        /// <summary>Lateral distance band (min,max) from the track centre for a prop in a theme.</summary>
        public static Vector2 OffsetFor(string key, ThemeId t)
        {
            if (key == "dec_ship" || key == "dec_wreck") return new Vector2(20f, 32f);
            if (key == "dec_watchtower" || key == "dec_fort" || key == "dec_waterfall") return new Vector2(13f, 22f);
            if (t == ThemeId.HauntedCave) return new Vector2(4.8f, 5.4f);
            if (t == ThemeId.TreasureTemple) return new Vector2(5.2f, 6.5f);
            if (t == ThemeId.ShipwreckPassage) return new Vector2(6.5f, 10f);
            return new Vector2(5.5f, 11f);
        }

        // ---------------------------------------------------------------- ground
        public static GameObject Ground(string key, string material)
        {
            GameObject g = new GameObject(key);
            g.AddComponent<MeshFilter>().sharedMesh = MeshFactory.Primitive(Cube);
            MeshRenderer r = g.AddComponent<MeshRenderer>();
            r.sharedMaterial = MaterialLibrary.Get(material);
            g.AddComponent<BoxCollider>(); // solid ground (not a trigger)
            return g;
        }

        // ---------------------------------------------------------------- small helpers
        static GameObject Torch(Transform parent, Vector3 pos, bool withLight, float height = 1.6f)
        {
            GameObject t = Proc.Node("Torch", parent, pos);
            t.AddComponent<KeepSeparate>();
            Proc.Part(Cyl, "WoodDark", t.transform, new Vector3(0, height * 0.5f, 0), new Vector3(0.1f, height * 0.5f, 0.1f));
            Proc.Part(Cyl, "Iron", t.transform, new Vector3(0, height, 0), new Vector3(0.22f, 0.08f, 0.22f));
            GameObject flame = Proc.Mesh(MeshFactory.Cone(6), "Flame", t.transform, new Vector3(0, height + 0.05f, 0), new Vector3(0.22f, 0.45f, 0.22f), Vector3.zero, false, "Flame");
            Flicker f = t.AddComponent<Flicker>();
            f.flame = flame.transform;
            FxManager.MakeSystem("Embers", t.transform, false, true, 6, 0.4f, 0.9f, 0.4f, 1f, 0.04f, 0.09f, new Color(1f, 0.6f, 0.2f), -0.3f, ParticleSystemShapeType.Sphere, 0.08f, 12)
                .transform.localPosition = new Vector3(0, height + 0.25f, 0);
            if (withLight)
            {
                Light l = Proc.Node("Light", t.transform, new Vector3(0, height + 0.4f, 0)).AddComponent<Light>();
                l.type = LightType.Point;
                l.color = new Color(1f, 0.62f, 0.3f);
                l.range = 9f;
                l.intensity = 1.6f;
                l.shadows = LightShadows.None;
                f.targetLight = l;
                f.baseIntensity = 1.6f;
            }
            return t;
        }

        static void Palm(Transform p, Vector3 pos, float h, float lean)
        {
            GameObject palm = Proc.Node("Palm", p, pos);
            Vector3 top = Vector3.zero;
            int segs = 5;
            for (int i = 0; i < segs; i++)
            {
                float t = i / (float)segs;
                Vector3 c = new Vector3(lean * t * t, h * (t + 0.5f / segs), 0);
                Proc.Part(Cyl, "PalmTrunk", palm.transform, c, new Vector3(0.32f - t * 0.1f, h / segs * 0.55f, 0.32f - t * 0.1f), new Vector3(0, 0, -lean * 8f * t));
                top = new Vector3(lean, h, 0);
            }
            for (int i = 0; i < 7; i++)
            {
                float a = i * 360f / 7f;
                GameObject leafNode = Proc.Node("Leaf", palm.transform, top);
                leafNode.transform.localRotation = Quaternion.Euler(0, a, 0);
                Proc.Part(Sph, "PalmLeaf", leafNode.transform, new Vector3(0, -0.25f, 1.2f), new Vector3(0.5f, 0.08f, 2.6f), new Vector3(22, 0, 0));
            }
            Proc.Part(Sph, "WoodDark", palm.transform, top + new Vector3(0.1f, -0.2f, 0.1f), Vector3.one * 0.25f);
            Proc.Part(Sph, "WoodDark", palm.transform, top + new Vector3(-0.15f, -0.25f, 0), Vector3.one * 0.25f);
        }

        static void Ship(Transform p, Vector3 pos, bool wrecked)
        {
            GameObject s = Proc.Node("Ship", p, pos);
            if (wrecked) s.transform.localRotation = Quaternion.Euler(0, 0, 18);
            Transform t = s.transform;
            Proc.Part(Cube, "WoodDark", t, new Vector3(0, 0.6f, 0), new Vector3(4.5f, 3f, 16f));
            Proc.Part(Cube, "Wood", t, new Vector3(0, 2.2f, 0), new Vector3(4.7f, 0.3f, 16.2f));
            Proc.Part(Cube, "WoodDark", t, new Vector3(0, 3.2f, -6.5f), new Vector3(4.4f, 2f, 3.5f));
            Proc.Part(Cube, "Gold", t, new Vector3(0, 1.2f, 0), new Vector3(4.6f, 0.15f, 16.1f));
            Proc.Mesh(MeshFactory.Cone(4), "WoodDark", t, new Vector3(0, 0.6f, 9.5f), new Vector3(3.2f, 3.5f, 3f), new Vector3(90, 45, 0));
            for (int i = 0; i < 4; i++)
                Proc.Part(Cyl, "Cannon", t, new Vector3(2.3f, 1.4f, -4f + i * 2.6f), new Vector3(0.3f, 0.35f, 0.3f), new Vector3(0, 0, 90));
            float[] mastZ = { -3f, 2.5f };
            for (int m = 0; m < 2; m++)
            {
                float hgt = wrecked && m == 1 ? 4f : 11f;
                Proc.Part(Cyl, "WoodDark", t, new Vector3(0, 2.2f + hgt * 0.5f, mastZ[m]), new Vector3(0.35f, hgt * 0.5f, 0.35f));
                if (!(wrecked && m == 1))
                {
                    Proc.Part(Cube, wrecked ? "SailDark" : "Sail", t, new Vector3(0, 8f, mastZ[m] + 0.3f), new Vector3(6f, 4.5f, 0.1f), new Vector3(0, 0, wrecked ? 6 : 0));
                    Proc.Part(Cube, wrecked ? "SailDark" : "Sail", t, new Vector3(0, 4.6f, mastZ[m] + 0.3f), new Vector3(5f, 2.2f, 0.1f));
                    Proc.Part(Cyl, "WoodDark", t, new Vector3(0, 10.3f, mastZ[m]), new Vector3(0.15f, 3.3f, 0.15f), new Vector3(0, 0, 90));
                }
            }
            Proc.Part(Cube, "Black", t, new Vector3(0, 13.6f, -3f), new Vector3(0.02f, 1f, 1.6f));
            Proc.Part(Sph, "PirateShirt", t, new Vector3(0.02f, 13.7f, -3.3f), new Vector3(0.02f, 0.4f, 0.4f));
        }

        // ---------------------------------------------------------------- props
        public static GameObject Prop(string key)
        {
            GameObject root = new GameObject(key);
            Transform r = root.transform;
            switch (key)
            {
                case "dec_palm": Palm(r, Vector3.zero, 6.5f, 1.4f); Proc.Part(Sph, "Bush", r, new Vector3(0.6f, 0.2f, 0.4f), new Vector3(1.4f, 0.8f, 1.2f)); break;
                case "dec_rock":
                    Proc.Part(Sph, "Rock", r, new Vector3(0, 0.5f, 0), new Vector3(2.2f, 1.6f, 1.9f), new Vector3(0, 30, 10));
                    Proc.Part(Sph, "RockDark", r, new Vector3(1.1f, 0.3f, 0.5f), new Vector3(1.2f, 0.9f, 1.1f));
                    break;
                case "dec_bush":
                    Proc.Part(Sph, "Bush", r, new Vector3(0, 0.5f, 0), new Vector3(1.8f, 1.2f, 1.6f));
                    Proc.Part(Sph, "PalmLeaf", r, new Vector3(0.7f, 0.4f, 0.3f), new Vector3(1.2f, 0.9f, 1.1f));
                    Proc.Part(Sph, "Bandana", r, new Vector3(0.3f, 1.0f, 0.5f), Vector3.one * 0.2f);
                    break;
                case "dec_torch": Torch(r, Vector3.zero, false); break;
                case "dec_torch_lit": Torch(r, Vector3.zero, true, 2.2f); break;
                case "dec_brazier":
                {
                    Proc.Part(Cyl, "StoneTemple", r, new Vector3(0, 0.6f, 0), new Vector3(0.5f, 0.6f, 0.5f));
                    Proc.Part(Cyl, "Gold", r, new Vector3(0, 1.25f, 0), new Vector3(0.9f, 0.12f, 0.9f));
                    GameObject t = Torch(r, new Vector3(0, 0.1f, 0), true, 1.25f);
                    t.transform.Find("Flame").localScale = new Vector3(0.6f, 0.8f, 0.6f);
                    break;
                }
                case "dec_chest":
                    Proc.Part(Cube, "ChestWood", r, new Vector3(0, 0.3f, 0), new Vector3(1f, 0.6f, 0.65f));
                    Proc.Part(Cube, "ChestWood", r, new Vector3(0, 0.75f, -0.3f), new Vector3(1f, 0.6f, 0.08f), new Vector3(-25, 0, 0));
                    Proc.Part(Sph, "GoldGlow", r, new Vector3(0, 0.62f, 0), new Vector3(0.85f, 0.3f, 0.5f));
                    Proc.Part(Cyl, "Coin", r, new Vector3(0.7f, 0.04f, 0.2f), new Vector3(0.3f, 0.02f, 0.3f));
                    Proc.Part(Cyl, "Coin", r, new Vector3(0.6f, 0.08f, -0.2f), new Vector3(0.3f, 0.02f, 0.3f));
                    FxManager.MakeSystem("Glint", r, false, true, 6, 0.5f, 1f, 0.2f, 0.6f, 0.05f, 0.12f, new Color(1f, 0.85f, 0.3f), -0.1f, ParticleSystemShapeType.Sphere, 0.4f, 12).transform.localPosition = new Vector3(0, 0.8f, 0);
                    break;
                case "dec_waterfall":
                {
                    Proc.Part(Cube, "Rock", r, new Vector3(0, 5f, 2f), new Vector3(9f, 10f, 4f), new Vector3(0, 0, 0));
                    Proc.Part(Sph, "IslandGreen", r, new Vector3(0, 10f, 2f), new Vector3(10f, 2.5f, 5f));
                    Proc.Part(Sph, "RockDark", r, new Vector3(-3.5f, 1f, -0.5f), new Vector3(3f, 2.4f, 2.4f));
                    Proc.Part(Sph, "RockDark", r, new Vector3(3.2f, 0.8f, -0.4f), new Vector3(2.6f, 2f, 2.2f));
                    GameObject fall = Proc.Part(Cube, "Waterfall", r, new Vector3(0, 4.8f, -0.1f), new Vector3(3f, 9.8f, 0.2f), Vector3.zero, false, "Falls");
                    fall.AddComponent<KeepSeparate>();
                    fall.AddComponent<TextureScroller>().tiling = new Vector2(1, 3);
                    Proc.Part(Cyl, "Water", r, new Vector3(0, -0.9f, -1.5f), new Vector3(6f, 0.1f, 3.5f));
                    FxManager.MakeSystem("Mist", r, false, true, 14, 1f, 2f, 0.5f, 1.5f, 0.8f, 1.8f, new Color(1f, 1f, 1f, 0.35f), -0.05f, ParticleSystemShapeType.Sphere, 1.2f, 40).transform.localPosition = new Vector3(0, -0.2f, -1f);
                    break;
                }
                case "dec_watchtower":
                    for (int i = 0; i < 4; i++)
                        Proc.Part(Cyl, "WoodDark", r, new Vector3(i < 2 ? -1.2f : 1.2f, 3.5f, i % 2 == 0 ? -1.2f : 1.2f), new Vector3(0.3f, 3.5f, 0.3f));
                    Proc.Part(Cube, "Planks", r, new Vector3(0, 7f, 0), new Vector3(3.4f, 0.25f, 3.4f));
                    Proc.Part(Cube, "Wood", r, new Vector3(0, 7.6f, 1.6f), new Vector3(3.4f, 1f, 0.15f));
                    Proc.Part(Cube, "Wood", r, new Vector3(0, 7.6f, -1.6f), new Vector3(3.4f, 1f, 0.15f));
                    Proc.Mesh(MeshFactory.Cone(4), "Bush", r, new Vector3(0, 9.2f, 0), new Vector3(4.6f, 1.8f, 4.6f), new Vector3(0, 45, 0));
                    Proc.Part(Cyl, "WoodDark", r, new Vector3(0, 11.2f, 0), new Vector3(0.08f, 1.2f, 0.08f));
                    Proc.Part(Cube, "Black", r, new Vector3(0, 12f, 0.5f), new Vector3(0.02f, 0.8f, 1.1f));
                    for (int i = 0; i < 8; i++) Proc.Part(Cube, "Wood", r, new Vector3(1.4f, 0.4f + i * 0.85f, 0), new Vector3(0.1f, 0.08f, 0.9f));
                    break;
                case "dec_barrels":
                    for (int i = 0; i < 3; i++)
                    {
                        Vector3 bp = new Vector3(i * 0.95f - 0.95f, 0.6f, (i % 2) * 0.4f);
                        Proc.Part(Cyl, "Barrel", r, bp, new Vector3(0.85f, 0.6f, 0.85f));
                        Proc.Part(Cyl, "Iron", r, bp + new Vector3(0, 0.38f, 0), new Vector3(0.88f, 0.04f, 0.88f));
                        Proc.Part(Cyl, "Iron", r, bp - new Vector3(0, 0.38f, 0), new Vector3(0.88f, 0.04f, 0.88f));
                    }
                    Proc.Part(Cyl, "Barrel", r, new Vector3(0, 1.75f, 0.2f), new Vector3(0.85f, 0.6f, 0.85f));
                    break;
                case "dec_crates":
                    Proc.Part(Cube, "Wood", r, new Vector3(0, 0.5f, 0), Vector3.one);
                    Proc.Part(Cube, "WoodLight", r, new Vector3(1.05f, 0.4f, 0.2f), Vector3.one * 0.8f, new Vector3(0, 20, 0));
                    Proc.Part(Cube, "Wood", r, new Vector3(0.3f, 1.35f, 0.1f), Vector3.one * 0.7f, new Vector3(0, -15, 0));
                    break;
                case "dec_lantern":
                {
                    Proc.Part(Cyl, "WoodDark", r, new Vector3(0, 1.4f, 0), new Vector3(0.14f, 1.4f, 0.14f));
                    Proc.Part(Cube, "WoodDark", r, new Vector3(0.35f, 2.75f, 0), new Vector3(0.8f, 0.1f, 0.1f));
                    GameObject lamp = Proc.Node("Lamp", r, new Vector3(0.65f, 2.35f, 0));
                    lamp.AddComponent<KeepSeparate>();
                    Proc.Part(Cube, "Lantern", lamp.transform, Vector3.zero, new Vector3(0.25f, 0.35f, 0.25f), Vector3.zero, false);
                    Proc.Part(Cube, "Iron", lamp.transform, new Vector3(0, 0.22f, 0), new Vector3(0.3f, 0.08f, 0.3f));
                    break;
                }
                case "dec_anchor":
                    Proc.Part(Cyl, "IronRust", r, new Vector3(0, 1.2f, 0), new Vector3(0.25f, 1.1f, 0.25f), new Vector3(0, 0, 15));
                    Proc.Part(Cube, "IronRust", r, new Vector3(0.35f, 2.1f, 0), new Vector3(1.1f, 0.18f, 0.2f), new Vector3(0, 0, 15));
                    Proc.Part(Cube, "IronRust", r, new Vector3(-0.6f, 0.25f, 0), new Vector3(1.1f, 0.22f, 0.22f), new Vector3(0, 0, -20));
                    Proc.Part(Cube, "IronRust", r, new Vector3(0.6f, 0.15f, 0), new Vector3(1.1f, 0.22f, 0.22f), new Vector3(0, 0, 40));
                    Proc.Mesh(MeshFactory.Torus(0.3f, 0.08f), "IronRust", r, new Vector3(0.62f, 2.6f, 0), Vector3.one, new Vector3(90, 0, 15));
                    break;
                case "dec_cannon":
                    Proc.Part(Cube, "WoodDark", r, new Vector3(0, 0.4f, 0), new Vector3(1f, 0.4f, 1.5f));
                    Proc.Part(Cyl, "Cannon", r, new Vector3(0, 0.85f, 0.2f), new Vector3(0.45f, 0.9f, 0.45f), new Vector3(70, 0, 0));
                    Proc.Part(Cyl, "Wood", r, new Vector3(-0.55f, 0.25f, 0), new Vector3(0.5f, 0.06f, 0.5f), new Vector3(0, 0, 90));
                    Proc.Part(Cyl, "Wood", r, new Vector3(0.55f, 0.25f, 0), new Vector3(0.5f, 0.06f, 0.5f), new Vector3(0, 0, 90));
                    for (int i = 0; i < 5; i++) Proc.Part(Sph, "Cannon", r, new Vector3(-0.9f + (i % 3) * 0.3f, 0.15f + (i / 3) * 0.25f, -0.9f), Vector3.one * 0.3f);
                    break;
                case "dec_platform":
                    Proc.Part(Cube, "Planks", r, new Vector3(0, -0.13f, 0), new Vector3(3.6f, 0.25f, 3.6f));
                    for (int i = 0; i < 4; i++)
                        Proc.Part(Cyl, "WoodDark", r, new Vector3(i < 2 ? -1.6f : 1.6f, -1.2f, i % 2 == 0 ? -1.6f : 1.6f), new Vector3(0.3f, 1.2f, 0.3f));
                    Proc.Part(Cube, "WoodDark", r, new Vector3(0, -0.3f, 1.75f), new Vector3(3.7f, 0.15f, 0.15f));
                    break;
                case "dec_ship": Ship(r, new Vector3(0, -0.8f, 0), false); break;
                case "dec_wreck": Ship(r, new Vector3(0, -2.4f, 0), true); break;
                case "dec_fort":
                    Proc.Part(Cube, "FortStone", r, new Vector3(0, 1.5f, 0), new Vector3(3f, 7f, 12f));
                    for (int i = 0; i < 6; i++) Proc.Part(Cube, "FortStone", r, new Vector3(-1.2f, 5.4f, -5f + i * 2f), new Vector3(0.6f, 0.8f, 1f));
                    Proc.Part(Cyl, "FortStone", r, new Vector3(0, 2.5f, 6.5f), new Vector3(3.6f, 4.5f, 3.6f));
                    Proc.Mesh(MeshFactory.Cone(8), "WoodDark", r, new Vector3(0, 7f, 6.5f), new Vector3(4.2f, 2.5f, 4.2f), Vector3.zero);
                    Proc.Part(Cyl, "Cannon", r, new Vector3(-1.4f, 4.6f, -2f), new Vector3(0.35f, 0.7f, 0.35f), new Vector3(0, 0, 80));
                    Proc.Part(Cyl, "Cannon", r, new Vector3(-1.4f, 4.6f, 2f), new Vector3(0.35f, 0.7f, 0.35f), new Vector3(0, 0, 80));
                    break;
                case "dec_ropecoil":
                    Proc.Mesh(MeshFactory.Torus(0.4f, 0.1f), "Rope", r, new Vector3(0, 0.1f, 0), Vector3.one, Vector3.zero);
                    Proc.Mesh(MeshFactory.Torus(0.35f, 0.1f), "Rope", r, new Vector3(0, 0.28f, 0), Vector3.one, Vector3.zero);
                    Proc.Part(Cyl, "WoodDark", r, new Vector3(1f, 0.5f, 0), new Vector3(0.35f, 0.5f, 0.35f));
                    break;
                case "dec_mast":
                    Proc.Part(Cyl, "WoodDark", r, new Vector3(0, 2.5f, 0), new Vector3(0.45f, 3.2f, 0.45f), new Vector3(0, 0, 35));
                    Proc.Part(Cube, "SailDark", r, new Vector3(-1.5f, 3.2f, 0.3f), new Vector3(3f, 2.4f, 0.08f), new Vector3(0, 0, 35));
                    Proc.Part(Cyl, "Rope", r, new Vector3(0.8f, 1.5f, 0), new Vector3(0.04f, 2f, 0.04f), new Vector3(0, 0, -30));
                    Proc.Part(Cube, "Wood", r, new Vector3(0.8f, 0.1f, 0.6f), new Vector3(2f, 0.15f, 0.4f), new Vector3(0, 30, 0));
                    break;
                case "dec_crystals":
                {
                    string[] mats = { "Crystal", "CrystalPurple" };
                    for (int i = 0; i < 5; i++)
                    {
                        float a = i * 72f;
                        Proc.Mesh(MeshFactory.Octahedron(), mats[i % 2], r, new Vector3(Mathf.Cos(a * Mathf.Deg2Rad) * 0.4f, 0.6f + (i % 3) * 0.3f, Mathf.Sin(a * Mathf.Deg2Rad) * 0.4f),
                            new Vector3(0.35f, 1.4f + (i % 3) * 0.5f, 0.35f), new Vector3(Mathf.Cos(a * Mathf.Deg2Rad) * 25f, 0, Mathf.Sin(a * Mathf.Deg2Rad) * 25f), false);
                    }
                    Proc.Part(Sph, "RockDark", r, new Vector3(0, 0.1f, 0), new Vector3(1.6f, 0.6f, 1.4f));
                    GameObject glow = Proc.Node("Glow", r, new Vector3(0, 1.2f, 0));
                    glow.AddComponent<KeepSeparate>();
                    Light l = glow.AddComponent<Light>();
                    l.type = LightType.Point; l.color = new Color(0.3f, 0.85f, 1f); l.range = 6f; l.intensity = 1.2f; l.shadows = LightShadows.None;
                    break;
                }
                case "dec_stalagmite":
                    Proc.Mesh(MeshFactory.Cone(7), "RockDark", r, Vector3.zero, new Vector3(1.2f, 3.2f, 1.2f), Vector3.zero);
                    Proc.Mesh(MeshFactory.Cone(7), "Rock", r, new Vector3(0.7f, 0, 0.3f), new Vector3(0.7f, 1.8f, 0.7f), Vector3.zero);
                    Proc.Mesh(MeshFactory.Cone(7), "RockDark", r, new Vector3(0, 9f, 0), new Vector3(1f, 2.5f, 1f), new Vector3(180, 0, 0));
                    break;
                case "dec_symbols":
                    Proc.Part(Cube, "StoneCave", r, new Vector3(0, 1.8f, 0), new Vector3(0.6f, 3.6f, 2.6f));
                    Proc.Part(Cube, "Glyph", r, new Vector3(-0.31f, 2f, 0), new Vector3(0.02f, 2.4f, 2.2f), Vector3.zero, false);
                    Proc.Part(Cube, "Glyph", r, new Vector3(0.31f, 2f, 0), new Vector3(0.02f, 2.4f, 2.2f), Vector3.zero, false);
                    break;
                case "dec_treasurepile":
                    Proc.Part(Sph, "Gold", r, new Vector3(0, 0.1f, 0), new Vector3(2.4f, 1f, 2f));
                    Proc.Part(Sph, "GoldGlow", r, new Vector3(0.3f, 0.45f, 0.1f), new Vector3(1.2f, 0.6f, 1f));
                    for (int i = 0; i < 6; i++) Proc.Part(Cyl, "Coin", r, new Vector3(-0.9f + i * 0.35f, 0.5f + (i % 2) * 0.15f, -0.5f), new Vector3(0.3f, 0.02f, 0.3f), new Vector3(60, i * 30, 0), false);
                    Proc.Mesh(MeshFactory.Octahedron(), "Gem", r, new Vector3(-0.4f, 0.75f, 0.2f), new Vector3(0.3f, 0.45f, 0.3f), Vector3.zero, false);
                    Proc.Mesh(MeshFactory.Octahedron(), "CrystalPurple", r, new Vector3(0.6f, 0.6f, -0.3f), new Vector3(0.25f, 0.35f, 0.25f), Vector3.zero, false);
                    FxManager.MakeSystem("Glint", r, false, true, 8, 0.5f, 1f, 0.2f, 0.6f, 0.05f, 0.12f, new Color(1f, 0.85f, 0.3f), -0.1f, ParticleSystemShapeType.Sphere, 0.9f, 16).transform.localPosition = new Vector3(0, 0.8f, 0);
                    break;
                case "dec_pillar":
                    Proc.Part(Cube, "StoneTemple", r, new Vector3(0, 0.3f, 0), new Vector3(1.4f, 0.6f, 1.4f));
                    Proc.Part(Cyl, "StoneTemple", r, new Vector3(0, 3.2f, 0), new Vector3(0.9f, 2.6f, 0.9f));
                    Proc.Part(Cube, "StoneTemple", r, new Vector3(0, 6f, 0), new Vector3(1.5f, 0.5f, 1.5f));
                    Proc.Part(Cyl, "Gold", r, new Vector3(0, 5.6f, 0), new Vector3(1f, 0.08f, 1f));
                    Proc.Part(Cyl, "Gold", r, new Vector3(0, 0.75f, 0), new Vector3(1f, 0.08f, 1f));
                    break;
                case "dec_ruin":
                    Proc.Part(Cube, "StoneTemple", r, new Vector3(0, 1f, 0), new Vector3(0.8f, 2f, 4f));
                    Proc.Part(Cube, "StoneTemple", r, new Vector3(0, 2.4f, -1f), new Vector3(0.8f, 0.8f, 2f));
                    Proc.Part(Cube, "StoneTemple", r, new Vector3(0.8f, 0.3f, 1.5f), new Vector3(0.9f, 0.6f, 0.9f), new Vector3(10, 30, 15));
                    Proc.Part(Cube, "Glyph", r, new Vector3(-0.41f, 1.2f, 0), new Vector3(0.02f, 1.2f, 3f), Vector3.zero, false);
                    break;
                case "dec_statue":
                    Proc.Part(Cube, "StoneTemple", r, new Vector3(0, 0.6f, 0), new Vector3(1.4f, 1.2f, 1.4f));
                    Proc.Part(Cyl, "Gold", r, new Vector3(0, 2f, 0), new Vector3(0.7f, 0.9f, 0.6f));
                    Proc.Part(Sph, "Gold", r, new Vector3(0, 3.3f, 0), new Vector3(0.8f, 0.9f, 0.8f));
                    Proc.Part(Cube, "Gold", r, new Vector3(0, 3.9f, 0), new Vector3(1f, 0.2f, 0.3f));
                    Proc.Mesh(MeshFactory.Octahedron(), "Gem", r, new Vector3(-0.17f, 3.4f, -0.35f), new Vector3(0.15f, 0.15f, 0.08f), Vector3.zero, false);
                    Proc.Mesh(MeshFactory.Octahedron(), "Gem", r, new Vector3(0.17f, 3.4f, -0.35f), new Vector3(0.15f, 0.15f, 0.08f), Vector3.zero, false);
                    break;
            }
            Proc.CombineByMaterial(root);
            return root;
        }

        // ---------------------------------------------------------------- side structures (one per chunk)
        public static GameObject Side(ThemeId theme, float length)
        {
            GameObject root = new GameObject(ThemeInfo.SideKey(theme));
            Transform r = root.transform;
            float half = length * 0.5f;
            switch (theme)
            {
                case ThemeId.TropicalIsland:
                    for (int s = -1; s <= 1; s += 2)
                    {
                        Proc.Part(Cube, "Sand", r, new Vector3(s * 16f, -0.55f, half), new Vector3(23.5f, 0.7f, length + 0.2f));
                        Proc.Part(Sph, "IslandGreen", r, new Vector3(s * 20f, -0.2f, half - 8f), new Vector3(9f, 1.6f, 12f));
                        Proc.Part(Sph, "Bush", r, new Vector3(s * 9f, -0.1f, half + 10f), new Vector3(3f, 1.2f, 3f));
                        for (int i = 0; i < 4; i++)
                            Proc.Part(Cube, "WoodDark", r, new Vector3(s * 4.5f, 0.15f, i * 10f + 2f), new Vector3(0.18f, 0.5f, 0.18f));
                    }
                    break;
                case ThemeId.PirateHarbor:
                    for (int s = -1; s <= 1; s += 2)
                    {
                        for (int i = 0; i < 10; i++)
                            Proc.Part(Cyl, "WoodDark", r, new Vector3(s * 4.3f, -1.4f, i * 4f + 2f), new Vector3(0.35f, 1.6f, 0.35f));
                        Proc.Part(Cube, "WoodDark", r, new Vector3(s * 4.35f, -0.2f, half), new Vector3(0.3f, 0.3f, length));
                        for (int i = 0; i < 2; i++)
                        {
                            Proc.Part(Cyl, "Iron", r, new Vector3(s * 4.0f, 0.25f, i * 20f + 8f), new Vector3(0.3f, 0.25f, 0.3f));
                            Proc.Part(Cyl, "Iron", r, new Vector3(s * 4.0f, 0.5f, i * 20f + 8f), new Vector3(0.42f, 0.05f, 0.42f));
                        }
                        // Side jetty
                        Proc.Part(Cube, "Planks", r, new Vector3(s * 8f, -0.15f, 20f), new Vector3(7f, 0.25f, 3f));
                        Proc.Part(Cyl, "WoodDark", r, new Vector3(s * 11f, -1f, 19f), new Vector3(0.3f, 1.2f, 0.3f));
                        Proc.Part(Cyl, "WoodDark", r, new Vector3(s * 11f, -1f, 21f), new Vector3(0.3f, 1.2f, 0.3f));
                    }
                    break;
                case ThemeId.ShipwreckPassage:
                    for (int s = -1; s <= 1; s += 2)
                    {
                        Proc.Part(Cube, "DeckPlanks", r, new Vector3(s * 5.4f, 1.0f, half), new Vector3(0.35f, 3.2f, length), new Vector3(0, 0, s * -12f));
                        for (int i = 0; i < 5; i++)
                        {
                            Proc.Part(Cube, "WoodDark", r, new Vector3(s * 5.1f, 1.2f, i * 8f + 3f), new Vector3(0.5f, 4f, 0.45f), new Vector3(0, 0, s * -18f));
                            Proc.Part(Cyl, "WoodDark", r, new Vector3(s * 4.3f, -1.6f, i * 8f + 3f), new Vector3(0.35f, 1.5f, 0.35f));
                        }
                        Proc.Part(Cube, "Wood", r, new Vector3(s * 5.9f, 2.7f, half), new Vector3(0.6f, 0.2f, length));
                        Proc.Part(Sph, "RockDark", r, new Vector3(s * 9f, -0.9f, half + 6f), new Vector3(3f, 1.5f, 4f));
                    }
                    break;
                case ThemeId.HauntedCave:
                    for (int s = -1; s <= 1; s += 2)
                    {
                        Proc.Part(Cube, "StoneCave", r, new Vector3(s * 7.6f, 3.5f, half), new Vector3(4f, 9f, length + 0.2f));
                        for (int i = 0; i < 6; i++)
                            Proc.Part(Sph, i % 2 == 0 ? "RockDark" : "Rock", r, new Vector3(s * 5.8f, 0.6f + (i % 3) * 2.2f, i * 7f + 3f), new Vector3(2.2f, 2.5f, 3.5f), new Vector3(0, i * 40, 0));
                        Proc.Part(Cube, "StoneCave", r, new Vector3(s * 5.1f, -0.35f, half), new Vector3(1.7f, 0.7f, length));
                    }
                    for (int i = 0; i < 4; i++)
                    {
                        Proc.Part(Cube, "RockDark", r, new Vector3(0, 8.3f, i * 10f + 5f), new Vector3(16f, 1.4f, 3f));
                        Proc.Mesh(MeshFactory.Cone(6), "RockDark", r, new Vector3(-3f + i, 7.6f, i * 10f + 5f), new Vector3(0.8f, 2f, 0.8f), new Vector3(180, 0, 0));
                        Proc.Mesh(MeshFactory.Cone(6), "Rock", r, new Vector3(3.5f - i, 7.6f, i * 10f + 6f), new Vector3(0.6f, 1.4f, 0.6f), new Vector3(180, 0, 0));
                    }
                    Proc.Part(Cube, "RockDark", r, new Vector3(0, 9.4f, half), new Vector3(16f, 1f, length));
                    Torch(r, new Vector3(-4.9f, 0, 12f), true, 2.2f);
                    Torch(r, new Vector3(4.9f, 0, 32f), true, 2.2f);
                    break;
                default: // Temple
                    for (int s = -1; s <= 1; s += 2)
                    {
                        Proc.Part(Cube, "StoneTemple", r, new Vector3(s * 8.5f, 2.5f, half), new Vector3(1.5f, 5f, length + 0.2f));
                        Proc.Part(Cube, "Gold", r, new Vector3(s * 7.7f, 4.9f, half), new Vector3(0.2f, 0.25f, length));
                        Proc.Part(Cube, "Glyph", r, new Vector3(s * 7.73f, 2.6f, half), new Vector3(0.02f, 2.2f, length - 2f), Vector3.zero, false);
                        Proc.Part(Cube, "StoneTemple", r, new Vector3(s * 6.1f, -0.4f, half), new Vector3(3.7f, 0.8f, length));
                        for (int i = 0; i < 4; i++)
                        {
                            Proc.Part(Cyl, "StoneTemple", r, new Vector3(s * 6.6f, 3f, i * 10f + 5f), new Vector3(1f, 3f, 1f));
                            Proc.Part(Cube, "Gold", r, new Vector3(s * 6.6f, 6.1f, i * 10f + 5f), new Vector3(1.3f, 0.2f, 1.3f));
                        }
                    }
                    for (int i = 0; i < 2; i++) Proc.Part(Cube, "StoneTemple", r, new Vector3(0, 6.5f, i * 20f + 5f), new Vector3(14.5f, 0.8f, 1.2f));
                    Torch(r, new Vector3(-4.8f, 0, 15f), true, 1.8f);
                    Torch(r, new Vector3(4.8f, 0, 35f), true, 1.8f);
                    break;
            }
            Proc.CombineByMaterial(root);
            return root;
        }

        // ---------------------------------------------------------------- gateways between areas
        public static GameObject Gate(ThemeId theme)
        {
            GameObject root = new GameObject(ThemeInfo.GateKey(theme));
            Transform r = root.transform;
            string pillar = "WoodDark", beam = "Wood", accent = "Gold";
            switch (theme)
            {
                case ThemeId.HauntedCave: pillar = "RockDark"; beam = "StoneCave"; accent = "Crystal"; break;
                case ThemeId.TreasureTemple: pillar = "StoneTemple"; beam = "StoneTemple"; accent = "GoldGlow"; break;
                case ThemeId.ShipwreckPassage: pillar = "WoodDark"; beam = "DeckPlanks"; accent = "IronRust"; break;
            }
            for (int s = -1; s <= 1; s += 2)
            {
                Proc.Part(Cube, pillar, r, new Vector3(s * 5.2f, 3f, 0), new Vector3(1.1f, 6.5f, 1.1f));
                Proc.Part(Cube, accent, r, new Vector3(s * 5.2f, 6.4f, 0), new Vector3(1.3f, 0.3f, 1.3f));
                Torch(r, new Vector3(s * 4.2f, 0, -0.8f), false, 2.4f);
            }
            Proc.Part(Cube, beam, r, new Vector3(0, 6.9f, 0), new Vector3(12f, 0.9f, 1.2f));
            Proc.Part(Cube, beam, r, new Vector3(0, 7.8f, 0), new Vector3(4.5f, 1.4f, 0.4f));
            Proc.Part(Cube, accent, r, new Vector3(0, 7.8f, -0.22f), new Vector3(4f, 0.12f, 0.05f), Vector3.zero, false);
            // Skull-and-crossbones emblem
            Proc.Part(Sph, "PirateShirt", r, new Vector3(0, 7.9f, -0.25f), new Vector3(0.6f, 0.6f, 0.15f), Vector3.zero, false);
            Proc.Part(Cube, "PirateShirt", r, new Vector3(0, 7.5f, -0.24f), new Vector3(1.2f, 0.12f, 0.05f), new Vector3(0, 0, 30), false);
            Proc.Part(Cube, "PirateShirt", r, new Vector3(0, 7.5f, -0.24f), new Vector3(1.2f, 0.12f, 0.05f), new Vector3(0, 0, -30), false);
            Proc.Part(Sph, "Black", r, new Vector3(-0.12f, 7.95f, -0.32f), new Vector3(0.13f, 0.13f, 0.05f), Vector3.zero, false);
            Proc.Part(Sph, "Black", r, new Vector3(0.12f, 7.95f, -0.32f), new Vector3(0.13f, 0.13f, 0.05f), Vector3.zero, false);
            if (theme == ThemeId.HauntedCave)
                for (int i = 0; i < 4; i++)
                    Proc.Mesh(MeshFactory.Octahedron(), i % 2 == 0 ? "Crystal" : "CrystalPurple", r, new Vector3(-4.5f + i * 3f, 6.3f, -0.4f), new Vector3(0.3f, 0.9f, 0.3f), new Vector3(180, 0, 0), false);
            Proc.CombineByMaterial(root);
            return root;
        }
    }
}
