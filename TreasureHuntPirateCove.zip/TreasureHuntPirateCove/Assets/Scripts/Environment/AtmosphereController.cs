using UnityEngine;
using UnityEngine.Rendering;

namespace TreasureHunt
{
    /// <summary>
    /// Sunset sun + moonlight, procedural skybox and linear fog. Smoothly blends fog, ambient and light colours
    /// toward the theme of the area the player is currently running through.
    /// </summary>
    public class AtmosphereController : MonoBehaviour
    {
        public Light sun, moon;
        ThemeInfo.Atmos current;
        ThemeId target = ThemeId.TropicalIsland;
        bool snapped;

        public void Build(Light existingSun)
        {
            sun = existingSun;
            if (sun == null)
            {
                sun = new GameObject("Sun").AddComponent<Light>();
            }
            sun.type = LightType.Directional;
            sun.transform.SetParent(transform, false);
            sun.transform.rotation = Quaternion.Euler(14f, -35f, 0f); // low sunset angle, behind-left
            sun.shadows = LightShadows.Soft;
            sun.shadowStrength = 0.7f;

            moon = new GameObject("Moonlight").AddComponent<Light>();
            moon.transform.SetParent(transform, false);
            moon.type = LightType.Directional;
            moon.transform.rotation = Quaternion.Euler(50f, 140f, 0f);
            moon.color = new Color(0.55f, 0.65f, 1f);
            moon.intensity = 0.15f;
            moon.shadows = LightShadows.None;

            Material sky = MaterialLibrary.CreateSkybox();
            if (sky != null) RenderSettings.skybox = sky;
            RenderSettings.sun = sun;
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.ambientMode = AmbientMode.Trilight;
            QualitySettings.shadowDistance = 45f;
            Apply(ThemeInfo.Atmosphere(ThemeId.TropicalIsland), 1f);
        }

        public void SetTheme(ThemeId t, bool instant)
        {
            target = t;
            if (instant) { snapped = false; Apply(ThemeInfo.Atmosphere(t), 1f); }
        }

        void Apply(ThemeInfo.Atmos a, float k)
        {
            if (!snapped) { current = a; snapped = true; }
            current.fog = Color.Lerp(current.fog, a.fog, k);
            current.sky = Color.Lerp(current.sky, a.sky, k);
            current.equator = Color.Lerp(current.equator, a.equator, k);
            current.ground = Color.Lerp(current.ground, a.ground, k);
            current.sun = Color.Lerp(current.sun, a.sun, k);
            current.fogStart = Mathf.Lerp(current.fogStart, a.fogStart, k);
            current.fogEnd = Mathf.Lerp(current.fogEnd, a.fogEnd, k);
            current.sunIntensity = Mathf.Lerp(current.sunIntensity, a.sunIntensity, k);
            current.moonIntensity = Mathf.Lerp(current.moonIntensity, a.moonIntensity, k);

            RenderSettings.fogColor = current.fog;
            RenderSettings.fogStartDistance = current.fogStart;
            RenderSettings.fogEndDistance = current.fogEnd;
            RenderSettings.ambientSkyColor = current.sky;
            RenderSettings.ambientEquatorColor = current.equator;
            RenderSettings.ambientGroundColor = current.ground;
            if (sun != null) { sun.color = current.sun; sun.intensity = current.sunIntensity; }
            if (moon != null) moon.intensity = current.moonIntensity;
            Camera cam = Camera.main;
            if (cam != null) cam.backgroundColor = current.fog;
        }

        void Update()
        {
            Apply(ThemeInfo.Atmosphere(target), 1f - Mathf.Exp(-Time.deltaTime * 1.2f));
        }
    }
}
