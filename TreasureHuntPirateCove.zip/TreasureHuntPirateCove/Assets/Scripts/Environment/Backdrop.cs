using UnityEngine;

namespace TreasureHunt
{
    /// <summary>Distant islands, ships, sea stacks and the moon. The whole group follows the player along Z.</summary>
    public class Backdrop : MonoBehaviour
    {
        public Transform follow;

        public static Backdrop Create(Transform parent, Transform follow)
        {
            GameObject root = new GameObject("Backdrop");
            root.transform.SetParent(parent, false);
            Backdrop b = root.AddComponent<Backdrop>();
            b.follow = follow;
            Transform r = root.transform;
            const PrimitiveType Sph = PrimitiveType.Sphere, Cube = PrimitiveType.Cube, Cyl = PrimitiveType.Cylinder;

            // Distant islands with palms and a volcano-like peak
            float[] xs = { -70f, 85f, -110f, 120f, -55f, 65f };
            float[] zs = { 95f, 115f, 150f, 165f, 190f, 205f };
            for (int i = 0; i < xs.Length; i++)
            {
                float s = 14f + (i % 3) * 8f;
                Proc.Part(Sph, "IslandGreen", r, new Vector3(xs[i], -2f, zs[i]), new Vector3(s * 2.4f, s * 0.9f, s * 1.6f), Vector3.zero, false);
                Proc.Part(Sph, "Sand", r, new Vector3(xs[i], -2.6f, zs[i]), new Vector3(s * 2.8f, s * 0.3f, s * 2f), Vector3.zero, false);
                Proc.Mesh(MeshFactory.Cone(7), "RockDark", r, new Vector3(xs[i] + s * 0.3f, s * 0.2f, zs[i]), new Vector3(s * 1.2f, s * 1.1f, s * 1.2f), Vector3.zero, false);
            }
            // Sea stacks
            for (int i = 0; i < 8; i++)
            {
                float x = (i % 2 == 0 ? -1 : 1) * (40f + i * 9f);
                Proc.Mesh(MeshFactory.Cone(6), "Rock", r, new Vector3(x, -2f, 80f + i * 25f), new Vector3(6f, 14f + (i % 3) * 6f, 6f), Vector3.zero, false);
            }
            // Ship silhouettes on the horizon
            for (int i = 0; i < 3; i++)
            {
                float x = (i == 1 ? 1 : -1) * (70f + i * 25f);
                Transform ship = Proc.Node("FarShip", r, new Vector3(x * 0.8f, -1f, 110f + i * 30f)).transform;
                ship.localRotation = Quaternion.Euler(0, 70f + i * 20f, 0);
                Proc.Part(Cube, "WoodDark", ship, new Vector3(0, 1f, 0), new Vector3(4f, 2.5f, 15f), Vector3.zero, false);
                Proc.Part(Cyl, "WoodDark", ship, new Vector3(0, 7f, 2f), new Vector3(0.4f, 6f, 0.4f), Vector3.zero, false);
                Proc.Part(Cyl, "WoodDark", ship, new Vector3(0, 6f, -3f), new Vector3(0.4f, 5f, 0.4f), Vector3.zero, false);
                Proc.Part(Cube, "SailDark", ship, new Vector3(0, 8f, 2f), new Vector3(5f, 5f, 0.1f), Vector3.zero, false);
                Proc.Part(Cube, "SailDark", ship, new Vector3(0, 7f, -3f), new Vector3(4.5f, 4f, 0.1f), Vector3.zero, false);
            }
            Proc.CombineByMaterial(root);
            Proc.DisableShadows(root);
            return b;
        }

        void LateUpdate()
        {
            if (follow == null) return;
            Vector3 p = transform.position;
            p.z = follow.position.z;
            transform.position = p;
        }
    }
}
