using UnityEngine;

namespace TreasureHunt
{
    /// <summary>
    /// Lightweight animated ocean: a low-resolution grid that follows the player (snapped to the grid step so
    /// waves don't "swim") with vertex waves computed in world space. Arrays are preallocated (no per-frame GC).
    /// </summary>
    [RequireComponent(typeof(MeshFilter), typeof(MeshRenderer))]
    public class OceanWater : MonoBehaviour
    {
        public Transform follow;
        public int cells = 48;
        public float size = 260f;
        public float height = -1.2f;
        public float waveHeight = 0.28f;
        public int updateEveryNFrames = 1;

        Mesh mesh;
        Vector3[] baseVerts, verts;
        float step;

        public static OceanWater Create(Transform parent, Transform follow)
        {
            GameObject go = new GameObject("Ocean");
            go.transform.SetParent(parent, false);
            go.AddComponent<MeshFilter>();
            MeshRenderer r = go.AddComponent<MeshRenderer>();
            r.sharedMaterial = MaterialLibrary.Get("Water");
            r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            OceanWater o = go.AddComponent<OceanWater>();
            o.follow = follow;
            if (Application.isMobilePlatform) { o.cells = 32; o.updateEveryNFrames = 2; }
            return o;
        }

        void Start()
        {
            mesh = MeshFactory.Grid(cells, size);
            GetComponent<MeshFilter>().sharedMesh = mesh;
            baseVerts = mesh.vertices;
            verts = new Vector3[baseVerts.Length];
            step = size / cells;
        }

        void LateUpdate()
        {
            if (mesh == null) return;
            Vector3 c = follow != null ? follow.position : Vector3.zero;
            float sx = Mathf.Round(c.x / step) * step;
            float sz = Mathf.Round((c.z + size * 0.3f) / step) * step;
            transform.position = new Vector3(sx, height, sz);
            if (Time.frameCount % updateEveryNFrames != 0) return;
            float t = Time.time;
            for (int i = 0; i < baseVerts.Length; i++)
            {
                Vector3 b = baseVerts[i];
                float wx = b.x + sx, wz = b.z + sz;
                float y = Mathf.Sin(wx * 0.11f + t * 1.1f) * 0.6f + Mathf.Sin(wz * 0.17f + t * 1.6f) * 0.4f + Mathf.Sin((wx + wz) * 0.07f - t * 0.8f) * 0.5f;
                verts[i] = new Vector3(b.x, y * waveHeight, b.z);
            }
            mesh.vertices = verts;
            mesh.RecalculateNormals();
        }
    }
}
