using UnityEngine;

namespace TreasureHunt
{
    public enum ObstacleKind
    {
        None, Crate, CrateStack, ExplosiveBarrel, RollingLog, RollingBarrel, FallingRock, CollapsingBridge,
        DockGap, PirateGuard, SwingingAnchor, Cannon, LowRope, SpikeTrap, CaveTrap, CannonBall
    }

    /// <summary>How the player must deal with an obstacle in a lane.</summary>
    public enum LaneContent { Empty, Jump, Slide, Block }

    public enum RowType { Normal, FullGap, FullSlide, Bridge, Rolling }

    /// <summary>One obstacle row across the three lanes.</summary>
    public class PlannedRow
    {
        public RowType type;
        public readonly ObstacleKind[] lanes = new ObstacleKind[3];
        /// <summary>Length of track (m) the row occupies, starting at its z.</summary>
        public float length = 1.5f;

        public void Clear()
        {
            type = RowType.Normal;
            length = 1.5f;
            for (int i = 0; i < 3; i++) lanes[i] = ObstacleKind.None;
        }
    }

    /// <summary>
    /// Pure, deterministic obstacle-row planner (no Unity objects, fully unit-tested).
    /// Guarantee: every row leaves at least one lane that is not a Block, so a valid escape always exists.
    /// Spacing between rows is enforced by the TrackGenerator from current speed.
    /// </summary>
    public static class SpawnPlanner
    {
        public static LaneContent ContentOf(ObstacleKind k)
        {
            switch (k)
            {
                case ObstacleKind.None: return LaneContent.Empty;
                case ObstacleKind.Crate:
                case ObstacleKind.SpikeTrap:
                case ObstacleKind.RollingLog:
                case ObstacleKind.RollingBarrel:
                case ObstacleKind.DockGap:
                case ObstacleKind.CannonBall: return LaneContent.Jump;
                case ObstacleKind.LowRope:
                case ObstacleKind.CaveTrap: return LaneContent.Slide;
                default: return LaneContent.Block;
            }
        }

        public static bool IsSafe(ObstacleKind[] lanes)
        {
            for (int i = 0; i < lanes.Length; i++) if (ContentOf(lanes[i]) != LaneContent.Block) return true;
            return false;
        }

        class Kinds
        {
            public ObstacleKind[] jump, slide, block;
            public ObstacleKind rolling;
            public bool gaps, bridges;
        }

        static readonly Kinds[] table =
        {
            new Kinds { jump = new[] { ObstacleKind.Crate, ObstacleKind.SpikeTrap }, slide = new[] { ObstacleKind.LowRope },
                        block = new[] { ObstacleKind.CrateStack, ObstacleKind.ExplosiveBarrel, ObstacleKind.PirateGuard },
                        rolling = ObstacleKind.RollingLog, gaps = true, bridges = true },
            new Kinds { jump = new[] { ObstacleKind.Crate }, slide = new[] { ObstacleKind.LowRope },
                        block = new[] { ObstacleKind.CrateStack, ObstacleKind.ExplosiveBarrel, ObstacleKind.PirateGuard, ObstacleKind.Cannon, ObstacleKind.SwingingAnchor },
                        rolling = ObstacleKind.RollingBarrel, gaps = true, bridges = true },
            new Kinds { jump = new[] { ObstacleKind.Crate }, slide = new[] { ObstacleKind.LowRope },
                        block = new[] { ObstacleKind.ExplosiveBarrel, ObstacleKind.SwingingAnchor, ObstacleKind.Cannon, ObstacleKind.CrateStack },
                        rolling = ObstacleKind.RollingBarrel, gaps = true, bridges = true },
            new Kinds { jump = new[] { ObstacleKind.SpikeTrap }, slide = new[] { ObstacleKind.CaveTrap },
                        block = new[] { ObstacleKind.FallingRock, ObstacleKind.CrateStack, ObstacleKind.PirateGuard },
                        rolling = ObstacleKind.RollingLog, gaps = true, bridges = true },
            new Kinds { jump = new[] { ObstacleKind.SpikeTrap }, slide = new[] { ObstacleKind.CaveTrap },
                        block = new[] { ObstacleKind.FallingRock, ObstacleKind.PirateGuard, ObstacleKind.CrateStack },
                        rolling = ObstacleKind.RollingLog, gaps = true, bridges = true },
        };

        static ObstacleKind Pick(System.Random rng, ObstacleKind[] arr) { return arr[rng.Next(arr.Length)]; }

        /// <param name="difficulty">0 at the start of a run, 1 after ~3 km.</param>
        public static PlannedRow Plan(System.Random rng, ThemeId theme, float difficulty, PlannedRow row)
        {
            if (row == null) row = new PlannedRow();
            row.Clear();
            difficulty = Mathf.Clamp01(difficulty);
            Kinds k = table[(int)theme];
            double r = rng.NextDouble();
            double special = 0.10 + 0.12 * difficulty;

            if (r < special * 0.3 && k.gaps)
            {
                row.type = RowType.FullGap;
                row.length = 2.6f + (float)rng.NextDouble() * 1.4f * (0.4f + difficulty);
                for (int i = 0; i < 3; i++) row.lanes[i] = ObstacleKind.DockGap;
            }
            else if (r < special * 0.55 && k.bridges)
            {
                row.type = RowType.Bridge;
                row.length = 12f;
                int safe = rng.Next(3);
                bool two = difficulty > 0.3f && rng.NextDouble() < 0.5;
                for (int i = 0; i < 3; i++) row.lanes[i] = i == safe ? ObstacleKind.None : ObstacleKind.CollapsingBridge;
                if (!two)
                {
                    int other = (safe + 1 + rng.Next(2)) % 3;
                    row.lanes[other] = ObstacleKind.None;
                }
            }
            else if (r < special * 0.8)
            {
                row.type = RowType.Rolling;
                int lane = rng.Next(3);
                row.lanes[lane] = k.rolling;
                if (difficulty > 0.4f && rng.NextDouble() < 0.4) row.lanes[(lane + 1 + rng.Next(2)) % 3] = k.rolling;
            }
            else if (r < special)
            {
                row.type = RowType.FullSlide;
                ObstacleKind s = Pick(rng, k.slide);
                for (int i = 0; i < 3; i++) row.lanes[i] = s;
            }
            else
            {
                row.type = RowType.Normal;
                int count = 1;
                if (rng.NextDouble() < 0.35 + 0.4 * difficulty) count++;
                if (rng.NextDouble() < 0.15 + 0.35 * difficulty) count++;
                int start = rng.Next(3);
                for (int n = 0; n < count; n++)
                {
                    int lane = (start + n) % 3;
                    double c = rng.NextDouble();
                    if (c < 0.45) row.lanes[lane] = Pick(rng, k.block);
                    else if (c < 0.78) row.lanes[lane] = Pick(rng, k.jump);
                    else row.lanes[lane] = Pick(rng, k.slide);
                }
            }

            // Safety net: never allow three blocking lanes.
            if (!IsSafe(row.lanes))
            {
                int l = rng.Next(3);
                row.lanes[l] = rng.NextDouble() < 0.5 ? ObstacleKind.None : Pick(rng, k.jump);
            }
            return row;
        }

        /// <summary>Minimum distance between rows so the player can always react and change lanes.</summary>
        public static float RowSpacing(float speed, float minSpacing, float seconds)
        {
            return Mathf.Max(minSpacing, speed * seconds);
        }
    }
}
