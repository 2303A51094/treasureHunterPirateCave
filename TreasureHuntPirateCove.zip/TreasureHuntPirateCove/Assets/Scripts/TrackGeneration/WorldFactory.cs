using System;
using System.Collections.Generic;
using UnityEngine;

namespace TreasureHunt
{
    /// <summary>
    /// Single entry point that turns a pool key into a GameObject. Uses the saved prefab from the
    /// PrefabCatalog when available, otherwise builds procedurally (identical result).
    /// </summary>
    public static class WorldFactory
    {
        public static PrefabCatalog Catalog;
        public const string RescueKey = "gnd_Rescue";

        /// <summary>Every key the game can request (the editor tool saves a prefab for each).</summary>
        public static List<string> AllKeys(GameConfig cfg)
        {
            List<string> keys = new List<string>();
            keys.Add("player");
            foreach (ObstacleKind k in Enum.GetValues(typeof(ObstacleKind)))
                if (k != ObstacleKind.None && k != ObstacleKind.DockGap) keys.Add("ob_" + k);
            foreach (CollectibleType c in Enum.GetValues(typeof(CollectibleType)))
                if (c != CollectibleType.PowerUp) keys.Add(CollectibleBuilder.Key(c));
            foreach (PowerUpType p in Enum.GetValues(typeof(PowerUpType))) keys.Add(CollectibleBuilder.Key(p));
            for (int i = 0; i < ThemeInfo.Count; i++)
            {
                ThemeId t = (ThemeId)i;
                keys.Add(ThemeInfo.GroundKey(t));
                keys.Add(ThemeInfo.SideKey(t));
                keys.Add(ThemeInfo.GateKey(t));
            }
            keys.Add(RescueKey);
            keys.AddRange(EnvironmentBuilder.AllDecorKeys);
            return keys;
        }

        public static GameObject Instantiate(string key, GameConfig cfg)
        {
            if (Catalog != null)
            {
                GameObject prefab = Catalog.FindPrefab(key);
                if (prefab != null)
                {
                    GameObject inst = UnityEngine.Object.Instantiate(prefab);
                    inst.name = key;
                    return inst;
                }
            }
            return Build(key, cfg);
        }

        /// <summary>Builds the object procedurally.</summary>
        public static GameObject Build(string key, GameConfig cfg)
        {
            if (key == "player") return PirateBuilder.BuildPlayer();
            if (key == RescueKey) return EnvironmentBuilder.Ground(key, "RescuePlanks");
            if (key.StartsWith("ob_"))
            {
                ObstacleKind k = (ObstacleKind)Enum.Parse(typeof(ObstacleKind), key.Substring(3));
                return ObstacleBuilder.Build(k);
            }
            if (key.StartsWith("col_"))
                return CollectibleBuilder.Build((CollectibleType)Enum.Parse(typeof(CollectibleType), key.Substring(4)));
            if (key.StartsWith("pu_"))
                return CollectibleBuilder.Build((PowerUpType)Enum.Parse(typeof(PowerUpType), key.Substring(3)));
            if (key.StartsWith("gnd_"))
            {
                ThemeId t = (ThemeId)Enum.Parse(typeof(ThemeId), key.Substring(4));
                return EnvironmentBuilder.Ground(key, ThemeInfo.GroundMaterial(t));
            }
            if (key.StartsWith("side_"))
                return EnvironmentBuilder.Side((ThemeId)Enum.Parse(typeof(ThemeId), key.Substring(5)), cfg != null ? cfg.chunkLength : 40f);
            if (key.StartsWith("gate_"))
                return EnvironmentBuilder.Gate((ThemeId)Enum.Parse(typeof(ThemeId), key.Substring(5)));
            if (key.StartsWith("dec_"))
                return EnvironmentBuilder.Prop(key);
            Debug.LogError("[TreasureHunt] Unknown pool key: " + key);
            return new GameObject(key);
        }
    }
}
