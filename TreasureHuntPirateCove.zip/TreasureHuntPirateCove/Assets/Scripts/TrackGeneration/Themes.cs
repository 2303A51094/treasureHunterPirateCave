using UnityEngine;

namespace TreasureHunt
{
    public enum ThemeId { TropicalIsland = 0, PirateHarbor = 1, ShipwreckPassage = 2, HauntedCave = 3, TreasureTemple = 4 }

    /// <summary>Static data for each environment segment type.</summary>
    public static class ThemeInfo
    {
        public const int Count = 5;

        public struct Atmos
        {
            public Color fog, sky, equator, ground, sun;
            public float fogStart, fogEnd, sunIntensity, moonIntensity;
        }

        public static string DisplayName(ThemeId t)
        {
            switch (t)
            {
                case ThemeId.TropicalIsland: return "Tropical Island";
                case ThemeId.PirateHarbor: return "Pirate Harbor";
                case ThemeId.ShipwreckPassage: return "Shipwreck Passage";
                case ThemeId.HauntedCave: return "Haunted Cave";
                default: return "Treasure Temple";
            }
        }

        public static string GroundKey(ThemeId t) { return "gnd_" + t; }
        public static string SideKey(ThemeId t) { return "side_" + t; }
        public static string GateKey(ThemeId t) { return "gate_" + t; }

        public static string GroundMaterial(ThemeId t)
        {
            switch (t)
            {
                case ThemeId.TropicalIsland: return "SandPath";
                case ThemeId.PirateHarbor: return "Planks";
                case ThemeId.ShipwreckPassage: return "DeckPlanks";
                case ThemeId.HauntedCave: return "StoneCave";
                default: return "StoneTemple";
            }
        }

        static Color C(float r, float g, float b) { return new Color(r, g, b, 1); }

        public static Atmos Atmosphere(ThemeId t)
        {
            Atmos a = new Atmos();
            switch (t)
            {
                case ThemeId.TropicalIsland:
                    a.fog = C(0.93f, 0.62f, 0.46f); a.fogStart = 40; a.fogEnd = 170;
                    a.sky = C(0.9f, 0.62f, 0.5f); a.equator = C(0.75f, 0.5f, 0.4f); a.ground = C(0.3f, 0.24f, 0.2f);
                    a.sun = C(1f, 0.7f, 0.45f); a.sunIntensity = 1.3f; a.moonIntensity = 0.1f; break;
                case ThemeId.PirateHarbor:
                    a.fog = C(0.66f, 0.46f, 0.5f); a.fogStart = 35; a.fogEnd = 160;
                    a.sky = C(0.62f, 0.5f, 0.62f); a.equator = C(0.55f, 0.42f, 0.45f); a.ground = C(0.22f, 0.18f, 0.18f);
                    a.sun = C(1f, 0.6f, 0.42f); a.sunIntensity = 1.05f; a.moonIntensity = 0.2f; break;
                case ThemeId.ShipwreckPassage:
                    a.fog = C(0.36f, 0.43f, 0.52f); a.fogStart = 22; a.fogEnd = 125;
                    a.sky = C(0.4f, 0.47f, 0.65f); a.equator = C(0.32f, 0.37f, 0.45f); a.ground = C(0.12f, 0.13f, 0.16f);
                    a.sun = C(0.7f, 0.78f, 1f); a.sunIntensity = 0.65f; a.moonIntensity = 0.5f; break;
                case ThemeId.HauntedCave:
                    a.fog = C(0.04f, 0.07f, 0.11f); a.fogStart = 14; a.fogEnd = 85;
                    a.sky = C(0.22f, 0.27f, 0.42f); a.equator = C(0.14f, 0.18f, 0.25f); a.ground = C(0.05f, 0.05f, 0.07f);
                    a.sun = C(0.45f, 0.55f, 0.85f); a.sunIntensity = 0.25f; a.moonIntensity = 0.3f; break;
                default:
                    a.fog = C(0.28f, 0.18f, 0.09f); a.fogStart = 18; a.fogEnd = 105;
                    a.sky = C(0.58f, 0.44f, 0.28f); a.equator = C(0.46f, 0.33f, 0.2f); a.ground = C(0.12f, 0.08f, 0.05f);
                    a.sun = C(1f, 0.75f, 0.4f); a.sunIntensity = 0.55f; a.moonIntensity = 0.1f; break;
            }
            return a;
        }
    }
}
