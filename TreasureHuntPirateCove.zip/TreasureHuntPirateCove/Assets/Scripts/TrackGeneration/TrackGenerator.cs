using System.Collections.Generic;
using UnityEngine;

namespace TreasureHunt
{
    /// <summary>
    /// Streams the endless track in 40 m chunks: ground (with carved gaps), theme side structures,
    /// scenery, obstacle rows and collectible formations. Everything comes from the ObjectPool and is
    /// returned when the chunk falls behind the player.
    /// </summary>
    public class TrackGenerator : MonoBehaviour
    {
        class Chunk
        {
            public int index;
            public float startZ;
            public ThemeId theme;
            public Transform root;
            public readonly List<PooledObject> items = new List<PooledObject>(96);
        }

        struct Hole { public float start, end; public Hole(float s, float e) { start = s; end = e; } }

        GameConfig cfg;
        ObjectPool pool;
        Transform player;
        readonly List<Chunk> active = new List<Chunk>();
        readonly Stack<Chunk> spareChunks = new Stack<Chunk>();
        readonly List<Hole> holes = new List<Hole>();
        readonly List<PooledObject> transients = new List<PooledObject>();
        readonly PlannedRow row = new PlannedRow();
        int nextChunkIndex;
        float nextRowZ;
        System.Random rng = new System.Random(1);

        public int ActiveChunkCount { get { return active.Count; } }
        public int RowsSpawned { get; private set; }
        public int UnsafeRowsDetected { get; private set; }

        public void Init(GameConfig config, ObjectPool objectPool, Transform playerTransform)
        {
            cfg = config;
            pool = objectPool;
            player = playerTransform;
        }

        public ThemeId ThemeForIndex(int index)
        {
            return (ThemeId)((Mathf.Max(0, index) / Mathf.Max(1, cfg.chunksPerTheme)) % ThemeInfo.Count);
        }

        public ThemeId ThemeAt(float z) { return ThemeForIndex(Mathf.FloorToInt(z / cfg.chunkLength)); }

        /// <summary>Clears everything and rebuilds the opening stretch of track.</summary>
        public void ResetTrack(int seed)
        {
            for (int i = 0; i < active.Count; i++) ReleaseChunk(active[i]);
            active.Clear();
            for (int i = 0; i < transients.Count; i++) pool.Release(transients[i]);
            transients.Clear();
            holes.Clear();
            nextChunkIndex = 0;
            nextRowZ = cfg.safeStartDistance;
            RowsSpawned = 0;
            UnsafeRowsDetected = 0;
            rng = new System.Random(seed);
            EnsureAhead(0f);
        }

        void Update()
        {
            if (player == null || cfg == null) return;
            float pz = player.position.z;
            EnsureAhead(pz);
            float behind = pz - cfg.chunksBehind * cfg.chunkLength;
            while (active.Count > 0 && active[0].startZ + cfg.chunkLength < behind)
            {
                ReleaseChunk(active[0]);
                active.RemoveAt(0);
            }
            for (int i = transients.Count - 1; i >= 0; i--)
            {
                PooledObject t = transients[i];
                bool gone = t == null || t.inPool;
                if (!gone && t.transform.position.z < pz - 30f) { pool.Release(t); gone = true; }
                if (gone) transients.RemoveAt(i);
            }
            for (int i = holes.Count - 1; i >= 0; i--) if (holes[i].end < pz - 120f) holes.RemoveAt(i);
        }

        void EnsureAhead(float pz)
        {
            int guard = 0;
            while (nextChunkIndex * cfg.chunkLength < pz + cfg.chunksAhead * cfg.chunkLength && guard++ < 32)
                SpawnChunk(nextChunkIndex++);
        }

        void ReleaseChunk(Chunk c)
        {
            for (int i = 0; i < c.items.Count; i++) pool.Release(c.items[i]);
            c.items.Clear();
            c.root.gameObject.SetActive(false);
            spareChunks.Push(c);
        }

        PooledObject Spawn(Chunk c, string key, Vector3 pos, Quaternion rot)
        {
            PooledObject po = pool.Get(key, c.root, pos, rot);
            if (po != null) c.items.Add(po);
            return po;
        }

        /// <summary>Spawns an object not tied to a chunk (cannonballs). Released once well behind the player.</summary>
        public PooledObject SpawnTransient(string key, Vector3 pos)
        {
            PooledObject po = pool.Get(key, transform, pos, Quaternion.identity);
            if (po != null) transients.Add(po);
            return po;
        }

        // ------------------------------------------------------------------ chunk construction
        void SpawnChunk(int index)
        {
            Chunk c = spareChunks.Count > 0 ? spareChunks.Pop() : new Chunk();
            if (c.root == null)
            {
                c.root = new GameObject("Chunk").transform;
                c.root.SetParent(transform, false);
            }
            c.root.gameObject.SetActive(true);
            c.root.name = "Chunk_" + index;
            c.index = index;
            c.startZ = index * cfg.chunkLength;
            c.theme = ThemeForIndex(index);
            active.Add(c);

            float endZ = c.startZ + cfg.chunkLength;
            while (nextRowZ < endZ) PlanRow(c);

            BuildGround(c, c.startZ, endZ);
            Spawn(c, ThemeInfo.SideKey(c.theme), new Vector3(0, 0, c.startZ), Quaternion.identity);
            if (index % cfg.chunksPerTheme == 0) Spawn(c, ThemeInfo.GateKey(c.theme), new Vector3(0, 0, c.startZ + 1f), Quaternion.identity);
            Decorate(c);
        }

        void BuildGround(Chunk c, float s, float e)
        {
            string key = ThemeInfo.GroundKey(c.theme);
            float cursor = s;
            for (int i = 0; i < holes.Count; i++)
            {
                Hole h = holes[i];
                if (h.end <= s || h.start >= e) continue;
                if (h.start > cursor) AddGround(c, key, cursor, Mathf.Min(h.start, e));
                cursor = Mathf.Max(cursor, h.end);
            }
            if (cursor < e) AddGround(c, key, cursor, e);
        }

        void AddGround(Chunk c, string key, float a, float b)
        {
            const float tile = 8f;
            for (float t = a; t < b - 0.01f; t += tile)
            {
                float len = Mathf.Min(tile, b - t);
                PooledObject g = Spawn(c, key, new Vector3(0, -0.25f, t + len * 0.5f), Quaternion.identity);
                if (g != null) g.transform.localScale = new Vector3(cfg.TrackWidth, 0.5f, len);
            }
        }

        void Decorate(Chunk c)
        {
            string[] props = EnvironmentBuilder.PropsFor(c.theme);
            int count = c.theme == ThemeId.HauntedCave ? 4 : 6;
            for (int i = 0; i < count; i++)
            {
                string key = props[rng.Next(props.Length)];
                float side = rng.Next(2) == 0 ? -1f : 1f;
                Vector2 band = EnvironmentBuilder.OffsetFor(key, c.theme);
                float x = side * Mathf.Lerp(band.x, band.y, (float)rng.NextDouble());
                float z = c.startZ + (i + (float)rng.NextDouble()) * cfg.chunkLength / count;
                float y = (key == "dec_ship" || key == "dec_wreck") ? -0.4f : (c.theme == ThemeId.TropicalIsland ? -0.2f : 0f);
                float yaw = side < 0 ? 90f : -90f;
                if (key != "dec_ship" && key != "dec_wreck" && key != "dec_waterfall" && key != "dec_symbols") yaw += (float)rng.NextDouble() * 60f - 30f;
                if (key == "dec_ship" || key == "dec_wreck") yaw = (float)rng.NextDouble() * 40f - 20f;
                bool overWater = c.theme == ThemeId.PirateHarbor || c.theme == ThemeId.ShipwreckPassage;
                bool bigProp = key == "dec_ship" || key == "dec_wreck" || key == "dec_fort" || key == "dec_watchtower";
                if (overWater && (key == "dec_rock" || key == "dec_mast")) y = -0.8f;
                else if (overWater && !bigProp && key != "dec_mast")
                    Spawn(c, "dec_platform", new Vector3(x, 0, z), Quaternion.Euler(0, yaw, 0));
                Spawn(c, key, new Vector3(x, y, z), Quaternion.Euler(0, yaw, 0));
            }
        }

        // ------------------------------------------------------------------ obstacle rows
        float EstimatedSpeed()
        {
            GameManager gm = GameManager.Instance;
            float s = gm != null ? gm.BaseSpeed : cfg.startSpeed;
            return Mathf.Max(cfg.startSpeed, s + 2f);
        }

        void PlanRow(Chunk c)
        {
            float spacing = SpawnPlanner.RowSpacing(EstimatedSpeed(), cfg.minRowSpacing, cfg.rowSpacingSeconds);
            float difficulty = Mathf.Clamp01(nextRowZ / 3000f);
            SpawnPlanner.Plan(rng, c.theme, difficulty, row);
            RowsSpawned++;
            if (!SpawnPlanner.IsSafe(row.lanes)) UnsafeRowsDetected++; // should never happen (validated in tests)

            float z = nextRowZ;
            if (row.type == RowType.Rolling) z += spacing * 1.3f; // runway for the hazard to roll into

            switch (row.type)
            {
                case RowType.FullGap:
                    holes.Add(new Hole(z, z + row.length));
                    CoinArc(c, rng.Next(3), z + row.length * 0.5f, 6);
                    break;
                case RowType.Bridge:
                {
                    holes.Add(new Hole(z, z + row.length));
                    PooledObject b = Spawn(c, "ob_" + ObstacleKind.CollapsingBridge, new Vector3(0, 0, z), Quaternion.identity);
                    if (b != null)
                    {
                        CollapsingBridge cb = b.GetComponent<CollapsingBridge>();
                        if (cb != null) cb.Configure(row.lanes);
                    }
                    for (int l = 0; l < 3; l++)
                        if (row.lanes[l] == ObstacleKind.None) { CoinLine(c, l, z + 1.5f, 5, 2f); break; }
                    break;
                }
                default:
                    for (int l = 0; l < 3; l++)
                    {
                        ObstacleKind k = row.lanes[l];
                        if (k == ObstacleKind.None) continue;
                        Spawn(c, "ob_" + k, new Vector3(cfg.LaneX(l), 0, z), Quaternion.identity);
                        LaneContent content = SpawnPlanner.ContentOf(k);
                        if (content == LaneContent.Jump && row.type == RowType.Normal && rng.NextDouble() < 0.4) CoinArc(c, l, z, 5);
                        else if (content == LaneContent.Slide && rng.NextDouble() < 0.35) CoinLine(c, l, z - 2f, 3, 2f, 0.5f);
                    }
                    break;
            }

            float rowEnd = z + row.length;
            float next = rowEnd + spacing;
            FillGap(c, rowEnd + 2.5f, next - 3f);
            nextRowZ = next;
        }

        // ------------------------------------------------------------------ collectibles
        void FillGap(Chunk c, float a, float b)
        {
            if (b - a < 4f) return;
            float rare = 1f;
            GameManager gm = GameManager.Instance;
            if (gm != null && gm.powerUps != null) rare = gm.powerUps.RareChanceMultiplier;

            double r = rng.NextDouble();
            int lane = rng.Next(3);
            if (r < 0.55)
            {
                int n = Mathf.Clamp(Mathf.FloorToInt((b - a) / 2f), 3, 8);
                if (rng.NextDouble() < 0.35)
                {
                    // Lane-switch trail: first half in one lane, second half in a neighbour
                    int lane2 = Mathf.Clamp(lane + (rng.Next(2) == 0 ? -1 : 1), 0, 2);
                    CoinLine(c, lane, a, n / 2, 2f);
                    CoinLine(c, lane2, a + (n / 2) * 2f, n - n / 2, 2f);
                    lane = lane2;
                }
                else CoinLine(c, lane, a, n, 2f);
            }

            float mid = (a + b) * 0.5f;
            int rareLane = rng.Next(3);
            Vector3 rarePos = new Vector3(cfg.LaneX(rareLane), 0, Mathf.Min(b, mid + 3f));
            if (rng.NextDouble() < cfg.powerUpChance)
            {
                PowerUpType p = (PowerUpType)rng.Next(6);
                SpawnPickup(c, CollectibleBuilder.Key(p), new Vector3(cfg.LaneX(rng.Next(3)), 0, mid - 2f));
            }
            double roll = rng.NextDouble();
            if (roll < cfg.artifactChance * rare) SpawnPickup(c, CollectibleBuilder.Key(CollectibleType.Artifact), rarePos);
            else if (roll < (cfg.artifactChance + cfg.chestChance) * rare) SpawnPickup(c, CollectibleBuilder.Key(CollectibleType.Chest), rarePos);
            else if (roll < (cfg.artifactChance + cfg.chestChance + cfg.keyChance) * rare) SpawnPickup(c, CollectibleBuilder.Key(CollectibleType.Key), rarePos);
            else if (roll < (cfg.artifactChance + cfg.chestChance + cfg.keyChance + cfg.gemChance) * rare) SpawnPickup(c, CollectibleBuilder.Key(CollectibleType.Gem), rarePos);
        }

        void SpawnPickup(Chunk c, string key, Vector3 pos)
        {
            PooledObject po = Spawn(c, key, pos, Quaternion.identity);
            if (po == null) return;
            Collectible col = po.GetComponent<Collectible>();
            if (col != null) po.transform.position = new Vector3(pos.x, col.spawnHeight, pos.z);
        }

        void CoinLine(Chunk c, int lane, float z0, int n, float step, float height = 0.9f)
        {
            string key = CollectibleBuilder.Key(CollectibleType.Coin);
            for (int i = 0; i < n; i++) Spawn(c, key, new Vector3(cfg.LaneX(lane), height, z0 + i * step), Quaternion.identity);
        }

        /// <summary>Arc of coins following the jump curve, centred on an obstacle or gap.</summary>
        void CoinArc(Chunk c, int lane, float zCenter, int n)
        {
            string key = CollectibleBuilder.Key(CollectibleType.Coin);
            float span = 6f;
            for (int i = 0; i < n; i++)
            {
                float u = n == 1 ? 0f : (i / (float)(n - 1)) * 2f - 1f;
                float y = 0.9f + 1.1f * (1f - u * u);
                Spawn(c, key, new Vector3(cfg.LaneX(lane), y, zCenter + u * span * 0.5f), Quaternion.identity);
            }
        }

        // ------------------------------------------------------------------ revive support
        /// <summary>Removes hazards around z, stabilises bridges and lays a rescue platform over any gap.</summary>
        public void ClearForRevive(float z, float behind, float ahead)
        {
            for (int ci = 0; ci < active.Count; ci++)
            {
                List<PooledObject> items = active[ci].items;
                for (int i = 0; i < items.Count; i++)
                {
                    PooledObject po = items[i];
                    if (po == null || po.inPool) continue;
                    float oz = po.transform.position.z;
                    Obstacle ob = po.GetComponent<Obstacle>();
                    if (ob != null && oz > z - behind - 2f && oz < z + ahead) ob.Smash(false);
                    CollapsingBridge cb = po.GetComponent<CollapsingBridge>();
                    if (cb != null && oz + 12f > z - behind && oz < z + ahead) cb.Stabilize();
                }
            }
            for (int i = 0; i < transients.Count; i++)
            {
                if (transients[i] == null || transients[i].inPool) continue;
                Obstacle ob = transients[i].GetComponent<Obstacle>();
                if (ob != null) ob.Smash(false);
            }
            float len = behind + ahead;
            PooledObject rescue = pool.Get(WorldFactory.RescueKey, transform, new Vector3(0, -0.262f, z - behind + len * 0.5f), Quaternion.identity);
            if (rescue != null)
            {
                rescue.transform.localScale = new Vector3(cfg.TrackWidth, 0.5f, len);
                transients.Add(rescue);
            }
        }
    }
}
