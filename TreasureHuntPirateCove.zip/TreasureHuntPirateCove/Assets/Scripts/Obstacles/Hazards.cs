using UnityEngine;

namespace TreasureHunt
{
    /// <summary>Shared helpers for moving hazards.</summary>
    public abstract class HazardBase : MonoBehaviour, IPoolable
    {
        protected static bool Running
        {
            get { return GameManager.Instance != null && GameManager.Instance.State == GameState.Playing; }
        }

        /// <summary>Distance from the player to this hazard along the track (positive = ahead).</summary>
        protected float DistanceAhead
        {
            get
            {
                GameManager gm = GameManager.Instance;
                if (gm == null || gm.player == null) return 9999f;
                return transform.position.z - gm.player.transform.position.z;
            }
        }

        public virtual void OnSpawned() { }
        public virtual void OnDespawned() { }
    }

    /// <summary>Logs, barrels and cannonballs that roll toward the player once it gets close.</summary>
    public class RollingHazard : HazardBase
    {
        public Transform roller;
        public GameObject warning;
        public float rollSpeed = 7f;
        public float radius = 0.45f;
        public float activateDistance = 42f;
        public bool startRolling;
        bool rolling;

        public override void OnSpawned()
        {
            rolling = startRolling;
            if (warning != null) warning.SetActive(true);
            if (roller != null) roller.localRotation = Quaternion.Euler(0, 0, 90);
        }

        void Update()
        {
            if (!Running) return;
            float d = DistanceAhead;
            if (!rolling && d < activateDistance)
            {
                rolling = true;
                if (AudioManager.Instance != null && d > 0) AudioManager.Instance.Play(Sfx.Rumble, 0.5f);
            }
            if (!rolling || d < -25f) return;
            float dt = Time.deltaTime;
            transform.position += Vector3.back * rollSpeed * dt;
            if (roller != null) roller.Rotate(Vector3.right, -rollSpeed / radius * Mathf.Rad2Deg * dt, Space.World);
            if (warning != null && d < 6f) warning.SetActive(false);
        }
    }

    /// <summary>Rock that falls into its lane after a ground warning is shown.</summary>
    public class FallingRockHazard : HazardBase
    {
        public Transform rock;
        public GameObject warning;
        public float triggerDistance = 30f;
        public float dropHeight = 14f;
        int state; // 0 waiting, 1 falling, 2 landed
        float vy;

        public override void OnSpawned()
        {
            state = 0;
            vy = 0;
            if (rock != null) rock.localPosition = new Vector3(0, dropHeight, 0);
            if (warning != null) warning.SetActive(true);
        }

        void Update()
        {
            if (rock == null) return;
            if (state == 0)
            {
                if (Running && DistanceAhead < triggerDistance) state = 1;
                return;
            }
            if (state == 1)
            {
                vy -= 40f * Time.deltaTime;
                Vector3 p = rock.localPosition;
                p.y += vy * Time.deltaTime;
                if (p.y <= 0f)
                {
                    p.y = 0f;
                    state = 2;
                    if (warning != null) warning.SetActive(false);
                    if (FxManager.Instance != null) FxManager.Instance.Dust(rock.position + Vector3.up * 0.3f, 30);
                    if (AudioManager.Instance != null) AudioManager.Instance.Play(Sfx.Rumble, 0.7f);
                    GameManager gm = GameManager.Instance;
                    if (gm != null && gm.cameraFollow != null && DistanceAhead < 25f) gm.cameraFollow.Shake(0.15f, 0.25f);
                }
                rock.localPosition = p;
            }
        }
    }

    /// <summary>Anchor pendulum swinging along the running direction inside its own lane.</summary>
    public class SwingingHazard : HazardBase
    {
        public Transform pivot;
        public float amplitude = 40f;
        public float speed = 2.2f;
        float phase;

        public override void OnSpawned() { phase = Random.value * Mathf.PI * 2f; }

        void Update()
        {
            if (pivot == null) return;
            pivot.localRotation = Quaternion.Euler(Mathf.Sin(Time.time * speed + phase) * amplitude, 0, 0);
        }
    }

    /// <summary>Cannon blocking its lane that fires cannonballs rolling toward the player.</summary>
    public class CannonHazard : HazardBase
    {
        public Transform muzzle;
        public Transform barrel;
        public float fireDistance = 55f;
        public float interval = 1.7f;
        public int shots = 2;
        int shotsLeft;
        float timer;

        public override void OnSpawned()
        {
            shotsLeft = shots;
            timer = 0f;
        }

        void Update()
        {
            if (!Running || shotsLeft <= 0) return;
            float d = DistanceAhead;
            if (d > fireDistance || d < 14f) return;
            timer -= Time.deltaTime;
            if (timer > 0f) return;
            timer = interval;
            shotsLeft--;
            GameManager gm = GameManager.Instance;
            if (gm == null || gm.track == null) return;
            Vector3 p = muzzle != null ? muzzle.position : transform.position + new Vector3(0, 0, -1.5f);
            p.y = 0f;
            gm.track.SpawnTransient("ob_" + ObstacleKind.CannonBall, p);
            if (FxManager.Instance != null)
            {
                FxManager.Instance.Smoke(p + Vector3.up * 0.8f, 14);
                FxManager.Instance.Sparkle(p + Vector3.up * 0.8f, new Color(1f, 0.6f, 0.2f), 10);
            }
            if (AudioManager.Instance != null) AudioManager.Instance.Play(Sfx.Cannon, 0.8f);
            if (barrel != null) barrel.localPosition += new Vector3(0, 0, 0.25f); // recoil, recovers in LateUpdate
        }

        void LateUpdate()
        {
            if (barrel == null) return;
            Vector3 lp = barrel.localPosition;
            lp.z = Mathf.MoveTowards(lp.z, -0.2f, Time.deltaTime * 0.8f);
            barrel.localPosition = lp;
        }
    }

    /// <summary>Idle animation for pirate guards (sword swing and sway).</summary>
    public class GuardHazard : HazardBase
    {
        public Transform swordArm;
        public Transform body;
        float phase;

        public override void OnSpawned() { phase = Random.value * 10f; }

        void Update()
        {
            float t = Time.time * 3f + phase;
            if (swordArm != null) swordArm.localRotation = Quaternion.Euler(-60f + Mathf.Sin(t) * 50f, 0, 15f);
            if (body != null) body.localRotation = Quaternion.Euler(0, 180f + Mathf.Sin(t * 0.5f) * 12f, 0);
        }
    }

    /// <summary>One lane of a collapsing bridge.</summary>
    public class BridgeLane : MonoBehaviour
    {
        public BoxCollider groundCollider;
        public Renderer[] planks;
        [System.NonSerialized] public Vector3 restPosition;
        [System.NonSerialized] public bool collapses;
    }

    /// <summary>
    /// Wooden bridge over water. Rotten lanes (darker planks) shake as the player approaches,
    /// then drop away, leaving open water. At least one lane is always solid.
    /// </summary>
    public class CollapsingBridge : HazardBase
    {
        public BridgeLane[] lanes;
        public float shakeDistance = 30f;
        public float dropDistance = 13f;
        int state; // 0 idle, 1 shaking, 2 dropping
        float fallVelocity;

        void Awake()
        {
            if (lanes == null) return;
            for (int i = 0; i < lanes.Length; i++) if (lanes[i] != null) lanes[i].restPosition = lanes[i].transform.localPosition;
        }

        public void Configure(ObstacleKind[] laneKinds)
        {
            for (int i = 0; i < lanes.Length && i < laneKinds.Length; i++)
            {
                BridgeLane l = lanes[i];
                l.collapses = laneKinds[i] == ObstacleKind.CollapsingBridge;
                Material m = MaterialLibrary.Get(l.collapses ? "PlanksRotten" : "Planks");
                for (int p = 0; p < l.planks.Length; p++) if (l.planks[p] != null) l.planks[p].sharedMaterial = m;
            }
        }

        public override void OnSpawned()
        {
            state = 0;
            fallVelocity = 0;
            if (lanes == null) return;
            for (int i = 0; i < lanes.Length; i++)
            {
                lanes[i].transform.localPosition = lanes[i].restPosition;
                lanes[i].transform.localRotation = Quaternion.identity;
                lanes[i].groundCollider.enabled = true;
                lanes[i].collapses = false;
            }
        }

        /// <summary>Used by revive: stop collapsing and make every lane solid again.</summary>
        public void Stabilize()
        {
            state = 3;
            for (int i = 0; i < lanes.Length; i++)
            {
                lanes[i].collapses = false;
                lanes[i].transform.localPosition = lanes[i].restPosition;
                lanes[i].transform.localRotation = Quaternion.identity;
                lanes[i].groundCollider.enabled = true;
            }
        }

        void Update()
        {
            if (lanes == null || state == 3) return;
            float d = DistanceAhead;
            if (state == 0 && Running && d < shakeDistance)
            {
                state = 1;
                if (AudioManager.Instance != null) AudioManager.Instance.Play(Sfx.Rumble, 0.4f, 1.4f);
            }
            if (state == 1)
            {
                for (int i = 0; i < lanes.Length; i++)
                {
                    if (!lanes[i].collapses) continue;
                    lanes[i].transform.localPosition = lanes[i].restPosition + new Vector3(0, Mathf.Sin(Time.time * 45f + i) * 0.04f, 0);
                }
                if (d < dropDistance)
                {
                    state = 2;
                    for (int i = 0; i < lanes.Length; i++)
                        if (lanes[i].collapses)
                        {
                            lanes[i].groundCollider.enabled = false;
                            if (FxManager.Instance != null) FxManager.Instance.Dust(lanes[i].transform.position + new Vector3(0, 0, 6), 20);
                        }
                }
            }
            else if (state == 2)
            {
                fallVelocity += 18f * Time.deltaTime;
                for (int i = 0; i < lanes.Length; i++)
                {
                    if (!lanes[i].collapses) continue;
                    Transform t = lanes[i].transform;
                    if (t.localPosition.y < -12f) continue;
                    t.localPosition += Vector3.down * fallVelocity * Time.deltaTime;
                    t.localRotation = Quaternion.Euler(t.localPosition.y * -3f, 0, t.localPosition.y * (i - 1) * 2f);
                }
            }
        }
    }
}
