using UnityEngine;

namespace TreasureHunt
{
    /// <summary>Builds every obstacle model procedurally, with fair colliders matched to its rule.</summary>
    public static class ObstacleBuilder
    {
        const PrimitiveType Cube = PrimitiveType.Cube, Cyl = PrimitiveType.Cylinder, Sph = PrimitiveType.Sphere, Cap = PrimitiveType.Capsule;

        public static GameObject Build(ObstacleKind kind)
        {
            if (kind == ObstacleKind.CollapsingBridge) return BuildBridge();
            GameObject root = new GameObject("ob_" + kind);
            GameObject vis = Proc.Node("Visual", root.transform, Vector3.zero);
            Obstacle ob = root.AddComponent<Obstacle>();
            ob.kind = kind;
            ob.visualRoot = vis;
            Transform v = vis.transform;
            Collider hit = null;

            switch (kind)
            {
                case ObstacleKind.Crate:
                    Crate(v, new Vector3(0, 0.45f, 0), new Vector3(1.5f, 0.9f, 0.9f));
                    hit = Proc.Box(root, new Vector3(0, 0.42f, 0), new Vector3(1.6f, 0.85f, 0.9f), true);
                    break;

                case ObstacleKind.CrateStack:
                    Crate(v, new Vector3(-0.42f, 0.5f, 0), new Vector3(0.95f, 1f, 1f));
                    Crate(v, new Vector3(0.48f, 0.5f, 0.05f), new Vector3(0.95f, 1f, 1f));
                    Crate(v, new Vector3(0.05f, 1.45f, 0), new Vector3(1f, 0.9f, 0.95f));
                    Proc.Part(Cyl, "Rope", v, new Vector3(0, 1.0f, 0), new Vector3(0.04f, 0.95f, 0.04f), new Vector3(0, 0, 90));
                    hit = Proc.Box(root, new Vector3(0, 1.1f, 0), new Vector3(1.8f, 2.2f, 1.1f), true);
                    break;

                case ObstacleKind.ExplosiveBarrel:
                    Barrel(v, new Vector3(-0.45f, 0.6f, 0), "ExplosiveRed");
                    Barrel(v, new Vector3(0.45f, 0.6f, 0.05f), "ExplosiveRed");
                    Barrel(v, new Vector3(0f, 1.75f, 0f), "ExplosiveRed");
                    Proc.Part(Cube, "PirateShirt", v, new Vector3(-0.45f, 0.65f, 0.43f), new Vector3(0.35f, 0.25f, 0.02f));
                    Proc.Part(Cube, "PirateShirt", v, new Vector3(0.45f, 0.65f, 0.48f), new Vector3(0.35f, 0.25f, 0.02f));
                    {
                        // Lit fuse
                        GameObject fuse = Proc.Part(Cyl, "Rope", v, new Vector3(0, 2.4f, 0), new Vector3(0.04f, 0.12f, 0.04f));
                        ParticleSystem ps = FxManager.MakeSystem("FuseSpark", fuse.transform, false, true, 25, 0.15f, 0.35f, 0.5f, 1.5f, 0.05f, 0.12f, new Color(1f, 0.7f, 0.2f), 0, ParticleSystemShapeType.Sphere, 0.05f, 40);
                        ps.transform.localPosition = new Vector3(0, 1.1f, 0);
                    }
                    ob.explodes = true;
                    hit = Proc.Box(root, new Vector3(0, 1.1f, 0), new Vector3(1.8f, 2.2f, 1.1f), true);
                    break;

                case ObstacleKind.RollingLog:
                case ObstacleKind.RollingBarrel:
                case ObstacleKind.CannonBall:
                {
                    bool log = kind == ObstacleKind.RollingLog, ball = kind == ObstacleKind.CannonBall;
                    float radius = ball ? 0.35f : log ? 0.42f : 0.45f;
                    GameObject roller = Proc.Node("Roller", v, new Vector3(0, radius, 0));
                    roller.transform.localRotation = Quaternion.Euler(0, 0, 90);
                    if (ball)
                    {
                        Proc.Part(Sph, "Cannon", roller.transform, Vector3.zero, Vector3.one * 0.7f);
                    }
                    else if (log)
                    {
                        Proc.Part(Cyl, "PalmTrunk", roller.transform, Vector3.zero, new Vector3(0.84f, 0.95f, 0.84f));
                        Proc.Part(Cyl, "WoodLight", roller.transform, new Vector3(0, 0.96f, 0), new Vector3(0.7f, 0.02f, 0.7f));
                        Proc.Part(Cyl, "WoodLight", roller.transform, new Vector3(0, -0.96f, 0), new Vector3(0.7f, 0.02f, 0.7f));
                        Proc.Part(Cube, "WoodDark", roller.transform, new Vector3(0.43f, 0.3f, 0), new Vector3(0.05f, 0.5f, 0.12f));
                    }
                    else
                    {
                        Proc.Part(Cyl, "Barrel", roller.transform, Vector3.zero, new Vector3(0.9f, 0.6f, 0.9f));
                        Proc.Part(Cyl, "Iron", roller.transform, new Vector3(0, 0.35f, 0), new Vector3(0.93f, 0.04f, 0.93f));
                        Proc.Part(Cyl, "Iron", roller.transform, new Vector3(0, -0.35f, 0), new Vector3(0.93f, 0.04f, 0.93f));
                        Proc.Part(Cyl, "Iron", roller.transform, Vector3.zero, new Vector3(0.95f, 0.04f, 0.95f));
                    }
                    RollingHazard rh = root.AddComponent<RollingHazard>();
                    rh.roller = roller.transform;
                    rh.radius = radius;
                    rh.rollSpeed = ball ? 10f : 7f;
                    rh.startRolling = ball;
                    if (!ball)
                    {
                        GameObject warn = Proc.Mesh(MeshFactory.Octahedron(), "WarningSolid", root.transform, new Vector3(0, 2.3f, 0), new Vector3(0.35f, 0.5f, 0.35f), Vector3.zero, false, "Warning");
                        warn.AddComponent<Rotator>().degreesPerSecond = 180f;
                        warn.AddComponent<Pulse>().amount = 0.25f;
                        rh.warning = warn;
                    }
                    float w = ball ? 0.75f : log ? 1.85f : 1.25f;
                    hit = Proc.Box(roller, Vector3.zero, new Vector3(radius * 1.8f, w, radius * 1.8f), true);
                    break;
                }

                case ObstacleKind.FallingRock:
                {
                    GameObject rock = Proc.Node("Rock", v, new Vector3(0, 14, 0));
                    Proc.Part(Sph, "RockDark", rock.transform, new Vector3(0, 0.85f, 0), new Vector3(1.8f, 1.7f, 1.5f), new Vector3(10, 30, 5));
                    Proc.Part(Sph, "Rock", rock.transform, new Vector3(0.45f, 1.35f, 0.1f), new Vector3(0.9f, 0.8f, 0.9f), new Vector3(0, 60, 20));
                    Proc.Part(Sph, "Rock", rock.transform, new Vector3(-0.5f, 0.4f, 0.3f), new Vector3(0.8f, 0.7f, 0.7f));
                    GameObject warn = Proc.Node("Warning", root.transform, Vector3.zero);
                    Proc.Part(Cyl, "Warning", warn.transform, new Vector3(0, 0.03f, 0), new Vector3(2.0f, 0.01f, 2.0f), Vector3.zero, false);
                    GameObject mark = Proc.Mesh(MeshFactory.Octahedron(), "WarningSolid", warn.transform, new Vector3(0, 2.6f, 0), new Vector3(0.35f, 0.5f, 0.35f), Vector3.zero, false, "Mark");
                    mark.AddComponent<Rotator>().degreesPerSecond = 180f;
                    warn.AddComponent<Pulse>().amount = 0.1f;
                    FallingRockHazard fr = root.AddComponent<FallingRockHazard>();
                    fr.rock = rock.transform;
                    fr.warning = warn;
                    hit = Proc.Box(rock, new Vector3(0, 0.95f, 0), new Vector3(1.8f, 1.9f, 1.4f), true);
                    break;
                }

                case ObstacleKind.PirateGuard:
                {
                    GameObject body = Proc.Node("Body", v, Vector3.zero);
                    body.transform.localRotation = Quaternion.Euler(0, 180, 0);
                    HumanoidParts h = PirateBuilder.BuildHumanoid(body.transform, "GuardCoat", false);
                    Proc.Part(Cube, "Silver", h.armR, new Vector3(0, -0.6f, 0.35f), new Vector3(0.05f, 0.08f, 0.75f));
                    Proc.Part(Cube, "Gold", h.armR, new Vector3(0, -0.6f, 0.0f), new Vector3(0.14f, 0.1f, 0.05f));
                    h.legL.localRotation = Quaternion.Euler(-12, 0, -6);
                    h.legR.localRotation = Quaternion.Euler(12, 0, 6);
                    h.armL.localRotation = Quaternion.Euler(0, 0, -25);
                    GuardHazard gh = root.AddComponent<GuardHazard>();
                    gh.swordArm = h.armR;
                    gh.body = body.transform;
                    hit = Proc.Box(root, new Vector3(0, 1f, 0), new Vector3(1.3f, 2f, 0.9f), true);
                    break;
                }

                case ObstacleKind.SwingingAnchor:
                {
                    Proc.Part(Cube, "WoodDark", v, new Vector3(-1.2f, 3.3f, 0), new Vector3(0.25f, 6.6f, 0.25f));
                    Proc.Part(Cube, "WoodDark", v, new Vector3(1.2f, 3.3f, 0), new Vector3(0.25f, 6.6f, 0.25f));
                    Proc.Part(Cube, "WoodDark", v, new Vector3(0, 6.6f, 0), new Vector3(2.7f, 0.3f, 0.35f));
                    GameObject pivot = Proc.Node("Pivot", v, new Vector3(0, 6.4f, 0));
                    for (int i = 0; i < 6; i++)
                        Proc.Mesh(MeshFactory.Torus(0.12f, 0.03f), "Iron", pivot.transform, new Vector3(0, -0.3f - i * 0.55f, 0), Vector3.one, new Vector3(i % 2 == 0 ? 90 : 0, 0, 90), true, "Chain");
                    GameObject anchor = Proc.Node("Anchor", pivot.transform, new Vector3(0, -4.4f, 0));
                    Proc.Part(Cyl, "Iron", anchor.transform, new Vector3(0, 0.3f, 0), new Vector3(0.16f, 0.65f, 0.16f));
                    Proc.Part(Cube, "Iron", anchor.transform, new Vector3(0, 0.8f, 0), new Vector3(0.7f, 0.12f, 0.14f));
                    Proc.Mesh(MeshFactory.Torus(0.16f, 0.05f), "Iron", anchor.transform, new Vector3(0, 1.05f, 0), Vector3.one, new Vector3(90, 0, 0), true, "Ring");
                    Proc.Part(Cube, "Iron", anchor.transform, new Vector3(-0.42f, -0.2f, 0), new Vector3(0.75f, 0.16f, 0.16f), new Vector3(0, 0, -35));
                    Proc.Part(Cube, "Iron", anchor.transform, new Vector3(0.42f, -0.2f, 0), new Vector3(0.75f, 0.16f, 0.16f), new Vector3(0, 0, 35));
                    Proc.Mesh(MeshFactory.Cone(), "Iron", anchor.transform, new Vector3(-0.75f, 0.0f, 0), new Vector3(0.25f, 0.35f, 0.25f), new Vector3(0, 0, 20));
                    Proc.Mesh(MeshFactory.Cone(), "Iron", anchor.transform, new Vector3(0.75f, 0.0f, 0), new Vector3(0.25f, 0.35f, 0.25f), new Vector3(0, 0, -20));
                    SwingingHazard sw = root.AddComponent<SwingingHazard>();
                    sw.pivot = pivot.transform;
                    hit = Proc.Box(anchor, new Vector3(0, 0.4f, 0), new Vector3(1.7f, 1.7f, 0.8f), true);
                    break;
                }

                case ObstacleKind.Cannon:
                {
                    Proc.Part(Cube, "WoodDark", v, new Vector3(0, 0.42f, 0), new Vector3(1.0f, 0.4f, 1.6f));
                    for (int i = 0; i < 4; i++)
                        Proc.Part(Cyl, "Wood", v, new Vector3(i < 2 ? -0.55f : 0.55f, 0.25f, i % 2 == 0 ? -0.55f : 0.55f), new Vector3(0.5f, 0.06f, 0.5f), new Vector3(0, 0, 90));
                    GameObject barrel = Proc.Node("Barrel", v, new Vector3(0, 0.85f, -0.2f));
                    Proc.Part(Cyl, "Cannon", barrel.transform, Vector3.zero, new Vector3(0.48f, 0.95f, 0.48f), new Vector3(-82, 0, 0));
                    Proc.Part(Cyl, "Cannon", barrel.transform, new Vector3(0, -0.12f, -0.9f), new Vector3(0.6f, 0.08f, 0.6f), new Vector3(-82, 0, 0));
                    Proc.Part(Sph, "Cannon", barrel.transform, new Vector3(0, 0.1f, 0.95f), Vector3.one * 0.5f);
                    GameObject muzzle = Proc.Node("Muzzle", barrel.transform, new Vector3(0, -0.15f, -1.2f));
                    Proc.Part(Sph, "Cannon", v, new Vector3(0.6f, 0.2f, 0.9f), Vector3.one * 0.35f);
                    Proc.Part(Sph, "Cannon", v, new Vector3(0.85f, 0.2f, 0.75f), Vector3.one * 0.35f);
                    CannonHazard ch = root.AddComponent<CannonHazard>();
                    ch.barrel = barrel.transform;
                    ch.muzzle = muzzle.transform;
                    hit = Proc.Box(root, new Vector3(0, 0.75f, 0), new Vector3(1.7f, 1.5f, 2.2f), true);
                    break;
                }

                case ObstacleKind.LowRope:
                {
                    Proc.Part(Cyl, "WoodDark", v, new Vector3(-1.3f, 1.8f, 0), new Vector3(0.18f, 1.8f, 0.18f));
                    Proc.Part(Cyl, "WoodDark", v, new Vector3(1.3f, 1.8f, 0), new Vector3(0.18f, 1.8f, 0.18f));
                    Proc.Part(Cyl, "Rope", v, new Vector3(0, 1.35f, 0), new Vector3(0.06f, 1.3f, 0.06f), new Vector3(0, 0, 90));
                    Proc.Part(Cyl, "Rope", v, new Vector3(0, 3.45f, 0), new Vector3(0.06f, 1.3f, 0.06f), new Vector3(0, 0, 90));
                    Proc.Part(Cube, "SailDark", v, new Vector3(0, 2.4f, 0), new Vector3(2.4f, 2.0f, 0.03f));
                    for (int i = 0; i < 5; i++)
                        Proc.Part(Cube, i % 2 == 0 ? "Bandana" : "Sail", v, new Vector3(-1f + i * 0.5f, 1.2f, -0.03f), new Vector3(0.28f, 0.32f, 0.02f), new Vector3(0, 0, 45));
                    Proc.Part(Sph, "PirateShirt", v, new Vector3(0, 2.5f, -0.04f), new Vector3(0.5f, 0.5f, 0.02f));
                    hit = Proc.Box(root, new Vector3(0, 2.35f, 0), new Vector3(2.0f, 2.4f, 0.6f), true);
                    break;
                }

                case ObstacleKind.SpikeTrap:
                {
                    Proc.Part(Cube, "IronRust", v, new Vector3(0, 0.05f, 0), new Vector3(1.9f, 0.1f, 1.3f));
                    for (int x = 0; x < 4; x++)
                        for (int z = 0; z < 3; z++)
                            Proc.Mesh(MeshFactory.Cone(6), "Spike", v, new Vector3(-0.7f + x * 0.47f, 0.08f, -0.4f + z * 0.4f), new Vector3(0.22f, 0.5f, 0.22f), Vector3.zero, true, "Spike");
                    Proc.Part(Cube, "Warning", v, new Vector3(0, 0.11f, -0.72f), new Vector3(1.9f, 0.02f, 0.12f), Vector3.zero, false);
                    hit = Proc.Box(root, new Vector3(0, 0.3f, 0), new Vector3(1.6f, 0.6f, 1.0f), true);
                    break;
                }

                case ObstacleKind.CaveTrap:
                {
                    Proc.Part(Cube, "RockDark", v, new Vector3(-1.3f, 2f, 0), new Vector3(0.4f, 4f, 0.5f));
                    Proc.Part(Cube, "RockDark", v, new Vector3(1.3f, 2f, 0), new Vector3(0.4f, 4f, 0.5f));
                    Proc.Part(Cube, "StoneCave", v, new Vector3(0, 3.6f, 0), new Vector3(3f, 0.6f, 0.6f));
                    Proc.Mesh(MeshFactory.Cone(), "Crystal", v, new Vector3(0, 3.9f, -0.32f), new Vector3(0.3f, 0.4f, 0.1f), new Vector3(-90, 0, 0), false, "Rune");
                    GameObject spin = Proc.Node("SpikedLog", v, new Vector3(0, 1.6f, 0));
                    Proc.Part(Cyl, "WoodDark", spin.transform, Vector3.zero, new Vector3(0.45f, 1.15f, 0.45f), new Vector3(0, 0, 90));
                    for (int i = 0; i < 12; i++)
                    {
                        float a = i * 90f;
                        float x = -0.9f + (i / 4) * 0.9f;
                        GameObject s = Proc.Mesh(MeshFactory.Cone(6), "Spike", spin.transform, new Vector3(x, 0, 0), new Vector3(0.14f, 0.45f, 0.14f), new Vector3(a, 0, 0), true, "Spike");
                        s.transform.localPosition += s.transform.up * 0.15f;
                    }
                    Rotator rot = spin.AddComponent<Rotator>();
                    rot.axis = Vector3.right;
                    rot.degreesPerSecond = 220f;
                    hit = Proc.Box(root, new Vector3(0, 2.3f, 0), new Vector3(2.0f, 2.3f, 0.7f), true);
                    break;
                }
            }

            ob.hitColliders = hit != null ? new Collider[] { hit } : new Collider[0];
            return root;
        }

        static void Crate(Transform parent, Vector3 pos, Vector3 size)
        {
            Proc.Part(Cube, "Wood", parent, pos, size);
            Vector3 s = size;
            Proc.Part(Cube, "WoodDark", parent, pos + new Vector3(0, s.y * 0.5f - 0.05f, 0), new Vector3(s.x + 0.02f, 0.1f, s.z + 0.02f));
            Proc.Part(Cube, "WoodDark", parent, pos - new Vector3(0, s.y * 0.5f - 0.05f, 0), new Vector3(s.x + 0.02f, 0.1f, s.z + 0.02f));
            Proc.Part(Cube, "WoodDark", parent, pos + new Vector3(0, 0, -s.z * 0.5f), new Vector3(0.12f, s.y * 1.25f, 0.04f), new Vector3(0, 0, Mathf.Atan2(s.y, s.x) * Mathf.Rad2Deg));
        }

        static void Barrel(Transform parent, Vector3 pos, string mat)
        {
            Proc.Part(Cyl, mat, parent, pos, new Vector3(0.85f, 0.6f, 0.85f));
            Proc.Part(Cyl, "Iron", parent, pos + new Vector3(0, 0.38f, 0), new Vector3(0.88f, 0.04f, 0.88f));
            Proc.Part(Cyl, "Iron", parent, pos - new Vector3(0, 0.38f, 0), new Vector3(0.88f, 0.04f, 0.88f));
        }

        /// <summary>12 m three-lane wooden bridge. Each lane has its own ground collider.</summary>
        static GameObject BuildBridge()
        {
            GameObject root = new GameObject("ob_CollapsingBridge");
            CollapsingBridge cb = root.AddComponent<CollapsingBridge>();
            cb.lanes = new BridgeLane[3];
            for (int l = 0; l < 3; l++)
            {
                GameObject lane = Proc.Node("Lane" + l, root.transform, new Vector3((l - 1) * 2.5f, 0, 0));
                BridgeLane bl = lane.AddComponent<BridgeLane>();
                Renderer[] planks = new Renderer[12];
                for (int p = 0; p < 12; p++)
                    planks[p] = Proc.Part(Cube, "Planks", lane.transform, new Vector3(0, -0.08f, 0.5f + p), new Vector3(2.4f, 0.16f, 0.9f), new Vector3(0, (p % 3 - 1) * 1.5f, 0)).GetComponent<Renderer>();
                Proc.Part(Cube, "WoodDark", lane.transform, new Vector3(-1.1f, -0.25f, 6f), new Vector3(0.15f, 0.15f, 12f));
                Proc.Part(Cube, "WoodDark", lane.transform, new Vector3(1.1f, -0.25f, 6f), new Vector3(0.15f, 0.15f, 12f));
                bl.planks = planks;
                bl.groundCollider = Proc.Box(lane, new Vector3(0, -0.25f, 6f), new Vector3(2.5f, 0.5f, 12f), false);
                cb.lanes[l] = bl;
            }
            // Rope railings and posts
            for (int side = -1; side <= 1; side += 2)
            {
                for (int p = 0; p < 4; p++)
                    Proc.Part(Cyl, "WoodDark", root.transform, new Vector3(side * 4.1f, 0.2f, p * 4f), new Vector3(0.22f, 1.4f, 0.22f));
                Proc.Part(Cyl, "Rope", root.transform, new Vector3(side * 4.1f, 1.3f, 6f), new Vector3(0.05f, 6f, 0.05f), new Vector3(90, 0, 0));
                Proc.Part(Cyl, "Rope", root.transform, new Vector3(side * 4.1f, 0.7f, 6f), new Vector3(0.05f, 6f, 0.05f), new Vector3(90, 0, 0));
            }
            return root;
        }
    }
}
