using UnityEngine;

namespace TreasureHunt
{
    /// <summary>
    /// Base component for anything that ends the run on contact. Colliders are triggers;
    /// the player (kinematic Rigidbody) reports the hit to the GameManager exactly once.
    /// </summary>
    public class Obstacle : MonoBehaviour, IPoolable
    {
        public ObstacleKind kind;
        public Collider[] hitColliders;
        public GameObject visualRoot;
        public bool explodes;
        [System.NonSerialized] public bool consumed;

        public LaneContent Content { get { return SpawnPlanner.ContentOf(kind); } }

        public void OnSpawned()
        {
            consumed = false;
            SetColliders(true);
            if (visualRoot != null) visualRoot.SetActive(true);
        }

        public void OnDespawned() { }

        void SetColliders(bool on)
        {
            if (hitColliders == null) return;
            for (int i = 0; i < hitColliders.Length; i++) if (hitColliders[i] != null) hitColliders[i].enabled = on;
        }

        /// <summary>Destroys the obstacle visually (shield / speed boost / revive clearing).</summary>
        public void Smash(bool withEffects)
        {
            if (consumed && visualRoot != null && !visualRoot.activeSelf) return;
            consumed = true;
            SetColliders(false);
            if (withEffects && FxManager.Instance != null)
            {
                Vector3 p = transform.position + Vector3.up * 0.8f;
                if (explodes) FxManager.Instance.Explosion(p);
                else { FxManager.Instance.Dust(p, 24); FxManager.Instance.Sparkle(p, new Color(1f, 0.85f, 0.5f), 10); }
            }
            if (visualRoot != null) visualRoot.SetActive(false);
        }
    }
}
