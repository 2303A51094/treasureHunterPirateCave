using NUnit.Framework;
using UnityEngine;

namespace TreasureHunt.Tests
{
    /// <summary>EditMode tests for the pure gameplay logic (Window > General > Test Runner > EditMode > Run All).</summary>
    public class GameplayLogicTests
    {
        [Test]
        public void SpawnPlanner_NeverBlocksAllThreeLanes()
        {
            PlannedRow row = new PlannedRow();
            for (int seed = 0; seed < 20; seed++)
            {
                System.Random rng = new System.Random(seed);
                for (int t = 0; t < ThemeInfo.Count; t++)
                    for (int i = 0; i < 5000; i++)
                    {
                        SpawnPlanner.Plan(rng, (ThemeId)t, i / 5000f, row);
                        Assert.IsTrue(SpawnPlanner.IsSafe(row.lanes), "Unsafe row for theme " + (ThemeId)t);
                    }
            }
        }

        [Test]
        public void SpawnPlanner_BridgeAlwaysHasASolidLane()
        {
            PlannedRow row = new PlannedRow();
            System.Random rng = new System.Random(3);
            int bridges = 0;
            for (int i = 0; i < 50000; i++)
            {
                SpawnPlanner.Plan(rng, ThemeId.PirateHarbor, 1f, row);
                if (row.type != RowType.Bridge) continue;
                bridges++;
                int solid = 0;
                for (int l = 0; l < 3; l++) if (row.lanes[l] == ObstacleKind.None) solid++;
                Assert.GreaterOrEqual(solid, 1);
                Assert.AreEqual(12f, row.length, 0.001f);
            }
            Assert.Greater(bridges, 0, "Bridges should appear");
        }

        [Test]
        public void SpawnPlanner_GapsAreJumpable()
        {
            GameConfig cfg = new GameConfig();
            // Horizontal distance covered while airborne at the slowest speed.
            float airTime = 2f * cfg.jumpVelocity / cfg.gravity;
            float minJumpDistance = airTime * cfg.startSpeed;
            PlannedRow row = new PlannedRow();
            System.Random rng = new System.Random(5);
            for (int i = 0; i < 50000; i++)
            {
                SpawnPlanner.Plan(rng, ThemeId.TropicalIsland, 1f, row);
                if (row.type == RowType.FullGap) Assert.Less(row.length, minJumpDistance * 0.7f, "Gap too wide to jump");
            }
        }

        [Test]
        public void SpawnPlanner_ObstacleRulesMatchHeights()
        {
            Assert.AreEqual(LaneContent.Jump, SpawnPlanner.ContentOf(ObstacleKind.Crate));
            Assert.AreEqual(LaneContent.Jump, SpawnPlanner.ContentOf(ObstacleKind.SpikeTrap));
            Assert.AreEqual(LaneContent.Slide, SpawnPlanner.ContentOf(ObstacleKind.LowRope));
            Assert.AreEqual(LaneContent.Slide, SpawnPlanner.ContentOf(ObstacleKind.CaveTrap));
            Assert.AreEqual(LaneContent.Block, SpawnPlanner.ContentOf(ObstacleKind.PirateGuard));
            Assert.AreEqual(LaneContent.Empty, SpawnPlanner.ContentOf(ObstacleKind.None));
        }

        [Test]
        public void JumpClearsJumpObstaclesButNotSlideObstacles()
        {
            GameConfig cfg = new GameConfig();
            float apex = cfg.jumpVelocity * cfg.jumpVelocity / (2f * cfg.gravity);
            Assert.Greater(apex, 0.9f, "Jump apex must clear a 0.85 m crate collider");
            // Slide obstacles' colliders span 1.15 m .. 3.55 m: a jumping 1.7 m capsule can never pass over them.
            Assert.Less(apex + 1.7f, 3.55f + 1.7f);
            Assert.Less(0.8f, 1.15f, "Sliding capsule (0.8 m) passes under slide obstacles (1.15 m)");
            Assert.Greater(1.7f, 1.15f, "Standing capsule is hit by slide obstacles");
        }

        [Test]
        public void RowSpacing_GrowsWithSpeedAndRespectsMinimum()
        {
            Assert.AreEqual(15f, SpawnPlanner.RowSpacing(5f, 15f, 0.95f), 0.001f);
            Assert.AreEqual(26f * 0.95f, SpawnPlanner.RowSpacing(26f, 15f, 0.95f), 0.001f);
        }

        [Test]
        public void Swipe_ClassifiesDirectionsAndIgnoresTaps()
        {
            Assert.AreEqual(InputCommand.None, SwipeLogic.Classify(new Vector2(5, 3), 50));
            Assert.AreEqual(InputCommand.Left, SwipeLogic.Classify(new Vector2(-80, 10), 50));
            Assert.AreEqual(InputCommand.Right, SwipeLogic.Classify(new Vector2(80, -30), 50));
            Assert.AreEqual(InputCommand.Jump, SwipeLogic.Classify(new Vector2(10, 90), 50));
            Assert.AreEqual(InputCommand.Slide, SwipeLogic.Classify(new Vector2(-20, -90), 50));
        }

        [Test]
        public void PowerUps_RefreshDoesNotCompoundAndExpires()
        {
            PowerUpTimers t = new PowerUpTimers();
            Assert.IsTrue(t.Activate(PowerUpType.Magnet, 10f));
            t.Tick(4f);
            Assert.AreEqual(6f, t.Remaining(PowerUpType.Magnet), 0.001f);
            t.Activate(PowerUpType.Magnet, 10f);
            Assert.AreEqual(10f, t.Remaining(PowerUpType.Magnet), 0.001f, "Refresh to full, never stack beyond");
            int expired = t.Tick(10.5f);
            Assert.IsFalse(t.IsActive(PowerUpType.Magnet));
            Assert.AreNotEqual(0, expired & (1 << (int)PowerUpType.Magnet));
            Assert.IsFalse(t.Activate(PowerUpType.TreasureBonus, 5f), "Treasure bonus is instant");
        }

        [Test]
        public void PowerUps_ShieldAbsorbsExactlyOneHit()
        {
            PowerUpTimers t = new PowerUpTimers();
            t.Activate(PowerUpType.Shield, 20f);
            Assert.IsTrue(t.ConsumeShield());
            Assert.IsFalse(t.ConsumeShield());
            Assert.IsFalse(t.IsActive(PowerUpType.Shield));
        }

        [Test]
        public void PowerUps_DifferentTypesRunTogether()
        {
            PowerUpTimers t = new PowerUpTimers();
            t.Activate(PowerUpType.Magnet, 5f);
            t.Activate(PowerUpType.ScoreMultiplier, 8f);
            t.Tick(6f);
            Assert.IsFalse(t.IsActive(PowerUpType.Magnet));
            Assert.IsTrue(t.IsActive(PowerUpType.ScoreMultiplier));
        }

        [Test]
        public void SaveSystem_PersistsScoreAndWallet()
        {
            string old = SaveSystem.Prefix;
            SaveSystem.Prefix = "THPC_TEST_";
            try
            {
                SaveSystem.DeleteAll();
                Assert.IsTrue(SaveSystem.SubmitScore(120));
                Assert.IsFalse(SaveSystem.SubmitScore(100));
                Assert.AreEqual(120, SaveSystem.BestScore);
                SaveSystem.AddGems(25);
                Assert.IsFalse(SaveSystem.TrySpendGems(30));
                Assert.IsTrue(SaveSystem.TrySpendGems(20));
                Assert.AreEqual(5, SaveSystem.Gems);
                SaveSystem.AddKeys(1);
                Assert.IsTrue(SaveSystem.TrySpendKey());
                Assert.IsFalse(SaveSystem.TrySpendKey());
                SaveSystem.SoundOn = false;
                Assert.IsFalse(SaveSystem.SoundOn);
            }
            finally
            {
                SaveSystem.DeleteAll();
                SaveSystem.Prefix = old;
            }
        }

        [Test]
        public void ObjectPool_ReusesReleasedObjects()
        {
            int created = 0;
            GameObject root = new GameObject("PoolRoot");
            try
            {
                ObjectPool pool = new ObjectPool(k => { created++; return new GameObject(k); }, root.transform);
                PooledObject a = pool.Get("x", null, Vector3.zero, Quaternion.identity);
                pool.Release(a);
                pool.Release(a); // double release is ignored
                PooledObject b = pool.Get("x", null, Vector3.one, Quaternion.identity);
                Assert.AreSame(a, b);
                Assert.AreEqual(1, created);
                Assert.AreEqual(Vector3.one, b.transform.position);
                Object.DestroyImmediate(b.gameObject);
            }
            finally { Object.DestroyImmediate(root); }
        }

        [Test]
        public void WorldFactory_EveryKeyBuildsProcedurally()
        {
            GameConfig cfg = new GameConfig();
            foreach (string key in WorldFactory.AllKeys(cfg))
            {
                GameObject go = WorldFactory.Build(key, cfg);
                Assert.IsNotNull(go, key);
                if (key.StartsWith("ob_") && key != "ob_CollapsingBridge")
                {
                    Obstacle o = go.GetComponent<Obstacle>();
                    Assert.IsNotNull(o, key);
                    Assert.Greater(o.hitColliders.Length, 0, key);
                    foreach (Collider c in o.hitColliders) Assert.IsTrue(c.isTrigger, key);
                }
                if (key.StartsWith("col_") || key.StartsWith("pu_"))
                    Assert.IsTrue(go.GetComponent<Collider>().isTrigger, key);
                Object.DestroyImmediate(go);
            }
        }
    }
}
