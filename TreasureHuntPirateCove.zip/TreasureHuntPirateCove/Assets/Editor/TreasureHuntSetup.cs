using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;
#if UNITY_2021_2_OR_NEWER
using UnityEditor.Build;
#endif

namespace TreasureHunt.EditorTools
{
    /// <summary>
    /// One-click project generator: Treasure Hunt > Build Complete Game.
    /// Creates folders, textures, materials, meshes and every prefab, builds the PirateCove scene,
    /// configures player/build settings and validates all references. Runs automatically the first
    /// time the delivered project is opened.
    /// </summary>
    [InitializeOnLoad]
    public static class TreasureHuntSetup
    {
        public const string ScenePath = "Assets/Scenes/PirateCove.unity";
        public const string CatalogPath = "Assets/Settings/PirateCovePrefabCatalog.asset";
        public const string MarkerPath = "Assets/Settings/TreasureHuntAutoSetup.pending";
        const string GenMaterials = "Assets/Materials/PirateCove";
        const string GenTextures = "Assets/Textures/PirateCove";
        const string GenModels = "Assets/Models/PirateCove";
        const string PrefabRoot = "Assets/Prefabs/PirateCove";
        const string LightingPath = "Assets/Settings/PirateCoveLighting.lighting";

        static TreasureHuntSetup()
        {
            EditorApplication.delayCall += AutoSetupCheck;
        }

        static void AutoSetupCheck()
        {
            if (Application.isBatchMode || EditorApplication.isPlayingOrWillChangePlaymode) return;
            if (EditorApplication.isCompiling || EditorApplication.isUpdating)
            {
                EditorApplication.delayCall += AutoSetupCheck;
                return;
            }
            if (File.Exists(MarkerPath))
            {
                Debug.Log("[TreasureHunt] First open detected - generating the complete game...");
                RunFullSetup(true);
                return;
            }
            if (!File.Exists(ScenePath))
            {
                string key = "TreasureHunt.AskedSetup." + Application.dataPath;
                if (EditorPrefs.GetBool(key, false)) return;
                EditorPrefs.SetBool(key, true);
                if (EditorUtility.DisplayDialog("Treasure Hunt - Pirate Cove",
                    "Generate the Pirate Cove scene, prefabs and materials now?\n\n(You can run this any time from the menu: Treasure Hunt > Build Complete Game.)",
                    "Generate", "Later"))
                    RunFullSetup(true);
            }
        }

        // ------------------------------------------------------------------ menu
        [MenuItem("Treasure Hunt/Build Complete Game", false, 0)]
        public static void BuildCompleteGame() { RunFullSetup(true); }

        [MenuItem("Treasure Hunt/Open Game Scene", false, 1)]
        public static void OpenScene()
        {
            if (!File.Exists(ScenePath)) { RunFullSetup(true); return; }
            if (EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) EditorSceneManager.OpenScene(ScenePath);
        }

        [MenuItem("Treasure Hunt/Validate Project", false, 20)]
        public static void ValidateMenu()
        {
            string report;
            bool ok = Validate(out report);
            EditorUtility.DisplayDialog("Treasure Hunt validation", ok ? "All checks passed.\n\n" + Short(report) : "Problems found - see Console.\n\n" + Short(report), "OK");
        }

        [MenuItem("Treasure Hunt/Export UnityPackage", false, 40)]
        public static void ExportPackageMenu() { ExportPackage(); }

        [MenuItem("Treasure Hunt/Build Android APK", false, 41)]
        public static void BuildAndroidMenu() { BuildAndroid(); }

        [MenuItem("Treasure Hunt/Reset Saved Progress", false, 60)]
        public static void ResetProgress()
        {
            if (EditorUtility.DisplayDialog("Reset progress", "Delete best score, coins, gems, keys and settings?", "Reset", "Cancel"))
            {
                SaveSystem.DeleteAll();
                PlayerPrefs.Save();
            }
        }

        static string Short(string s) { return s.Length > 900 ? s.Substring(0, 900) + "\n..." : s; }

        // ------------------------------------------------------------------ batch-mode entry points
        /// <summary>Unity -batchmode -quit -projectPath ... -executeMethod TreasureHunt.EditorTools.TreasureHuntSetup.BatchSetup</summary>
        public static void BatchSetup()
        {
            bool ok = RunFullSetup(false);
            string report;
            ok &= Validate(out report);
            EditorApplication.Exit(ok ? 0 : 1);
        }

        public static void BatchBuildAndroid()
        {
            if (!File.Exists(ScenePath)) RunFullSetup(false);
            EditorApplication.Exit(BuildAndroid() ? 0 : 1);
        }

        public static void BatchExportPackage()
        {
            if (!File.Exists(ScenePath)) RunFullSetup(false);
            ExportPackage();
            EditorApplication.Exit(0);
        }

        // ------------------------------------------------------------------ setup
        public static bool RunFullSetup(bool openScene)
        {
            if (!Application.isBatchMode && !EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return false;
            try
            {
                Progress("Preparing", 0.02f);
                usedNames.Clear();
                EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                EnsureFolders();
                ConfigureProject();

                MaterialLibrary.Catalog = null;
                WorldFactory.Catalog = null;
                MaterialLibrary.ClearCache();
                MeshFactory.ClearCache();
                TextureFactory.ClearCache();

                Progress("Generating textures & materials", 0.1f);
                foreach (string n in MaterialLibrary.AllNames) MaterialLibrary.Get(n);
                MaterialLibrary.Particle();
                foreach (Texture2D t in new List<Texture2D>(TextureFactory.All)) SaveAsset(t, GenTextures, t.name, ".asset");
                List<Material> mats = new List<Material>(MaterialLibrary.All);
                foreach (Material m in mats) SaveAsset(m, GenMaterials, m.name, ".mat");

                PrefabCatalog catalog = ScriptableObject.CreateInstance<PrefabCatalog>();
                catalog.materials.AddRange(mats);

                GameConfig cfg = new GameConfig();
                List<string> keys = WorldFactory.AllKeys(cfg);
                int savedMeshes = 0;
                for (int i = 0; i < keys.Count; i++)
                {
                    string key = keys[i];
                    Progress("Building prefab " + key, 0.15f + 0.7f * i / keys.Count);
                    GameObject go = WorldFactory.Build(key, cfg);
                    savedMeshes = SaveNewMeshes(savedMeshes);
                    string folder = PrefabRoot + "/" + Category(key);
                    EnsureFolder(folder);
                    GameObject prefab = PrefabUtility.SaveAsPrefabAsset(go, folder + "/" + key + ".prefab");
                    Object.DestroyImmediate(go);
                    if (prefab == null) { Debug.LogError("[TreasureHunt] Failed to save prefab " + key); continue; }
                    PrefabCatalog.Entry e = new PrefabCatalog.Entry();
                    e.key = key;
                    e.prefab = prefab;
                    catalog.prefabs.Add(e);
                }
                SaveAsset(catalog, "Assets/Settings", "PirateCovePrefabCatalog", ".asset");

                Progress("Building scene", 0.9f);
                CreateScene(catalog);

                if (File.Exists(MarkerPath)) AssetDatabase.DeleteAsset(MarkerPath);
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();

                string report;
                bool ok = Validate(out report);
                Debug.Log("[TreasureHunt] Setup complete. Validation " + (ok ? "PASSED" : "FAILED") + "\n" + report);
                if (openScene && !Application.isBatchMode) EditorSceneManager.OpenScene(ScenePath);
                return ok;
            }
            catch (Exception ex)
            {
                Debug.LogError("[TreasureHunt] Setup failed: " + ex);
                return false;
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
        }

        static void Progress(string msg, float p)
        {
            if (!Application.isBatchMode) EditorUtility.DisplayProgressBar("Treasure Hunt - Pirate Cove", msg, p);
        }

        static string Category(string key)
        {
            if (key == "player") return "Player";
            if (key.StartsWith("ob_")) return "Obstacles";
            if (key.StartsWith("col_")) return "Collectibles";
            if (key.StartsWith("pu_")) return "PowerUps";
            if (key.StartsWith("gnd_")) return "Track";
            return "Environment";
        }

        static void EnsureFolder(string path)
        {
            if (AssetDatabase.IsValidFolder(path)) return;
            string parent = Path.GetDirectoryName(path).Replace('\\', '/');
            EnsureFolder(parent);
            AssetDatabase.CreateFolder(parent, Path.GetFileName(path));
        }

        static void EnsureFolders()
        {
            string[] folders =
            {
                "Assets/Scenes", "Assets/Scripts", "Assets/Prefabs", "Assets/Materials", "Assets/Models", "Assets/Textures",
                "Assets/Audio", "Assets/Settings", "Assets/Editor", GenMaterials, GenTextures, GenModels, PrefabRoot
            };
            // Regenerate cleanly: remove ONLY this game's previous generated output (safe inside existing projects).
            string[] regenerate = { GenMaterials, GenTextures, GenModels, PrefabRoot, CatalogPath, LightingPath };
            for (int i = 0; i < regenerate.Length; i++)
                if (AssetDatabase.IsValidFolder(regenerate[i]) || File.Exists(regenerate[i])) AssetDatabase.DeleteAsset(regenerate[i]);
            for (int i = 0; i < folders.Length; i++) EnsureFolder(folders[i]);
        }

        static readonly HashSet<string> usedNames = new HashSet<string>();

        static void SaveAsset(Object obj, string folder, string name, string ext)
        {
            if (obj == null || AssetDatabase.Contains(obj)) return;
            EnsureFolder(folder);
            string safe = name.Replace('/', '_').Replace('\\', '_').Replace(':', '_');
            string path = folder + "/" + safe + ext;
            int n = 1;
            while (usedNames.Contains(path) || File.Exists(path)) path = folder + "/" + safe + "_" + (n++) + ext;
            usedNames.Add(path);
            AssetDatabase.CreateAsset(obj, path);
        }

        static int SaveNewMeshes(int alreadySaved)
        {
            List<Mesh> gen = MeshFactory.Generated;
            for (int i = alreadySaved; i < gen.Count; i++)
                if (gen[i] != null && !AssetDatabase.Contains(gen[i])) SaveAsset(gen[i], GenModels, gen[i].name, ".asset");
            return gen.Count;
        }

        static void ConfigureProject()
        {
            PlayerSettings.companyName = "Treasure Hunt Studio";
            PlayerSettings.productName = "Treasure Hunt - Pirate Cove";
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.AutoRotation;
            PlayerSettings.allowedAutorotateToLandscapeLeft = true;
            PlayerSettings.allowedAutorotateToLandscapeRight = true;
            PlayerSettings.allowedAutorotateToPortrait = false;
            PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
#if UNITY_2021_2_OR_NEWER
            PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android, "com.treasurehunt.piratecove");
#else
            PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, "com.treasurehunt.piratecove");
#endif
#if !ENABLE_LEGACY_INPUT_MANAGER && !TH_INPUT_SYSTEM
            // Neither input backend is usable: enable "Both" so keyboard/touch work (requires an editor restart).
            Object ps = Unsupported.GetSerializedAssetInterfaceSingleton("PlayerSettings");
            SerializedObject so = new SerializedObject(ps);
            SerializedProperty prop = so.FindProperty("activeInputHandler");
            if (prop != null) { prop.intValue = 2; so.ApplyModifiedProperties(); }
            Debug.LogWarning("[TreasureHunt] Active Input Handling set to 'Both'. Please restart the Unity Editor.");
#endif
        }

        static void CreateScene(PrefabCatalog catalog)
        {
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            GameObject sun = new GameObject("Sun");
            Light l = sun.AddComponent<Light>();
            l.type = LightType.Directional;
            l.color = new Color(1f, 0.7f, 0.45f);
            l.intensity = 1.3f;
            l.shadows = LightShadows.Soft;
            sun.transform.rotation = Quaternion.Euler(14f, -35f, 0f);

            GameObject camGo = new GameObject("Main Camera");
            camGo.tag = "MainCamera";
            Camera cam = camGo.AddComponent<Camera>();
            cam.clearFlags = CameraClearFlags.Skybox;
            camGo.AddComponent<AudioListener>();
            camGo.transform.position = new Vector3(1.5f, 2.2f, 5.5f);
            camGo.transform.LookAt(new Vector3(0, 1.5f, 0));

            GameObject boot = new GameObject("PirateCove_Bootstrap");
            Bootstrap b = boot.AddComponent<Bootstrap>();
            b.catalog = catalog;

            // Edit-mode preview (destroyed automatically when Play starts)
            GameObject preview = new GameObject("EditorPreview (auto-removed in Play mode)");
            preview.AddComponent<EditorPreview>();
            PlacePreview(catalog, preview.transform, "side_TropicalIsland", Vector3.zero, 0);
            PlacePreview(catalog, preview.transform, "gate_TropicalIsland", new Vector3(0, 0, 1), 0);
            PlacePreview(catalog, preview.transform, "player", Vector3.zero, 0);
            PlacePreview(catalog, preview.transform, "ob_Crate", new Vector3(-2.5f, 0, 18), 0);
            PlacePreview(catalog, preview.transform, "ob_LowRope", new Vector3(0, 0, 30), 0);
            PlacePreview(catalog, preview.transform, "pu_Magnet", new Vector3(2.5f, 1.1f, 14), 0);
            PlacePreview(catalog, preview.transform, "dec_palm", new Vector3(-8, -0.2f, 10), 90);
            PlacePreview(catalog, preview.transform, "dec_waterfall", new Vector3(16, -0.2f, 26), -90);
            for (int i = 0; i < 5; i++)
            {
                GameObject g = PlacePreview(catalog, preview.transform, "gnd_TropicalIsland", new Vector3(0, -0.25f, 4 + i * 8), 0);
                if (g != null) g.transform.localScale = new Vector3(8.5f, 0.5f, 8f);
                PlacePreview(catalog, preview.transform, "col_Coin", new Vector3(2.5f, 0.9f, 20 + i * 2), 0);
            }

            Material sky = MaterialLibrary.CreateSkybox();
            if (sky != null) { SaveAsset(sky, GenMaterials, "PirateSunsetSky", ".mat"); RenderSettings.skybox = sky; }
            RenderSettings.sun = l;
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogColor = new Color(0.93f, 0.62f, 0.46f);
            RenderSettings.fogStartDistance = 40f;
            RenderSettings.fogEndDistance = 170f;

            LightingSettings ls = new LightingSettings();
            ls.name = "PirateCoveLighting";
            ls.bakedGI = false;
            ls.realtimeGI = false;
            SaveAsset(ls, "Assets/Settings", "PirateCoveLighting", ".lighting");
            Lightmapping.lightingSettings = ls;

            EditorSceneManager.SaveScene(scene, ScenePath);
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
        }

        static GameObject PlacePreview(PrefabCatalog catalog, Transform parent, string key, Vector3 pos, float yaw)
        {
            GameObject prefab = catalog.FindPrefab(key);
            if (prefab == null) return null;
            GameObject g = (GameObject)PrefabUtility.InstantiatePrefab(prefab);
            g.transform.SetParent(parent, false);
            g.transform.localPosition = pos;
            g.transform.localRotation = Quaternion.Euler(0, yaw, 0);
            return g;
        }

        // ------------------------------------------------------------------ validation
        public static bool Validate(out string report)
        {
            StringBuilder sb = new StringBuilder();
            int errors = 0;
            Action<bool, string> check = (cond, msg) =>
            {
                sb.AppendLine((cond ? "[PASS] " : "[FAIL] ") + msg);
                if (!cond) errors++;
            };

            check(File.Exists(ScenePath), "Scene exists: " + ScenePath);
            bool inBuild = false;
            foreach (EditorBuildSettingsScene s in EditorBuildSettings.scenes) if (s.path == ScenePath && s.enabled) inBuild = true;
            check(inBuild, "Scene is enabled in Build Settings (startup scene)");

            PrefabCatalog catalog = AssetDatabase.LoadAssetAtPath<PrefabCatalog>(CatalogPath);
            check(catalog != null, "Prefab catalog exists: " + CatalogPath);
            check(MaterialLibrary.LitShader != null, "Lit shader available (" + (MaterialLibrary.IsURP ? "URP" : "Built-in") + ")");
            check(Shader.Find("Sprites/Default") != null, "Particle shader 'Sprites/Default' available");
            check(Shader.Find("Skybox/Procedural") != null, "Skybox shader available");

            if (catalog != null)
            {
                catalog.Invalidate();
                GameConfig cfg = new GameConfig();
                int ok = 0;
                foreach (string key in WorldFactory.AllKeys(cfg))
                {
                    GameObject p = catalog.FindPrefab(key);
                    if (p == null) { check(false, "Prefab missing: " + key); continue; }
                    string problem = CheckPrefab(key, p);
                    if (problem != null) check(false, key + ": " + problem); else ok++;
                }
                check(ok > 0, ok + " prefabs validated (colliders, components, references)");
                int nullMats = 0;
                foreach (Material m in catalog.materials) if (m == null || m.shader == null) nullMats++;
                check(nullMats == 0 && catalog.materials.Count > 0, catalog.materials.Count + " materials saved, missing/invalid: " + nullMats);
            }

            if (File.Exists(ScenePath))
            {
                Scene active = SceneManager.GetActiveScene();
                bool opened = active.path == ScenePath;
                Scene s = opened ? active : EditorSceneManager.OpenScene(ScenePath, OpenSceneMode.Additive);
                int boots = 0; bool catalogAssigned = false;
                foreach (GameObject root in s.GetRootGameObjects())
                    foreach (Bootstrap b in root.GetComponentsInChildren<Bootstrap>(true)) { boots++; catalogAssigned |= b.catalog != null; }
                check(boots == 1, "Scene contains exactly one Bootstrap (found " + boots + ")");
                check(catalogAssigned, "Bootstrap has the prefab catalog assigned");
                if (!opened) EditorSceneManager.CloseScene(s, true);
            }

            // Spawn-safety simulation: no row may block all three lanes.
            System.Random rng = new System.Random(7);
            PlannedRow row = new PlannedRow();
            int unsafeRows = 0;
            for (int t = 0; t < ThemeInfo.Count; t++)
                for (int i = 0; i < 20000; i++)
                {
                    SpawnPlanner.Plan(rng, (ThemeId)t, i / 20000f, row);
                    if (!SpawnPlanner.IsSafe(row.lanes)) unsafeRows++;
                }
            check(unsafeRows == 0, "Spawn planner: 100,000 simulated rows, unavoidable rows = " + unsafeRows);

            sb.Insert(0, errors == 0 ? "RESULT: ALL CHECKS PASSED\n" : "RESULT: " + errors + " PROBLEM(S)\n");
            report = sb.ToString();
            try { File.WriteAllText(Path.Combine(Directory.GetParent(Application.dataPath).FullName, "TreasureHuntValidation.txt"), report); } catch { }
            if (errors == 0) Debug.Log("[TreasureHunt] Validation passed.\n" + report); else Debug.LogError("[TreasureHunt] Validation failed.\n" + report);
            return errors == 0;
        }

        static string CheckPrefab(string key, GameObject p)
        {
            foreach (Renderer r in p.GetComponentsInChildren<Renderer>(true))
            {
                if (r is ParticleSystemRenderer) continue;
                if (r.sharedMaterial == null) return "renderer '" + r.name + "' has no material";
                MeshFilter mf = r.GetComponent<MeshFilter>();
                if (mf != null && mf.sharedMesh == null) return "mesh missing on '" + r.name + "'";
            }
            if (key == "player")
            {
                PlayerController pc = p.GetComponent<PlayerController>();
                Rigidbody rb = p.GetComponent<Rigidbody>();
                if (pc == null || pc.capsule == null || pc.animator == null) return "PlayerController references missing";
                if (rb == null || !rb.isKinematic) return "player needs a kinematic Rigidbody";
                if (pc.animator.legL == null || pc.animator.armR == null) return "animator rig references missing";
                return null;
            }
            if (key == "ob_CollapsingBridge")
            {
                CollapsingBridge cb = p.GetComponent<CollapsingBridge>();
                if (cb == null || cb.lanes == null || cb.lanes.Length != 3) return "bridge lanes missing";
                foreach (BridgeLane l in cb.lanes) if (l == null || l.groundCollider == null || l.groundCollider.isTrigger) return "bridge lane ground collider invalid";
                return null;
            }
            if (key.StartsWith("ob_"))
            {
                Obstacle o = p.GetComponent<Obstacle>();
                if (o == null) return "Obstacle component missing";
                if (o.hitColliders == null || o.hitColliders.Length == 0) return "no hit collider";
                foreach (Collider c in o.hitColliders) if (c == null || !c.isTrigger) return "hit collider must be a trigger";
                return null;
            }
            if (key.StartsWith("col_") || key.StartsWith("pu_"))
            {
                Collectible c = p.GetComponent<Collectible>();
                Collider col = p.GetComponent<Collider>();
                if (c == null || c.visual == null) return "Collectible/visual missing";
                if (col == null || !col.isTrigger) return "pickup needs a trigger collider";
                return null;
            }
            if (key.StartsWith("gnd_"))
            {
                BoxCollider bc = p.GetComponent<BoxCollider>();
                if (bc == null || bc.isTrigger) return "ground needs a solid BoxCollider";
                return null;
            }
            return null;
        }

        // ------------------------------------------------------------------ export & build
        public static string ExportPackage()
        {
            string root = Directory.GetParent(Application.dataPath).FullName;
            string path = Path.Combine(root, "TreasureHuntPirateCove.unitypackage");
            List<string> roots = new List<string>();
            string[] candidates = { ScenePath, "Assets/Scripts", "Assets/Editor/TreasureHuntSetup.cs", "Assets/Editor/TreasureHunt.Editor.asmdef", PrefabRoot, GenMaterials, GenModels, GenTextures,
                CatalogPath, LightingPath, "Assets/Tests/Editor/GameplayLogicTests.cs", "Assets/Tests/Editor/TreasureHunt.Tests.asmdef", "Assets/Resources/Audio/_AudioOverrides_README.txt", "Assets/README_TreasureHunt.md" };
            foreach (string c in candidates) if (AssetDatabase.IsValidFolder(c) || File.Exists(c)) roots.Add(c);
            AssetDatabase.ExportPackage(roots.ToArray(), path, ExportPackageOptions.Recurse);
            Debug.Log("[TreasureHunt] Exported " + path);
            if (!Application.isBatchMode) EditorUtility.RevealInFinder(path);
            return path;
        }

        public static bool BuildAndroid()
        {
            if (!BuildPipeline.IsBuildTargetSupported(BuildTargetGroup.Android, BuildTarget.Android))
            {
                string msg = "Android Build Support is not installed. Add it in Unity Hub > Installs > (version) > Add modules > Android Build Support (with OpenJDK and Android SDK & NDK).";
                Debug.LogError("[TreasureHunt] " + msg);
                if (!Application.isBatchMode) EditorUtility.DisplayDialog("Android build", msg, "OK");
                return false;
            }
            string root = Directory.GetParent(Application.dataPath).FullName;
            string outDir = Path.Combine(root, "Builds/Android");
            Directory.CreateDirectory(outDir);
            EditorUserBuildSettings.buildAppBundle = false;
            BuildPlayerOptions o = new BuildPlayerOptions();
            o.scenes = new[] { ScenePath };
            o.locationPathName = Path.Combine(outDir, "TreasureHuntPirateCove.apk");
            o.target = BuildTarget.Android;
            o.targetGroup = BuildTargetGroup.Android;
            o.options = BuildOptions.None;
            UnityEditor.Build.Reporting.BuildReport rep = BuildPipeline.BuildPlayer(o);
            bool ok = rep.summary.result == UnityEditor.Build.Reporting.BuildResult.Succeeded;
            Debug.Log("[TreasureHunt] Android build " + rep.summary.result + " -> " + o.locationPathName);
            return ok;
        }
    }
}
