# Treasure Hunt — Pirate Cove

A complete 3D endless runner for Unity (C#). A pirate captain auto-runs along a three-lane track through five
connected areas — **Tropical Island → Pirate Harbor → Shipwreck Passage → Haunted Cave → Treasure Temple** —
dodging 14 obstacle types, collecting treasure and using 6 power-ups. Runs on PC (keyboard) and Android (swipe).

No paid assets, no external packages, no API keys. Every model, texture, sound and the music are generated in code.

---

## Open and play (Unity Hub)

1. Extract `TreasureHuntPirateCove.zip` anywhere (avoid very long paths on Windows).
2. **Unity Hub → Projects → Add → Add project from disk →** select the `TreasureHuntPirateCove` folder.
3. Open it with **Unity 2022.3 LTS** (recommended; 2021.3 LTS and Unity 6 also supported). If Hub says the
   version is not installed, pick any installed 2021.3+ editor and confirm.
4. **First open:** after scripts compile, the project builds itself automatically (progress bar
   "Treasure Hunt - Pirate Cove", ~10–40 s). It generates all textures, materials, meshes and ~70 prefabs,
   creates `Assets/Scenes/PirateCove.unity`, adds it to Build Settings, validates everything and opens it.
5. Press **Play**.

If the automatic step didn't run (or you want to rebuild): menu **Treasure Hunt → Build Complete Game**.
That single command recreates everything. Nothing has to be wired up in the Inspector.

## Controls

| Action | PC | Android |
|---|---|---|
| Move left | A / Left Arrow | Swipe left |
| Move right | D / Right Arrow | Swipe right |
| Jump | Space / Up Arrow (W) | Swipe up |
| Slide | S / Down Arrow | Swipe down (in the air: fast-drop, then slide) |
| Pause / resume | Escape (P) | On-screen pause button |

In the Editor you can also test swipes by dragging with the mouse. Taps never trigger moves, and one gesture
produces at most one move.

## Gameplay

* **Obstacle rules** – *Jump*: crates, spike traps, rolling logs/barrels, cannonballs, gaps between docks.
  *Slide*: low rope nets, spinning cave traps. *Change lane*: crate stacks, explosive barrels, pirate guards,
  swinging anchors, cannons, falling rocks (red warning circle first), rotten collapsing bridge lanes (dark planks).
  Falling off the track into the ocean ends the run.
* **Fair spawning** – rows are planned lane-by-lane; a row never blocks all three lanes, a collapsing bridge
  always keeps a solid lane, and row spacing grows with speed so there is always time to react.
* **Treasure** – gold coins (trails, lane-switch trails, jump arcs), blue gems, keys, chests (a key upgrades the
  chest reward) and rare golden artifacts.
* **Power-ups** – Coin Magnet, Shield (absorbs one hit), Speed Boost (faster + smashes obstacles),
  Score ×2, Treasure Detector (beams over rare treasure and higher rare-spawn chance), Treasure Bonus (instant).
  Picking up an active power-up refreshes it to full duration; different power-ups run at the same time.
* **Revive** – costs gems (20, doubling per revive, max 3 per run). Clears hazards around you, lays a rescue
  platform over any gap and gives 2.5 s of invulnerability. There is no ad integration and none is simulated.
* **Saved** – best score, coins, gems, keys, sound/music/sensitivity settings (PlayerPrefs).

All values (speeds, jump, rewards, power-up durations, revive cost, spawn chances) are editable on the
**PirateCove_Bootstrap** object in the scene (`config` field).

## Menu commands (Treasure Hunt menu)

* **Build Complete Game** – regenerate scene, prefabs, materials and settings.
* **Validate Project** – checks scene, build settings, every prefab's colliders/components/references,
  materials, shaders, and simulates 100,000 obstacle rows; writes `TreasureHuntValidation.txt`.
* **Export UnityPackage** – writes `TreasureHuntPirateCove.unitypackage` (including generated prefabs/scene).
* **Build Android APK** – builds `Builds/Android/TreasureHuntPirateCove.apk` (needs Android Build Support).
* **Reset Saved Progress**.

Tests: **Window → General → Test Runner → EditMode → Run All** (13 tests).

Batch mode:
```
Unity -batchmode -projectPath <path> -executeMethod TreasureHunt.EditorTools.TreasureHuntSetup.BatchSetup -logFile setup.log
Unity -batchmode -projectPath <path> -executeMethod TreasureHunt.EditorTools.TreasureHuntSetup.BatchBuildAndroid -logFile android.log
Unity -batchmode -projectPath <path> -runTests -testPlatform EditMode -testResults results.xml
```

## Android

1. Unity Hub → Installs → your editor → **Add modules → Android Build Support** (+ OpenJDK, Android SDK & NDK).
2. In the project: **File → Build Settings → Android → Switch Platform**.
3. **Treasure Hunt → Build Android APK** (or Build Settings → Build). Orientation is set to landscape and the
   package id to `com.treasurehunt.piratecove`.

## Importing into another project (unitypackage)

Import `TreasureHuntPirateCove.unitypackage`, wait for compilation, then click **Generate** in the dialog (or use
**Treasure Hunt → Build Complete Game**). Requirements: the uGUI package (`com.unity.ugui`, present by default) and
Active Input Handling set to *Input Manager* or *Both* — or the Input System package installed (supported
automatically). Built-in render pipeline recommended; URP is detected and uses URP/Lit materials.

Note for existing projects: the game's assembly definitions live in `Assets/Scripts` and `Assets/Editor`, so any
other scripts already in those two folders would be compiled into the game's assemblies. If your project keeps
its own scripts there, move them into a subfolder with their own `.asmdef`, or move the Treasure Hunt folders.
Generated content is written only to `PirateCove` subfolders (`Assets/Prefabs/PirateCove`,
`Assets/Materials/PirateCove`, …) and regeneration never touches anything else.

## Project layout

```
Assets/
  Scenes/            PirateCove.unity (generated)
  Scripts/           TreasureHunt.Runtime assembly
    Player/          PlayerController, PlayerAnimator, CameraFollow, PirateBuilder
    GameManager/     GameManager (state machine), Bootstrap (assembles the game), RunStats
    Environment/     EnvironmentBuilder (scenery), OceanWater, AtmosphereController, Backdrop
    TrackGeneration/ TrackGenerator, SpawnPlanner (pure logic), Themes, WorldFactory
    Obstacles/       Obstacle, Hazards (rolling, falling, swinging, cannon, guard, bridge), ObstacleBuilder
    Collectibles/    Collectible, CollectibleBuilder
    PowerUps/        PowerUpManager, PowerUpTimers (pure logic)
    UI/              UIManager, UIFactory
    Audio/           AudioManager, ProceduralAudio
    SaveSystem/      SaveSystem
    Utilities/       GameConfig, ObjectPool, MeshFactory, TextureFactory, MaterialLibrary, FxManager, InputAdapter …
  Editor/            TreasureHuntSetup (generator, validator, exporter, Android build)
  Tests/Editor/      EditMode tests
  Prefabs/PirateCove  Materials/PirateCove  Models/PirateCove  Textures/PirateCove  Settings/   (generated)
  Resources/Audio/   optional audio overrides
```
