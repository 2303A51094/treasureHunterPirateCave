Optional audio overrides. All sounds are synthesized at runtime, so this folder can stay empty.
To replace a sound, drop an AudioClip here with one of these exact names:
Coin, Gem, Key, Chest, Artifact, Jump, Slide, Hit, Explosion, Splash, PowerUp, Shield, Cannon,
Footstep, Button, Rumble, Revive, Music, GameOver, Ocean, Seagull
