# BUILD_REPORT — Treasure Hunt: Pirate Cove

Date: 2026-10-27

## 1. Summary

| Item | Status |
|---|---|
| Complete Unity project (scripts, editor generator, tests, packages, settings) | **Delivered** |
| C# compilation (runtime + editor + tests, 3 configurations) | **0 errors, 0 warnings** (Mono `mcs` against Unity API stubs — see §4) |
| Gameplay logic & physics checks executed | **10,163 passed, 0 failed** |
| Runtime play-test inside the Unity Editor | **Not performed** — Unity is not installable in the build environment |
| Scene / prefab / material generation | **Not executed here** — runs automatically on first open in Unity (see §5) |
| `TreasureHuntPirateCove.unitypackage` | **Delivered** (scripts, editor tool, tests, docs; content is generated on import) |
| Android APK | **Not built** — no Unity/Android SDK in the build environment (steps in §7) |

## 2. Environment

* Build machine: Linux (Ubuntu 24), **no Unity Editor available** and none installable (no network access to Unity's servers).
* Tools used: Mono C# compiler 6.x (`mcs`), Unity 6 API type definitions (npm `unity-types@6000.5.4`) to verify engine APIs.
* Target Unity version: **2022.3 LTS** (recommended). Code is written to also compile on **2021.3 LTS** and **Unity 6**
  (conditional paths for `LegacyRuntime.ttf` vs `Arial.ttf`, `NamedBuildTarget`, and new Input System).
* Render pipeline: Built-in (Standard shader). URP is auto-detected (URP/Lit, transparent setup).

## 3. Features implemented

**Core:** auto-run, smooth 3-lane switching, jump (buffered), slide (+ fast-drop from the air), kinematic movement with
ground probe (cannot fall through the track), collision handling with single-fire guards, speed ramp 11→26 m/s,
distance score, Game Over, retry, home, pause/resume, revive.

**Environment (5 connected areas, cycling every 240 m with themed gateways and blended lighting/fog):**
Tropical Island (beaches, palms, waterfalls with scrolling water + mist, watchtowers), Pirate Harbor (docks on posts,
moored galleons, sea fort, lanterns, cannons, anchors, rope coils), Shipwreck Passage (hull walls, tilted wrecks,
broken masts, torn sails, misty moonlight), Haunted Cave (rock walls & ceiling arches, stalactites, glowing crystals with
lights, glowing glyph walls, torches), Treasure Temple (gold-trimmed walls, pillars, statues, treasure piles, braziers).
Animated vertex-wave ocean, procedural sunset skybox, sun + moonlight, linear fog, distant islands/sea stacks/ships.

**Obstacles (14 + cannonballs):** crate, crate stack, explosive barrels (lit fuse, explosion FX), rolling log, rolling barrel,
falling rock (ground warning first), collapsing bridge (rotten lanes shake then drop), dock/ocean gaps, pirate guard (animated),
swinging anchor, cannon (fires rolling cannonballs), low rope net, spike trap, spinning spiked cave trap.
Rolling hazards show a spinning red warning marker.

**Collectibles:** coins (straight trails, lane-switch trails, jump arcs over obstacles and gaps), gems, keys, chests
(key upgrades reward), golden artifacts. Spin/bob animation, sparkle FX, sounds, HUD counters, persistent wallet.

**Power-ups:** Magnet, Shield, Speed Boost (smashes obstacles, FOV/streak FX, 0.8 s grace on expiry), Score ×2,
Treasure Detector (beams over rare treasure + 3× rare spawn chance), Treasure Bonus (instant). HUD icons with timer bars.
Stacking: refresh-to-full, different types concurrent, shield = one hit.

**UI:** Main Menu (title, Play, Settings, Sound toggle, best score, coins/gems/keys), HUD (score, distance, coins, gems,
keys, ×2 indicator, power-up bar, pause button, area banner, toasts), Pause (Resume, Restart, Home, Sound), Game Over
(score, best, NEW BEST, coins, gems, Revive with gem cost, Home, Retry), Settings (sound, music, swipe sensitivity; saved).

**Audio:** 17 synthesized SFX, original sea-shanty music loop, game-over sting, ocean ambience loop, random seagulls.
Any sound can be overridden by dropping a clip in `Assets/Resources/Audio`.

**Architecture/performance:** keyed object pooling for every spawned object (prewarmed), mesh combining per material for
static scenery, GPU instancing on materials, shared world-space particle systems driven by `EmitParams` (no per-effect
allocations), HUD text updated only on change, ocean arrays preallocated, single subscription points for events.

## 4. Tests executed and results

### 4.1 Compilation (actually executed)
Unity is unavailable, so all 40 C# files (6463 lines) were compiled with Mono `mcs` against hand-written stubs of the
UnityEngine / UnityEngine.UI / UnityEditor / NUnit APIs used. Engine APIs were cross-checked against the Unity 6 type
definitions. Results:

| Configuration | Result |
|---|---|
| Runtime, legacy Input Manager, Unity 2022.2+ | 0 errors, 0 warnings |
| Runtime, new Input System only (`TH_INPUT_SYSTEM`) | 0 errors, 0 warnings |
| Runtime, Unity 2021.3 path | 0 errors, 0 warnings |
| Editor tool (generator/validator/export/APK) | 0 errors |
| EditMode tests | 0 errors |

Limitation: stubs prove the code is internally consistent and uses the API names/signatures I expect; a real Unity compile
is the final word. Any mismatch would be a small signature fix, and would show in the Console on first open.

### 4.2 Gameplay logic, executed against the real game code
The real `SpawnPlanner`, `PowerUpTimers`, `SwipeLogic`, `SaveSystem` and `GameConfig` were run in a harness:

```
== Spawn safety ==
  rows=250000 unsafe=0 gaps=12040 bridges=10107 rolling=10034 fullSlide=7834
  Crate=65680 CrateStack=50169 ExplosiveBarrel=27057 RollingLog=7670 RollingBarrel=5133 FallingRock=23139 CollapsingBridge=14074 DockGap=36120 PirateGuard=41605 SwingingAnchor=15504 Cannon=15513 LowRope=65721 SpikeTrap=65274 CaveTrap=43694 CannonBall=0 
== Survivability (lane reachability between consecutive rows) ==
  worst lane move=2  min time slack=0.353 s
== Jump / slide / gap physics (frame simulation @60fps) ==
  speed 11.0 m/s: crate jump window 0.37s, gap(4.56m) window 0.33s, slide window 0.63s
  speed 16.0 m/s: crate jump window 0.42s, gap(4.56m) window 0.46s, slide window 0.67s
  speed 21.0 m/s: crate jump window 0.43s, gap(4.56m) window 0.53s, slide window 0.69s
  speed 26.0 m/s: crate jump window 0.33s, gap(4.56m) window 0.46s, slide window 0.70s
  speed 31.0 m/s: crate jump window 0.26s, gap(4.56m) window 0.39s, slide window 0.71s
  speed 36.0 m/s: crate jump window 0.21s, gap(4.56m) window 0.33s, slide window 0.71s
  speed 41.0 m/s: crate jump window 0.17s, gap(4.56m) window 0.29s, slide window 0.72s
  jump apex = 1.74 m (rope collider bottom 1.15 m, top 3.55 m: cannot be jumped)
== Swipe ==
== Power-ups ==
== Save system ==

RESULT: 10163 passed, 0 failed
```

What this proves: no unavoidable obstacle rows in 250,000 generated rows; every collapsing bridge keeps a solid lane;
all planned obstacle types appear; between any two rows there is always enough time (≥0.35 s spare, incl. 0.3 s
reaction) to reach a free lane at every speed; jump/gap/slide timing windows are fair at all speeds (frame-accurate
simulation of the same jump physics the player uses); swipe classification, power-up stacking/expiry/shield, and the
save system (best score, gem spend for revive, keys, settings) behave as specified.

### 4.3 Unity EditMode tests (written, not run here)
`Assets/Tests/Editor/GameplayLogicTests.cs` — 13 tests: spawn safety, bridges, gap width, obstacle rules, jump/slide
heights, row spacing, swipe, 3× power-up behaviour, save system, object pool reuse, and **building every one of the ~70
prefab keys procedurally and checking their colliders**. Run via Test Runner or `-runTests -testPlatform EditMode`.

### 4.4 Not tested (requires Unity)
Scene loading, rendering/visual quality, camera feel, actual collisions in PhysX, UI layout at different aspect ratios,
audio playback, prefab serialization, frame rate on devices, Android build. The project includes a validator
(**Treasure Hunt → Validate Project**) that checks the scene, build settings, every prefab's components/colliders/material
references and simulates 100,000 rows, and writes `TreasureHuntValidation.txt`.

## 5. How the project assembles itself
The delivered folder contains code only. On first open, `TreasureHuntSetup` (Editor, `[InitializeOnLoad]`) sees
`Assets/Settings/TreasureHuntAutoSetup.pending` and runs **Build Complete Game**: creates folders; generates and saves
textures, materials, meshes and ~70 prefabs (in `…/PirateCove` subfolders) plus a prefab catalog; creates
`Assets/Scenes/PirateCove.unity` (sun, camera, Bootstrap with catalog assigned, edit-mode preview); disables baked/realtime
GI; sets it as the only Build Settings scene; sets product name, landscape orientation and Android package id; validates.
At Play, `Bootstrap` builds the game and wires every reference in code. If the catalog is missing, every object is built
procedurally, so the scene still plays.

## 6. Known limitations
* Not run inside Unity by me (see §4.4). First open is the first real compile and run.
* Character and props are stylized low-poly primitives with procedural animation, not artist-made models.
* Audio is synthesized (chiptune/ambient quality); replaceable via `Resources/Audio`.
* No ads, IAP, leaderboard, achievements or daily missions (from the reference sheet's feature list); revive uses gems.
* Very long runs (>~50 km) will slowly lose float precision (no origin shifting).
* UI uses legacy uGUI Text (no TextMeshPro, to avoid import prompts). Safe-area insets for notched phones are not applied.
* Point lights in cave/temple are limited by the quality setting's pixel light count on low-end devices.

## 7. Android build steps (not performed)
1. Unity Hub → Installs → (your 2022.3 editor) → Add modules → **Android Build Support** + OpenJDK + Android SDK & NDK.
2. Open the project → File → Build Settings → Android → **Switch Platform**.
3. **Treasure Hunt → Build Android APK** → `Builds/Android/TreasureHuntPirateCove.apk`.
   Batch: `Unity -batchmode -projectPath <path> -executeMethod TreasureHunt.EditorTools.TreasureHuntSetup.BatchBuildAndroid -logFile android.log`

## 8. Deliverables
* `TreasureHuntPirateCove.zip` → `TreasureHuntPirateCove/` (Assets, Packages, ProjectSettings, README.md, BUILD_REPORT.md)
* `TreasureHuntPirateCove.unitypackage` (scripts, editor generator, tests, docs; generates content after import)
* `BUILD_REPORT.md` (this file)
